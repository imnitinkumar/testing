<#
Title     : start_tomcat
Purpose   : Starts the Tomcat9 service as part of a release pipeline.
Author    : Mark Spain
Date      : 2021-06-22
Version   : 1.0
Notes     : Must be run from an account with login rights to SailPoint IIQ servers
Keywords  : SailPoint, IIQ, IdentityIQ, deploy, war, tomcat, XML, IGA
#>

<#
.SYNOPSIS
    Starts the Tomcat9 service as part of a release pipeline.
.DESCRIPTION
    Intended to be called as part of a deployment pipeline, this script starts the Tomcat9 service.
#>
# name of tomcat service
$serviceName = "Tomcat9"
try {
	Start-Service $serviceName -Verbose
} catch [System.Management.Automation.ActionPreferenceStopException] {
	Write-host "Error starting $serviceName"
	Exit 1
}
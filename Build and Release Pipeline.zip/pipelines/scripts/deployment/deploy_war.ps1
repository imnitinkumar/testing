<#
Title     : deploy_war
Purpose   : Deploys an IIQ war on the server that executes this script.
Author    : Mark Spain
Edited by : Sarthak Chawla
Edit Date : 09-08-2021
Version   : 1.1
Changelog : Edited to take webapps path as an input
Notes     : Must be run from an account with login rights to SailPoint IIQ servers
Keywords  : SailPoint, IIQ, IdentityIQ, deploy, war, tomcat, XML, IGA
#>

<#
.SYNOPSIS
    Deploys an already built identityiq.war file and imports corresponding XMLs for a given environment.
.DESCRIPTION
    Intended to be called as part of a deployment pipeline, this script deploys a pre-built war
    on the server which is executing this script.
#>

# extract environment variables passed into this powershell session
$SPTARGET               = $env:SPTARGET
$IMPORT_SERVER          = $env:IMPORT_SERVER
$IIQ_ADMIN_USERNAME     = $env:IIQ_ADMIN_USERNAME
$IIQ_ADMIN_PASSWORD     = $env:IIQ_ADMIN_PASSWORD
$WEBAPPS_LOCATION       = $env:WEBAPPS_LOCATION

# make sure we have values for the required environment variables
if ([string]::IsNullOrEmpty($SPTARGET)) {
    Write-Host "Value must be provided for environment variable: SPTARGET -- aborting"
    Exit 1
}
if ([string]::IsNullOrEmpty($IMPORT_SERVER)) {
    Write-Host "Value must be provided for environment variable: IMPORT_SERVER -- aborting"
    Exit 1
}
if ([string]::IsNullOrEmpty($IIQ_ADMIN_USERNAME)) {
    Write-Host "Value must be provided for environment variable: IIQ_ADMIN_USERNAME -- aborting"
    Exit 1
}
if ([string]::IsNullOrEmpty($IIQ_ADMIN_PASSWORD)) {
    Write-Host "Value must be provided for environment variable: IIQ_ADMIN_PASSWORD -- aborting"
    Exit 1
}
if ([string]::IsNullOrEmpty($WEBAPPS_LOCATION)) {
    Write-Host "Value must be provided for environment variable: WEBAPPS_LOCATION -- aborting"
    Exit 1
}

# get the hostname of our current host
$hostname = $(hostname)

Write-Host "SPTARGET: $SPTARGET"
Write-Host "IMPORT_SERVER: $IMPORT_SERVER"
Write-Host "IIQ_ADMIN_USERNAME: $IIQ_ADMIN_USERNAME"
Write-Host "IIQ_ADMIN_PASSWORD: $IIQ_ADMIN_PASSWORD"
Write-Host "WEBAPPS_LOCATION: $WEBAPPS_LOCATION"
Write-Host "hostname: $hostname"

# setting up war file name
$warName = "identityiq"

Write-Host "Using war name = $warName"

# path to webapps dir
$webappsPath = $WEBAPPS_LOCATION

# path to exploded war directory
$explodedWarDir = "$webappsPath\$warName"

# path to deplooyed war file
$deployedWar = "$explodedWarDir.war"

# target folder where Azure will copy the new war file that is being deployed
$dropDir = "$env:SYSTEM_ARTIFACTSDIRECTORY\$env:RELEASE_PRIMARYARTIFACTSOURCEALIAS\drop"

# var that contains the full path of the war file -- war file will always be named "identityiq.war"
$deployableWar = "$dropDir\identityiq.war"

# delete old war file & exploded war directory (if exists), then copy new war file everywhere
# If below is unreliable, try https://stackoverflow.com/questions/38375318/powershell-test-path-then-remove-item-but-file-in-use-by-another-process
Write-Host "Deleting old war file/folder on $hostname"
if (Test-Path $deployedWar -ErrorAction SilentlyContinue) {
    Write-Host "Deleting deployed war: $deployedWar"
    Remove-Item "$deployedWar" -Force
}
if (Test-Path $explodedWarDir -ErrorAction SilentlyContinue) {
    Write-Host "Deleting exploded war directory: $explodedWarDir"
    Remove-Item "$explodedWarDir" -Recurse -Force
}

# fail if the old war or old exploded war directory still exist after attempting to delete
if ((Test-Path $deployedWar) -or (Test-Path $explodedWarDir)) {
    Write-Host "Failed to delete old war or old exploded war -- aborting"
    Exit 1
}

# copy new war -- war to copy will always be called identityiq.war, destination will usually be the same except for devnp
Write-Host "Copying new war file to $webappsPath"
Copy-Item -Path "$deployableWar" -Destination "$deployedWar" -Force -Verbose

# fail if the new war does not exist at the destination path after attempting to copy
if (-Not (Test-Path $deployedWar)) {
    Write-Host "Failed to copy new war -- aborting"
    Exit 1
}

# extract war file ONLY on import servers
if ($IMPORT_SERVER -eq $hostname) {
    Write-Host "Current host ($hostname) is the designated import server"

    # extract the war
    Write-Host "Extracting war in preparation for importing custom XMLs"
    $prevDir = $PWD
    Set-Location $dropDir
    jar xvf identityiq.war | Out-Null
    Set-Location $prevDir

    # import XMLs
    Write-Host "Invoking 'import sp.init-custom.xml' on the iiq console to import custom XMLs"
    #& "$dropDir\WEB-INF\bin\iiq.bat" console -u $IIQ_ADMIN_USERNAME -p $IIQ_ADMIN_PASSWORD -c "about"
    & "$dropDir\WEB-INF\bin\iiq.bat" console -u $IIQ_ADMIN_USERNAME -p $IIQ_ADMIN_PASSWORD -c "import sp.init-custom.xml"

    Write-Host "Finished importing XMLs for environment: $SPTARGET on import server: $IMPORT_SERVER"
} else {
    Write-Host "Current host ($hostname) is not the designated import server ($IMPORT_SERVER)"
}

Write-Host "Finished deploying war on $hostname"

<#
Title     : extract_artifacts
Purpose   : Extracts build scripts and deployable war which are created during the build pipeline.
Author    : Mark Spain
Date      : 2021-06-22
Version   : 1.0
Notes     : Must be run from an account with login rights to SailPoint IIQ servers
Keywords  : SailPoint, IIQ, IdentityIQ, deploy, war, tomcat, XML, IGA
#>

<#
.SYNOPSIS
    Extracts build scripts and deployable war which are created during the build pipeline.
.DESCRIPTION
    Intended to be called as part of a deployment pipeline, this script extracts build scripts and deployable
    war which are created during the build pipeline.
#>

Write-Host "Extracting archived files"
$sourceDir="$(System.ArtifactsDirectory)\_$(Build.DefinitionName)\drop\*.zip"
$targetDir="$(System.ArtifactsDirectory)\_$(Build.DefinitionName)\drop"
Write-Host "Extracting $sourceDir into $targetDir"

Expand-Archive -Force -Path "$sourceDir" -DestinationPath "$targetDir"

Get-ChildItem $targetDir
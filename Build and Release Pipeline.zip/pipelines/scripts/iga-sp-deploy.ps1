<#
Title     : iga-sp-deploy
Purpose   : Deploys an IIQ war and corresponding XMLs to the specified environment.
Author    : Mark Spain
Date      : 2021-03-09
Version   : 0.1
Notes     : Must be run from an account with login rights to SailPoint IIQ servers
Keywords  : SailPoint, IIQ, IdentityIQ, deploy, war, tomcat, XML, IGA
#>

<#
.SYNOPSIS
    Deploys an already built identityiq.war file and imports corresponding XMLs for a given environment
.DESCRIPTION
    Intended to be called as part of a deployment pipeline, this script accepts the name of an
    environment and the administrator password for that environment, then deploys a pre-built war
    to each of the servers for the specified environment and imports the corresponding XMLs using
    the provided administrator password.
.PARAMETER env
    Specifies the name of the environment which is the deployment target.
    Options are dev, devnp, qa, ua, np, and prod.
    Required?               true
    Position?               1
    Default value
    Accept pipeline input?  true
    Accept wildcard chars?  false
.PARAMETER password
    Specifies the password of the administrator account (spadmin) for the environment denoted by the env parameter.
    Required?               true
    Position?               2
    Default value
    Accept pipeline input?  true
    Accept wildcard chars?  false
.EXAMPLE
    .\iga-sp-deploy.ps1 -env qa -password N0tARealP@55word
#>

param (
    [Parameter(Mandatory=$true)]
    [string]$env,
    [Parameter(Mandatory=$true)]
    [string]$password
)

# mapping of environment/branch names to lists of servers for each environment
$envServers = @{
    dev   = @("wigaapausw2d01","wigaapausw2d02")
    devnp = @("wigaapausw2d01","wigaapausw2d02")
    qa    = @("wigauiausw2q01","wigauiausw2q02","wigauiausw2q03","wigatkausw2q01","wigatkausw2q02","wigatkausw2q03")
    ua    = @("wigauiausw2u01","wigauiausw2u02","wigauiausw2u03","wigatkausw2u01","wigatkausw2u02","wigatkausw2u03")
    np    = @("wigauiausw2n01","wigauiausw2n02","wigauiausw2n03","wigatkausw2n01","wigatkausw2n02","wigatkausw2n03")
    #prod  = @("") # TODO: add prod servers once built
}

# destination folder for downloading war from Azure DevOps
$deployDir = "F:\SailPoint\Deploy"
$deployableWar = "$deployDir\identityiq.war"

# path to webapps dir using UNC format minus the hostname portion
$webappsPartialUNCPath = "F$\SailPoint\Apps\Tomcat\webapps"

# name of tomcat service
$serviceName = "Tomcat9"

# remove preceding and trailing spaces
$env = $env.Trim()
$password = $password.Trim()

# exit if parameters are missing or malformed
if (-not($env)) {
    Write-Host "You must supply a value for -env"
    Exit 1
}
if (-not($password)) {
    Write-Host "You must supply a value for -password"
    Exit 1
}
if (-not($envServers.ContainsKey($env))) {
    Write-Host 'Value supplied for -env must be a key in $envServers:'
    Write-Host ($envServers | Out-String)
    Exit 1
}

Write-Host "Deploying to environment: $env"

# get the list of servers for the provided environment
$servers = $envServers[$env]
$serversCSV = $servers -join ", "
Write-Host "Servers: $serversCSV"

# get the "deployed" name of the war file, devnp is a special case
$warName = "identityiq"
if ($env -eq "devnp") {
    $warName = "identityiq-devnp"
}
Write-Host "Using war name = $warName"

# create the deploy folder, -Force suppresses output if the folder already exists
Write-Host "Creating (or clearing) deploy folder: $deployDir"
New-Item -ItemType Directory -Force -Path $deployDir | Out-Null
# make sure the folder is empty
# TODO: uncomment or delete line below which deletes everything in the $deployDir
#Remove-Item $deployDir\* -Recurse -Force

# download war file from Azure DevOps
# TODO: implement me --> download identityiq.war from Azure DevOps and store it at F:\SailPoint\Deploy\identityiq.war
Write-Host "Obtaining deployable war file from Azure DevOps"

# stop tomcat on all servers
Write-Host "Stopping $serviceName on all $env servers: $serversCSV"
Get-Service -Name $serviceName -ComputerName $servers | Stop-Service

# exit if tomcat is still running somewhere
if ((Get-Service $serviceName -ComputerName $servers | Where-Object {$_.Status -ne "Stopped"}).Count -gt 0) {
    Write-Host "Problem stopping Tomcat on one or more servers"
    Get-Service $serviceName -ComputerName $servers | Where-Object {$_.Status -ne "Stopped"} | Format-Table MachineName,Status
    Write-Host "Aborting deployment to environment: $env"
    Exit 1
} else {
    Write-Host "$serviceName stopped on all $env servers: $serversCSV"
}

# for each server, delete old war file & extracted war directory (if exists), then copy new war file everywhere
foreach ($server in $servers) {
    # delete war file/folder
    Write-Host "Deleting old war file/folder on $server"
    Remove-Item "\\$server\$webappsPartialUNCPath\$warName" -Recurse -Force
    Remove-Item "\\$server\$webappsPartialUNCPath\$warName.war" -Force

    # copy new war -- war to copy will always be called identityiq.war, destination will usually be the same except for devnp
    Write-Host "Copying new war file to $server"
    Copy-Item "$deployableWar" -Destination "\\$server\$webappsPartialUNCPath\$warName.war"
}

# extract war file on import server
Write-Host "Extracting war in preparation for importing custom XMLs"
$prevDir = $PWD
Set-Location $deployDir
jar xvf identityiq.war | Out-Null
Set-Location $prevDir

# import XMLs
Write-Host "Invoking 'import sp.init-custom.xml' on the iiq console to import custom XMLs"
#& "$deployDir\WEB-INF\bin\iiq.bat" console -u spadmin -p $password -c "about"
& "$deployDir\WEB-INF\bin\iiq.bat" console -u spadmin -p $password -c "import sp.init-custom.xml"

# start tomcat on all servers
Write-Host "Starting $serviceName on all $env servers: $serversCSV"
Get-Service -Name $serviceName -ComputerName $servers | Start-Service

# log if tomcat failed to start somewhere
if ((Get-Service $serviceName -ComputerName $servers | Where-Object {$_.Status -ne "Running"}).Count -gt 0) {
    Write-Host "Problem starting Tomcat on one or more servers"
    Get-Service $serviceName -ComputerName $servers | Where-Object {$_.Status -ne "Running"} | Format-Table MachineName,Status
} else {
    Write-Host "$serviceName started on all $env servers: $serversCSV"
}

Write-Host "Finished deploying to environment: $env"
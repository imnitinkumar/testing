package com.ey.iiq.api;

import com.ey.iiq.constants.THD_Constants_Birthright;
import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.object.THD_BirthrightRule;
import com.ey.iiq.util.THD_Util_Birthright;
import com.ey.iiq.util.THD_Util_SearchUtil;
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

public class THD_API_BirthrightTableMaintenance {

    private static final Logger log = Logger.getLogger(THD_API_BirthrightTableMaintenance.class);

    public static List<ProvisioningPlan> addRule_Driver(Map<String, Object> processAddResults, SailPointContext context)
            throws GeneralException, SQLException {
        setLogLevel();
        log.trace("ENTERING addRule_Driver()");

        // List of provisioning plans to be returned if any are required
        List<ProvisioningPlan> plansList = null;

        // Ensure the required keys are present in the processAddResults map
        if (!processAddResults.containsKey(THD_Constants_Birthright.ADD_RULE_QUERY_KEY) ||
                !processAddResults.containsKey(THD_Constants_Birthright.APPLICATION_NAME_KEY) ||
                !processAddResults.containsKey(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY) ||
                !processAddResults.containsKey(THD_Constants_Birthright.DYNAMIC_KEY) ||
                !processAddResults.containsKey(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY) ||
                !processAddResults.containsKey(THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY) ||
                !processAddResults.containsKey(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY) ||
                !processAddResults.containsKey(THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY)) {

            // Populate the default error message for any of the missing keys
            String logError = "Key '%s' is not present in processModifyResults map";
            if (!processAddResults.containsKey(THD_Constants_Birthright.ADD_RULE_QUERY_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.ADD_RULE_QUERY_KEY));
            if (!processAddResults.containsKey(THD_Constants_Birthright.APPLICATION_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.APPLICATION_NAME_KEY));
            if (!processAddResults.containsKey(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY));
            if (!processAddResults.containsKey(THD_Constants_Birthright.DYNAMIC_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.DYNAMIC_KEY));
            if (!processAddResults.containsKey(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY));
            if (!processAddResults.containsKey(THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY));
            if (!processAddResults.containsKey(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY));
            if (!processAddResults.containsKey(THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY));
        } else {

            // Extract the required values
            List<String> identitiesThatWillGainEntitlement =
                    Util.otol(processAddResults.get(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY));
            String addRuleQuery        = Util.otos(processAddResults.get(THD_Constants_Birthright.ADD_RULE_QUERY_KEY));
            String applicationName     = Util.otos(processAddResults.get(THD_Constants_Birthright.APPLICATION_NAME_KEY));
            String birthrightTableName = Util.otos(processAddResults.get(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY));
            String dynamic             = Util.otos(processAddResults.get(THD_Constants_Birthright.DYNAMIC_KEY));
            String groupAttributeName  = Util.otos(processAddResults.get(THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY));
            String newEntitlementName  = Util.otos(processAddResults.get(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY));
            String ruleChangelogInsertStatement =
                    Util.otos(processAddResults.get(THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY));

            // Ensure the values that should never be null were extracted
            if (addRuleQuery == null || applicationName == null || birthrightTableName == null ||
                    groupAttributeName == null || newEntitlementName == null || ruleChangelogInsertStatement == null) {

                // Populate the default error message for any of the keys that cannot have null values
                String logError = "Key '%s' cannot have a null value";
                if (addRuleQuery == null)
                    log.error(String.format(logError, THD_Constants_Birthright.ADD_RULE_QUERY_KEY));
                if (applicationName == null)
                    log.error(String.format(logError, THD_Constants_Birthright.APPLICATION_NAME_KEY));
                if (birthrightTableName == null)
                    log.error(String.format(logError, THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY));
                if (groupAttributeName == null)
                    log.error(String.format(logError, THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY));
                if (newEntitlementName == null)
                    log.error(String.format(logError, THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY));
                if (ruleChangelogInsertStatement == null)
                    log.error(String.format(logError, THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY));
            } else {
                log.debug("All required keys and values are present in processModifyResults map");

                // Maintain a check to see if the add was successful (avoid nesting)
                boolean successfullyUpdatedTable = false;

                // Establish connection to SailPoint database (DO NOT CLOSE)
                Connection dbCxn = context.getJdbcConnection();
                if (dbCxn == null) log.error("Could not connect to SailPoint database");
                else {
                    log.debug("Successfully connected to SailPoint database");

                    // Use the DB MetaData to check if the birthright assignment table exists
                    DatabaseMetaData dbm = dbCxn.getMetaData();
                    ResultSet tables = dbm.getTables(null, null, birthrightTableName, null);
                    if (tables == null)
                        log.error("Could not find birthright table '" + birthrightTableName + "' in the SailPoint database");
                    else {
                        if (!tables.next())
                            log.error("Could not find birthright table '" + birthrightTableName + "' in the SailPoint database");
                        else {
                            log.debug("Successfully found birthright table '" + birthrightTableName + "' in the SailPoint database");

                            // Execute insert to add the rule
                            PreparedStatement prStmt = dbCxn.prepareStatement(addRuleQuery);
                            int rowAdded = prStmt.executeUpdate();
                            prStmt.close();

                            // Check to see that a single row was modified in the table
                            if (rowAdded != 1)
                                log.error("Failed to add a row to birthright table '" + birthrightTableName + "'");
                            else {
                                log.debug("Successfully added a row to birthright table '" + birthrightTableName + "'");
                                successfullyUpdatedTable = true;
                            }
                        }

                        // Close birthright tables ResultSet if it was not null
                        tables.close();
                    }

                    // If the birthright table was successfully modified update the rule changelog
                    if (!successfullyUpdatedTable)
                        log.warn("Unable to add rule, will not attempt to add a row to the rule changelog");
                    else {

                        // Ensure the rule changelog exists
                        String ruleChangelogTableName = THD_Constants_Birthright.RULE_CHANGELOG_TABLE_NAME;
                        tables = dbm.getTables(null, null, ruleChangelogTableName, null);
                        if (tables == null) log.error("Could not find rule changelog in the SailPoint database");
                        else {
                            if (!tables.next()) log.error("Could not find rule changelog in the SailPoint database");
                            else {
                                log.debug("Successfully found rule changelog in the SailPoint database");

                                // Execute the query to add a row to the rule changelog
                                PreparedStatement prStmt = dbCxn.prepareStatement(ruleChangelogInsertStatement);
                                int rowAdded = prStmt.executeUpdate();
                                prStmt.close();

                                // Check to see that a single row was added to the table
                                if (rowAdded != 1) log.error("Failed to add a row in rule changelog");
                                else log.debug("Successfully added a row to rule changelog");
                            }
                            // Close birthright tables ResultSet if it was not null
                            tables.close();
                        }
                    }
                }

                // If the birthright table was successfully modified update the affected identities
                if (!successfullyUpdatedTable)
                    log.warn("Unable to add rule, will not attempt to add/remove entitlement to/from identities");
                else {

                    // Check to see if any identities need an entitlement added
                    if ((identitiesThatWillGainEntitlement == null || identitiesThatWillGainEntitlement.isEmpty()))
                        log.debug("No identities require an entitlement be added to their account");
                    else {

                        // Add the entitlement to all the identities that require it
                        for (String identityName : identitiesThatWillGainEntitlement) {
                            log.debug("Attempting to add entitlement '" + newEntitlementName + "' to Identity '" +
                                    identityName + "'");

                            // Get the nativeIdentity on the existing account
                            Link identityApplicationLink = THD_Util_SearchUtil.getAccount(context, identityName, applicationName);
                            if (identityApplicationLink == null)
                                log.error("Failed to get identityApplicationLink when attempting to modify account");
                            else {
                                String nativeIdentity = identityApplicationLink.getNativeIdentity();

                                // Variables used to update the entitlement (if needed) and create plan
                                Identity identityObject = context.getObjectByName(Identity.class, identityName);
                                String updatedEntitlementName;

                                // If the rule is dynamic update the entitlement name based on the identity
                                if (dynamic != null && dynamic.equalsIgnoreCase(THD_Constants_General.TRUE)) {
                                    log.debug("Rule is dynamic, will update entitlement with identity attributes");

                                    updatedEntitlementName = THD_Util_Birthright.updateDynamicEntitlementName(
                                            identityObject, newEntitlementName);
                                }
                                else updatedEntitlementName = newEntitlementName;

                                // Check if the updatedEntitlementName is null
                                if (Util.isNullOrEmpty(updatedEntitlementName))
                                    log.error("Failed to create updatedEntitlementName using identity attributes");
                                else {
                                    log.debug("Creating plan and account request with entitlement name '" +
                                            updatedEntitlementName + "'");

                                    // Variables needed to create the plan
                                    List<ProvisioningPlan.AccountRequest> accountRequests = new ArrayList<>();
                                    ProvisioningPlan plan = new ProvisioningPlan();

                                    // Create the account request
                                    ProvisioningPlan.AccountRequest acctReq = new ProvisioningPlan.AccountRequest();
                                    acctReq.setApplication(applicationName);
                                    acctReq.setNativeIdentity(nativeIdentity);
                                    acctReq.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
                                    acctReq.add(new ProvisioningPlan.AttributeRequest(groupAttributeName,
                                            ProvisioningPlan.Operation.Add, updatedEntitlementName));

                                    // Populate the plan
                                    accountRequests.add(acctReq);
                                    plan.setAccountRequests(accountRequests);
                                    plan.setIdentity(identityObject);
                                    plan.setNativeIdentity(identityName);

                                    // Add the plan to the overall list of plans
                                    if (plansList == null) plansList = new ArrayList<>();
                                    plansList.add(plan);
                                }
                            }
                        }
                    }

                    // Check to see if any plans were created
                    if (plansList == null || plansList.isEmpty())
                        log.debug("No plans were created for adding entitlements");
                    else log.debug("Plans were created for adding entitlements");
                }
            }
        }

        // Return the plans with the account requests required if any
        log.trace("EXITING addRule_Driver()");
        return plansList;
    }

    private static <T> List<Map<T, T>> addRules_CartesianProduct(Iterator<Map.Entry<T, List<T>>> iterator,
                                                                 List<Map<T, T>> mapList) {
        // Continue the process if there are still entries in the iterator
        if (iterator.hasNext()) {

            // Get the next entry
            Map.Entry<T, List<T>> entry = iterator.next();

            // This iteration's maps
            List<Map<T, T>> newMapList = new ArrayList<>();

            // Combination of previous and this iteration's maps
            List<Map<T, T>> combinedMapList = new ArrayList<>();

            // Turn all of the values in the current entry into maps and add them to the newMapList
            for (T currentValue : entry.getValue()) {
                Map<T, T> newMap = new HashMap<>();
                newMap.put(entry.getKey(), currentValue);
                newMapList.add(newMap);
            }

            // If the map list is still empty, create single null entry
            if (newMapList.isEmpty()) {
                Map<T, T> newMap = new HashMap<>();
                newMap.put(entry.getKey(), null);
                newMapList.add(newMap);
            }

            // Combine the previous map with current map
            for (Map<T, T> newMap : newMapList) {
                for (Map<T, T> map : mapList) {
                    Map<T, T> combinedMap = new HashMap<>();
                    combinedMap.putAll(map);
                    combinedMap.putAll(newMap);
                    combinedMapList.add(combinedMap);
                }
            }

            // Return the combinedMap if it's not empty, otherwise return this iterations map
            // (Required for first iteration since above loop won't run while previous mapList is empty)
            return addRules_CartesianProduct(iterator, combinedMapList.isEmpty() ? newMapList : combinedMapList);
        }

        // When there are no more elements return the mapList
        return mapList;
    }

    public static List<Map<String, Object>> addRules_Init(List<String> entitlementNames, Map<String, Object> assignmentCriteria,
                                                          SailPointContext context, String applicationName, String description,
                                                          String dynamic, String launcher) throws GeneralException {
        setLogLevel();
        log.trace("ENTERING addRules_Init()");

        // The returnMap that will contain everything from the driver once init verifies all input and required values
        List<Map<String, Object>> processAddResults = null;

        // Gate used to avoid over nesting after initial input is validated
        boolean initialInputValidated = false;

        // Vars to be extracted from initial input validation
        String groupAttributeName = null;

        // The error message to return if any are encountered
        String errorMessage = null;

        // Ensure everything was retrieved from the input JSON
        if ((assignmentCriteria == null || assignmentCriteria.isEmpty()) ||
                (entitlementNames == null || entitlementNames.isEmpty()) ||
                Util.isNullOrEmpty(applicationName) ||
                Util.isNullOrEmpty(launcher)) {
            if (assignmentCriteria == null || assignmentCriteria.isEmpty())
                log.error("Unable to retrieve assignment criteria from input JSON");
            if (entitlementNames == null || entitlementNames.isEmpty())
                log.error("Unable to retrieve entitlements from input JSON");
            if (Util.isNullOrEmpty(applicationName)) log.error("Unable to retrieve application from input JSON");
            if (Util.isNullOrEmpty(launcher))        log.error("Unable to retrieve launcher from input JSON");

            errorMessage = "Failed to retrieve all required arguments from input JSON, view log for more details";
        } else {
            log.debug("Successfully retrieved all arguments from JSON input");

            // Ensure the application submitted exists in SailPoint
            Application application = THD_Util_SearchUtil.getApplication(context, applicationName);
            if (application == null) {
                errorMessage = "Unable to find application '" + applicationName + "' in SailPoint";
                log.error(errorMessage);
            } else {
                log.debug("Successfully found application '" + applicationName + "' in SailPoint");

                // Get the group attribute off of the application (assume only one)
                if (application.getGroupAttributes() == null || application.getGroupAttributes().isEmpty()) {
                    errorMessage = "Unable to find a group attribute on application '" + applicationName + "'";
                    log.error(errorMessage);
                } else {
                    groupAttributeName = application.getGroupAttributes().get(0).getName();
                    log.debug("Successfully found group attribute name '" + groupAttributeName + "' on application");

                    // Check if the entitlements being added are dynamic or not
                    if (dynamic != null && dynamic.equalsIgnoreCase(THD_Constants_General.TRUE)) {
                        log.debug("Entitlements to be added are dynamic, do not check if they exist in SailPoint");

                        // If dynamic is true the initial input has been validated
                        initialInputValidated = true;
                    } else {
                        log.debug("Entitlements to be added are not dynamic, check if they exist in SailPoint");

                        // Loop through all entitlements submitted and check that they exist in SailPoint
                        boolean allEntitlementsExist = true;
                        for (String entitlementName : entitlementNames) {

                            // Ensure the current entitlement is present
                            if (Util.isNullOrEmpty(entitlementName)) {
                                errorMessage = "Entitlements must not be null or empty in input JSON";
                                log.error(errorMessage);

                                // Set allEntitlementsExist to false and break out of the loop which will end the method
                                allEntitlementsExist = false;
                                break;
                            }

                            // Attempt to get the entitlement from SailPoint to check if it exists
                            ManagedAttribute entitlement = THD_Util_SearchUtil.getManagedAttribute(
                                    context, applicationName, groupAttributeName, entitlementName);
                            if (entitlement == null) {
                                errorMessage = "Unable to find entitlement '" + entitlementName + "' in SailPoint";
                                log.error(errorMessage);

                                // Set allEntitlementsExist to false and break out of the loop which will end the method
                                allEntitlementsExist = false;
                                break;
                            }
                        }
                        if (allEntitlementsExist) {
                            log.debug("Successfully found all entitlements in SailPoint");

                            // At this point everything possible was fetched and validated without fetching Custom Objects
                            initialInputValidated = true;
                        }
                    }
                }
            }
        }

        // Check if the initial input was validated, if so proceed with more fetching/validating
        if (initialInputValidated) {

            log.debug("Get the required values from SailPoint Custom Objects");
            List<String> identityAttributes = THD_Util_Birthright.getBirthrightIdentityAttributes(context);
            String birthrightTableName      = THD_Util_Birthright.getBirthrightTableName(context, applicationName);

            // Check if the required values were retrieved from Custom Objects
            if (Util.isNullOrEmpty(birthrightTableName) || identityAttributes == null || identityAttributes.isEmpty()) {
                if (Util.isNullOrEmpty(birthrightTableName))
                    log.error("Failed to retrieve birthright table name");
                if (identityAttributes == null || identityAttributes.isEmpty())
                    log.error("Failed to retrieve birthright identity attributes");

                errorMessage = "Unable to retrieve required values from Custom Objects from SailPoint, " +
                        "view log for more details";
            } else {
                log.debug("Successfully retrieved required values from Custom Objects");

                // Ensure the assignmentCriteria map has valid input using the birthright identity attributes
                if (!THD_Util_Birthright.verifyAssignmentCriteria(identityAttributes, assignmentCriteria)) {
                    errorMessage = "Failed to validate assignmentCriteria input JSON, view log for more details";
                    log.error(errorMessage);
                } else {
                    log.debug("Successfully validated assignmentCriteria input JSON");

                    // Extract the equalsMap, notEqualsMap, disabled value, and endsInSUP value from the assignmentCriteria
                    Map<String, Object> equalsMap =
                            Util.otom(assignmentCriteria.get(THD_Constants_Birthright.EQUALS_JSON_FIELD));
                    Map<String, Object> notEqualsMap =
                            Util.otom(assignmentCriteria.get(THD_Constants_Birthright.NOT_EQUALS_JSON_FIELD));
                    String disabled  = Util.otos(assignmentCriteria.get(THD_Constants_Birthright.DISABLED_JSON_FIELD));
                    String endsInSUP = Util.otos(assignmentCriteria.get(THD_Constants_Birthright.ENDS_IN_SUP_JSON_FIELD));

                    log.debug("All required fields have been fetched, begin to transform and process request");
                    processAddResults = addRules_Process(
                            entitlementNames, equalsMap, notEqualsMap, context, applicationName,
                            birthrightTableName, description, disabled, dynamic, endsInSUP, groupAttributeName, launcher);
                }
            }
        }

        // Check if any errors were encountered
        if (errorMessage != null) {
            log.debug("An error was encountered, will return the error message as JSON result");
            processAddResults = new ArrayList<>();
            Map<String, Object> errorMap = new HashMap<>();
            errorMap.put(THD_Constants_Birthright.ERROR_MESSAGE, errorMessage);
            processAddResults.add(errorMap);
        }

        log.trace("EXITING addRules_Init()");
        return processAddResults;
    }

    public static List<Map<String, Object>> addRules_Process(List<String> entitlementNames, Map<String, Object> equalsObjectMap,
                                                             Map<String, Object> notEqualsObjectMap, SailPointContext context,
                                                             String applicationName, String birthrightTableName,
                                                             String description, String disabled, String dynamic,
                                                             String endsInSUP, String groupAttributeName, String launcher)
            throws GeneralException {
        log.trace("ENTERING addRules_Process()");

        // The overall results that will be returned
        List<Map<String, Object>> processAddResults = new ArrayList<>();

        log.debug("Transform the JSON input into a list of BirthrightRule Objects");
        List<THD_BirthrightRule> birthrightRules = addRules_Transform(entitlementNames, equalsObjectMap,
                notEqualsObjectMap, applicationName, description, disabled, dynamic, endsInSUP);

        // Loop through each birthrightRule fetching the required values and adding them to the return map
        for (int i = 0; i < birthrightRules.size(); i++) {
            log.debug("Processing BirthrightRule: " + (i + 1));
            THD_BirthrightRule birthrightRule = birthrightRules.get(i);
            String entitlementName = birthrightRule.getEntitlement();

            log.debug("Get the list of identities that meet the criteria of the new BirthrightRule");
            List<String> identitiesMeetingNewRuleCriteria =
                    birthrightRule.getIdentitiesMeetingRuleCriteria(context, groupAttributeName);

            log.debug("Get the list of identities that will need to have the birthright entitlement added");
            List<String> identitiesThatWillGainEntitlement = THD_Util_Birthright.getIdentitiesThatWillGainEntitlement(
                    identitiesMeetingNewRuleCriteria, context, applicationName, entitlementName);

            // Get the number of identities affected by the modification
            int numIdentitiesMeetingNewRuleCriteria = identitiesMeetingNewRuleCriteria.size();
            int numIdentitiesThatWillGainEntitlement = identitiesThatWillGainEntitlement.size();
            log.debug("Number of identities that meet the criteria of the new rule: " + numIdentitiesMeetingNewRuleCriteria);
            log.debug("Number of identities that will gain the entitlement: " + numIdentitiesThatWillGainEntitlement);

            log.debug("Create the SQL query that will be used to add a row to the birthright table");
            String addRuleQuery = birthrightRule.toQuery_Add(birthrightTableName);

            log.debug("Create the SQL query that will be used to add a row to the rule changelog");
            String operation = THD_Constants_Birthright.ADD_RULE_OPERATION;
            String ruleChangelogInsertStatement = THD_Util_Birthright.generateRuleChangelogInsertStatement(
                    launcher, operation, birthrightTableName, birthrightRule, null);

            log.debug("Create the approval comments that will show a preview of identities affected");
            String ruleToString = birthrightRule.toString();
            String approvalComments = String.format(THD_Constants_Birthright.APPROVAL_COMMENTS_ADD_RULE_SHELL,
                    ruleToString, numIdentitiesMeetingNewRuleCriteria, numIdentitiesThatWillGainEntitlement);

            // Populate the currentResults map with all of the Objects that need to be returned
            Map<String, Object> currentResults = new HashMap<>();
            currentResults.put(THD_Constants_Birthright.NUM_MEET_NEW_CRITERIA_KEY, numIdentitiesMeetingNewRuleCriteria);
            currentResults.put(THD_Constants_Birthright.NUM_GAINING_ENTITLEMENT_KEY, numIdentitiesThatWillGainEntitlement);
            currentResults.put(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY, identitiesThatWillGainEntitlement);
            currentResults.put(THD_Constants_Birthright.ADD_RULE_QUERY_KEY, addRuleQuery);
            currentResults.put(THD_Constants_Birthright.APPLICATION_NAME_KEY, applicationName);
            currentResults.put(THD_Constants_Birthright.APPROVAL_COMMENTS_KEY, approvalComments);
            currentResults.put(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY, birthrightTableName);
            currentResults.put(THD_Constants_Birthright.DYNAMIC_KEY, dynamic);
            currentResults.put(THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY, groupAttributeName);
            currentResults.put(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY, entitlementName);
            currentResults.put(THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY, ruleChangelogInsertStatement);
            log.debug("Results of processing BirthrightRule " + (i + 1) + ":\n" + currentResults);

            // Add the results from processing the current birthright rule to the overall results list
            processAddResults.add(currentResults);
        }

        // Return the overall results map containing the results of processing each BirthrightRule
        log.trace("EXITING addRules_Process()");
        return processAddResults;
    }

    public static List<THD_BirthrightRule> addRules_Transform(List<String> entitlementNames, Map<String, Object> equalsObjectMap,
                                                              Map<String, Object> notEqualsObjectMap, String applicationName,
                                                              String description, String disabled, String dynamic, String endsInSUP) {
        log.trace("ENTERING addRules_Transform()");

        // The list of birthright rules to be returned once the transformation is complete
        List<THD_BirthrightRule> birthrightRules = new ArrayList<>();

        log.debug("Transforming the equals and notEquals JSON input maps");
        Map<String, List<String>> multiValuedEqualsMap = equalsObjectMap.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry :: getKey, e ->
                        (e.getValue() == null) ? new ArrayList<>() : Util.otol(e.getValue())));
        Map<String, List<String>> notEqualsMap = notEqualsObjectMap.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry :: getKey, e ->
                        (e.getValue() == null) ? new ArrayList<>() : Util.otol(e.getValue())));

        log.debug("Transform the equalsMap into a list of maps with single-valued strings (Cartesian product)");
        Iterator<Map.Entry<String, List<String>>> iterator = multiValuedEqualsMap.entrySet().iterator();
        List<Map<String, String>> equalsMaps = addRules_CartesianProduct(iterator, new ArrayList<>());

        log.debug("Looping through both the entitlements and list of equalsMaps to get all unique rules");
        for (String entitlementName : entitlementNames) {
            for (Map<String, String> equalsMap : equalsMaps) {
                birthrightRules.add(new THD_BirthrightRule(notEqualsMap, equalsMap, applicationName,
                        description, disabled, dynamic, endsInSUP, entitlementName, null));
            }
        }
        log.debug("Number of birthright rules created: " + birthrightRules.size());

        log.trace("EXITING addRules_Transform()");
        return birthrightRules;
    }

    public static Map<String, Object> getAddRulesTemplate_Driver(List<String> identityAttributes) {
        log.trace("ENTERING getAddRulesTemplate_Driver()");

        log.debug("Create the equals and notEquals maps using the identityAttributes fetched");
        Map<String, ArrayList<String>> equalsMap    = new HashMap<>();
        Map<String, ArrayList<String>> notEqualsMap = new HashMap<>();
        for (String identityAttribute : identityAttributes) {
            equalsMap.put(identityAttribute, new ArrayList<>());
            notEqualsMap.put(identityAttribute, new ArrayList<>());
        }

        log.debug("Construct the assignmentCriteriaMap using the disabled and endsInSUP fields, equalsMap, and notEqualsMap");
        Map<String, Object> assignmentCriteriaMap = new HashMap<>();
        assignmentCriteriaMap.put(THD_Constants_Birthright.DISABLED_JSON_FIELD, THD_Constants_General.EMPTY_STRING);
        assignmentCriteriaMap.put(THD_Constants_Birthright.ENDS_IN_SUP_JSON_FIELD, THD_Constants_General.EMPTY_STRING);
        assignmentCriteriaMap.put(THD_Constants_Birthright.EQUALS_JSON_FIELD, equalsMap);
        assignmentCriteriaMap.put(THD_Constants_Birthright.NOT_EQUALS_JSON_FIELD, notEqualsMap);

        log.debug("Construct the workflowArgsMap using the application and entitlements fields, and the assignmentCriteriaMap");
        Map<String, Object> workflowArgsMap = new HashMap<>();
        workflowArgsMap.put(THD_Constants_Birthright.APPLICATION_JSON_FIELD, THD_Constants_General.EMPTY_STRING);
        workflowArgsMap.put(THD_Constants_Birthright.ASSIGNMENT_CRITERIA_JSON_FIELD, assignmentCriteriaMap);
        workflowArgsMap.put(THD_Constants_Birthright.DESCRIPTION_JSON_FIELD, THD_Constants_General.EMPTY_STRING);
        workflowArgsMap.put(THD_Constants_Birthright.DYNAMIC_JSON_FIELD, THD_Constants_General.EMPTY_STRING);
        workflowArgsMap.put(THD_Constants_Birthright.ENTITLEMENTS_JSON_FIELD, new ArrayList<String>());

        log.debug("Construct the addRuleTemplateMap using only the workflowArgsMap");
        Map<String, Object> addRulesTemplateMap = new HashMap<>();
        addRulesTemplateMap.put(THD_Constants_Birthright.WORKFLOW_ARGS_JSON_FIELD, workflowArgsMap);

        // Return the created Map that will be turned into a JSON Object
        log.trace("EXITING getAddRulesTemplate_Driver()");
        return addRulesTemplateMap;
    }

    public static Map<String, Object> getAddRulesTemplate_Init(SailPointContext context) throws GeneralException {
        setLogLevel();
        log.trace("ENTERING getAddRulesTemplate_Init()");

        // The Map that will become the JSON template
        Map<String, Object> addRulesTemplateMap = null;

        // The error message to return if any are encountered
        String errorMessage = null;

        log.debug("Get the required values from SailPoint Custom Objects");
        List<String> identityAttributes = THD_Util_Birthright.getBirthrightIdentityAttributes(context);

        // Check if the required values were retrieved from Custom Objects
        if (identityAttributes == null || identityAttributes.isEmpty()) {
            errorMessage = "Could not retrieve Birthright Identity Attributes from Custom Object";
            log.error(errorMessage);
        } else {
            log.debug("Successfully retrieved required values from Custom Objects");

            // Construct the addRuleTemplateMap using what has been fetched
            addRulesTemplateMap = getAddRulesTemplate_Driver(identityAttributes);
            log.debug("The addRuleTemplateMap that was created:\n" + addRulesTemplateMap);
        }

        // Check if any errors were encountered
        if (errorMessage != null) {
            log.debug("An error was encountered, will return the error message as JSON result");
            addRulesTemplateMap = new HashMap<>();
            addRulesTemplateMap.put(THD_Constants_Birthright.ERROR_MESSAGE, errorMessage);
        }

        log.trace("EXITING getAddRulesTemplate_Init()");
        return addRulesTemplateMap;
    }

    public static Map<String, Object> getBirthrightApplications_Init(SailPointContext context) throws GeneralException {
        setLogLevel();
        log.trace("ENTERING getBirthrightApplications_Init()");

        // The Map that will become the JSON template
        Map<String, Object> applicationsMap = null;

        // The error message to return if any are encountered
        String errorMessage = null;

        log.debug("Get the required values from SailPoint Custom Objects");
        List<String> birthrightApplicationNames = THD_Util_Birthright.getBirthrightApplications(context);

        // Check if the required values were retrieved from Custom Objects
        if (birthrightApplicationNames == null || birthrightApplicationNames.isEmpty()) {
            errorMessage = "Failed to retrieve Birthright Application Names from Custom Object";
            log.error(errorMessage);
        } else {
            log.debug("Successfully retrieved Birthright Application Names from Custom Object");

            // Construct the Map of birthright application names using what has been fetched
            applicationsMap = new HashMap<>();
            applicationsMap.put(THD_Constants_Birthright.BIRTHRIGHT_APPLICATIONS_JSON_FIELD, birthrightApplicationNames);
            log.debug("Birthright Applications Map:\n" + applicationsMap);
        }

        // Check if any errors were encountered
        if (errorMessage != null) {
            log.debug("An error was encountered, will return the error message as JSON result");
            applicationsMap = new HashMap<>();
            applicationsMap.put(THD_Constants_Birthright.ERROR_MESSAGE, errorMessage);
        }

        // Return the created Map that will be translated into a JSON Object
        log.trace("EXITING getBirthrightApplications_Init()");
        return applicationsMap;
    }

    private static Map<String, Object> getModifyRulesTemplate_Driver(List<Object> ruleIds, List<String> identityAttributes,
                                                                     SailPointContext context, String applicationName,
                                                                     String birthrightTableName)
            throws SQLException, GeneralException {
        log.trace("ENTERING getModifyRulesTemplate_Driver()");

        // The Map that will become the JSON template
        Map<String, Object> modifyRulesTemplateMap;

        // The list of rules based on ruleIds as maps to be turned into JSON
        List<Map<String, Object>> modifyRuleMaps = new ArrayList<>();

        // The error message to return if any are encountered
        String errorMessage = null;

        log.debug("Looping through all the rules in the ruleIds list to create the modifyRulesTemplateMap");
        for (Object ruleIdObject : ruleIds) {
            String ruleId = Util.otos(ruleIdObject);

            // Check that the current ruleId is not null or empty
            if (Util.isNullOrEmpty(ruleId)) {
                errorMessage = "Cannot have null or empty ruleId value in ruleIds Object";
                log.error(errorMessage);
                break;
            } else {
                log.debug("Will attempt to fetch rule template using ruleId '" + ruleId + "'");

                // Create and execute the query to get the rule based on the ruleId passed in
                THD_BirthrightRule ruleToMakeModifyTemplateFor = THD_Util_Birthright.getRuleFromRuleId(
                        identityAttributes, context, applicationName, birthrightTableName, ruleId);

                // Check that the rule was created successfully from the query and if it was translate it into a map
                if (ruleToMakeModifyTemplateFor == null) {
                    errorMessage = "Failed to make BirthrightRule object using ruleId '" + ruleId + "'";
                    log.error(errorMessage);
                } else {
                    log.debug("Successfully created BirthrightRule object using ruleId");

                    // Turn the BirthrightRule object into a map that can be used in the modify template
                    Map<String, Object> modifyRuleMap = ruleToMakeModifyTemplateFor.toMap();

                    // Check that the modifyRuleMap was retrieved successfully
                    if (modifyRuleMap == null || modifyRuleMap.isEmpty()) {
                        errorMessage = "Failed to retrieve modifyRuleMap for rule '" + ruleId + "'";
                        log.error(errorMessage);
                        break;
                    } else {
                        log.debug("Modify Rule '" + ruleId + "' Map:\n" + modifyRuleMap);

                        // Add the modifyRuleMap to the list of maps
                        modifyRuleMaps.add(modifyRuleMap);
                    }
                }
            }
        }

        // Check if any errors were encountered
        if (errorMessage != null) {
            log.debug("An error was encountered, will return the error message as JSON result");
            modifyRulesTemplateMap = new HashMap<>();
            modifyRulesTemplateMap.put(THD_Constants_Birthright.ERROR_MESSAGE, errorMessage);
        } else {

            // Create the workflowArgs map which will contain the application and all the rules
            Map<String, Object> workflowArgsMap = new HashMap<>();
            workflowArgsMap.put(THD_Constants_Birthright.APPLICATION_JSON_FIELD, applicationName);
            workflowArgsMap.put(THD_Constants_Birthright.RULES_JSON_FIELD, modifyRuleMaps);

            // Create the final template map to be returned which contains the workflowArgs map
            modifyRulesTemplateMap = new HashMap<>();
            modifyRulesTemplateMap.put(THD_Constants_Birthright.WORKFLOW_ARGS_JSON_FIELD, workflowArgsMap);
            log.debug("The modifyRulesTemplateMap that was created:\n" + modifyRulesTemplateMap);
        }

        // Return the final map that contains all rules in a modify template
        log.trace("EXITING getModifyRulesTemplate_Driver()");
        return modifyRulesTemplateMap;
    }

    public static Map<String, Object> getModifyRulesTemplate_Init(List<Object> ruleIds, SailPointContext context,
                                                                  String applicationName)
            throws GeneralException, SQLException {
        setLogLevel();
        log.trace("ENTERING getModifyRulesTemplate_Init()");

        // The Map that will become the JSON template
        Map<String, Object> modifyRulesTemplateMap = null;

        // The error message to return if any are encountered
        String errorMessage = null;

        log.debug("Get the required values from SailPoint Custom Objects");
        List<String> identityAttributes = THD_Util_Birthright.getBirthrightIdentityAttributes(context);
        String birthrightTableName      = THD_Util_Birthright.getBirthrightTableName(context, applicationName);

        // Check if the required values were retrieved from Custom Objects
        if (Util.isNullOrEmpty(birthrightTableName) || identityAttributes == null || identityAttributes.isEmpty()) {
            if (Util.isNullOrEmpty(birthrightTableName))
                log.debug("Failed to retrieve birthright table name");
            if (identityAttributes == null || identityAttributes.isEmpty())
                log.error("Failed to retrieve birthright identity attributes");

            errorMessage = "Unable to retrieve required values from Custom Objects from SailPoint, " +
                    "view log for more details";
        } else {
            log.debug("Successfully retrieved required values from Custom Objects");

            // Get the application name from the JSONObject and check to ensure it was retrieved
            if (Util.isNullOrEmpty(applicationName)) {
                errorMessage = "Cannot have null or empty application name";
                log.error(errorMessage);
            } else {
                log.debug("Successfully retrieved application name '" + applicationName + "' from Input JSON");

                // Get the ruleIds from the JSONObject and check to ensure it was retrieved
                if (ruleIds == null || ruleIds.isEmpty()) {
                    errorMessage = "Cannot have null or empty ruleIds";
                    log.error(errorMessage);
                } else {
                    log.debug("Successfully retrieved ruleIds from input JSON:\n" + ruleIds.toString());

                    modifyRulesTemplateMap = getModifyRulesTemplate_Driver(
                            ruleIds, identityAttributes, context, applicationName, birthrightTableName);
                }
            }
        }

        // Check if any errors were encountered
        if (errorMessage != null) {
            log.debug("An error was encountered, will return the error message as JSON result");
            modifyRulesTemplateMap = new HashMap<>();
            modifyRulesTemplateMap.put(THD_Constants_Birthright.ERROR_MESSAGE, errorMessage);
        }

        // Return the created Map that will be translated into a JSON Object
        log.trace("EXITING getModifyRulesTemplate_Init()");
        return modifyRulesTemplateMap;
    }

    public static Map<String, Object> modifyRule_CheckIfIdentitiesAffectedChanged(Map<String, Object> processModifyResults,
                                                                                  SailPointContext context)
            throws GeneralException, SQLException {
        setLogLevel();
        log.trace("ENTERING modifyRule_CheckIfIdentitiesAffectedChanged()");

        // The flag to return used to determine if the workflow must generate an updated approval
        boolean identitiesAffectedHasChanged;

        // Ensure the required keys are present in the processModifyResults map
        if (!processModifyResults.containsKey(THD_Constants_Birthright.APPLICATION_NAME_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.BIRTHRIGHT_IDENTITY_ATTRIBUTES_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.LOSING_ENTITLEMENT_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.MEET_NEW_CRITERIA_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.MEET_OLD_CRITERIA_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.NEW_RULE_AS_STRING_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.OLD_RULE_AS_STRING_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.RULE_ID_KEY)) {

            // Populate the default error message for any of the missing keys
            String logError = "Key '%s' is not present in processModifyResults map";
            if (!processModifyResults.containsKey(THD_Constants_Birthright.APPLICATION_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.APPLICATION_NAME_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.BIRTHRIGHT_IDENTITY_ATTRIBUTES_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.BIRTHRIGHT_IDENTITY_ATTRIBUTES_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.LOSING_ENTITLEMENT_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.LOSING_ENTITLEMENT_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.MEET_NEW_CRITERIA_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.MEET_NEW_CRITERIA_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.MEET_OLD_CRITERIA_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.MEET_OLD_CRITERIA_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.NEW_RULE_AS_STRING_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.NEW_RULE_AS_STRING_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.OLD_RULE_AS_STRING_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.OLD_RULE_AS_STRING_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.RULE_ID_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.RULE_ID_KEY));
        } else {

            // Extract the required values
            List<String> identityAttributes =
                    Util.otol(processModifyResults.get(THD_Constants_Birthright.BIRTHRIGHT_IDENTITY_ATTRIBUTES_KEY));
            List<String> identitiesThatWillGainEntitlement =
                    Util.otol(processModifyResults.get(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY));
            List<String> identitiesThatWillLoseEntitlement =
                    Util.otol(processModifyResults.get(THD_Constants_Birthright.LOSING_ENTITLEMENT_KEY));
            List<String> identitiesMeetingNewRuleCriteria =
                    Util.otol(processModifyResults.get(THD_Constants_Birthright.MEET_NEW_CRITERIA_KEY));
            List<String> identitiesMeetingOldRuleCriteria =
                    Util.otol(processModifyResults.get(THD_Constants_Birthright.MEET_OLD_CRITERIA_KEY));
            String applicationName     = Util.otos(processModifyResults.get(THD_Constants_Birthright.APPLICATION_NAME_KEY));
            String birthrightTableName = Util.otos(processModifyResults.get(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY));
            String newEntitlementName  = Util.otos(processModifyResults.get(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY));
            String newRuleAsString     = Util.otos(processModifyResults.get(THD_Constants_Birthright.NEW_RULE_AS_STRING_KEY));
            String oldEntitlementName  = Util.otos(processModifyResults.get(THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY));
            String oldRuleAsString     = Util.otos(processModifyResults.get(THD_Constants_Birthright.OLD_RULE_AS_STRING_KEY));
            String ruleId              = Util.otos(processModifyResults.get(THD_Constants_Birthright.RULE_ID_KEY));

            // Ensure the values that should never be null or empty were extracted
            if (identityAttributes == null || identityAttributes.isEmpty() ||
                    Util.isAnyNullOrEmpty(applicationName, birthrightTableName, newEntitlementName, newRuleAsString,
                            oldEntitlementName, oldRuleAsString, ruleId)) {

                // Populate the default error message for any of the keys that cannot have null or empty values
                String logError = "Key '%s' cannot have a null or empty value";
                if (identityAttributes == null || identityAttributes.isEmpty())
                    log.error(String.format(logError, THD_Constants_Birthright.BIRTHRIGHT_IDENTITY_ATTRIBUTES_KEY));
                if (Util.isNullOrEmpty(applicationName))
                    log.error(String.format(logError, THD_Constants_Birthright.APPLICATION_NAME_KEY));
                if (Util.isNullOrEmpty(birthrightTableName))
                    log.error(String.format(logError, THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY));
                if (Util.isNullOrEmpty(newEntitlementName))
                    log.error(String.format(logError, THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY));
                if (Util.isNullOrEmpty(oldEntitlementName))
                    log.error(String.format(logError, THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY));
                if (Util.isNullOrEmpty(ruleId))
                    log.error(String.format(logError, THD_Constants_Birthright.RULE_ID_KEY));
            } else {
                log.debug("All required keys and values are present in processModifyResults map");

                log.debug("Get the updated list of identities that will need to have the birthright entitlement added");
                List<String> updatedIdentitiesThatWillGainEntitlement = THD_Util_Birthright.getIdentitiesThatWillGainEntitlement(
                        identitiesMeetingNewRuleCriteria, context, applicationName, newEntitlementName);

                log.debug("Get the updated list of identities that will need to have the birthright entitlement removed");
                List<String> updatedIdentitiesThatWillLoseEntitlement = THD_Util_Birthright.getIdentitiesThatWillLoseEntitlement(
                        identitiesMeetingNewRuleCriteria, identitiesMeetingOldRuleCriteria, identityAttributes, context,
                        birthrightTableName, newEntitlementName, oldEntitlementName, ruleId);

                // Transform the lists of identities that gain/lose the entitlement to empty lists if they are null
                if (identitiesThatWillGainEntitlement == null) {
                    identitiesThatWillGainEntitlement = new ArrayList<>();
                }
                if (identitiesThatWillLoseEntitlement == null) {
                    identitiesThatWillLoseEntitlement = new ArrayList<>();
                }

                log.debug("Sort the original and updated lists so they can be compared");
                Collections.sort(identitiesThatWillGainEntitlement);
                Collections.sort(identitiesThatWillLoseEntitlement);
                Collections.sort(updatedIdentitiesThatWillGainEntitlement);
                Collections.sort(updatedIdentitiesThatWillLoseEntitlement);

                log.debug("Compare if either list of identities affected has changed since the approval was processed");
                if (identitiesThatWillGainEntitlement.equals(updatedIdentitiesThatWillGainEntitlement) &&
                        identitiesThatWillLoseEntitlement.equals(updatedIdentitiesThatWillLoseEntitlement)) {
                    log.debug("The identities affected has not changed since the approval, continue with modification");

                    identitiesAffectedHasChanged = false;
                } else {
                    if (!identitiesThatWillGainEntitlement.equals(updatedIdentitiesThatWillGainEntitlement))
                        log.debug("The list of identities that will gain the entitlement has changed");
                    if (!identitiesThatWillLoseEntitlement.equals(updatedIdentitiesThatWillLoseEntitlement))
                        log.debug("The list of identities that will lose the entitlement has changed");
                    log.debug("Must create updated approval to reflect the new identities affected");

                    identitiesAffectedHasChanged = true;

                    log.debug("Get the updated number of identities affected by modifying the current rule");
                    int numIdentitiesMeetingNewRuleCriteria = (identitiesMeetingNewRuleCriteria == null) ? 0
                            : identitiesMeetingNewRuleCriteria.size();
                    int numIdentitiesMeetingOldRuleCriteria = (identitiesMeetingOldRuleCriteria == null) ? 0
                            : identitiesMeetingOldRuleCriteria.size();
                    int numIdentitiesThatWillGainEntitlement = updatedIdentitiesThatWillGainEntitlement.size();
                    int numIdentitiesThatWillLoseEntitlement = updatedIdentitiesThatWillLoseEntitlement.size();

                    log.debug("Update the approval comments using the new numbers of identities affected");
                    String approvalComments = String.format(
                            THD_Constants_Birthright.UPDATED_APPROVAL_COMMENTS_MODIFY_RULE_SHELL, ruleId,
                            newRuleAsString, numIdentitiesMeetingNewRuleCriteria, numIdentitiesThatWillGainEntitlement,
                            oldRuleAsString, numIdentitiesMeetingOldRuleCriteria, numIdentitiesThatWillLoseEntitlement);

                    log.debug("Add the updated values to the processModifyResults map");
                    processModifyResults.put(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY,
                            updatedIdentitiesThatWillGainEntitlement);
                    processModifyResults.put(THD_Constants_Birthright.LOSING_ENTITLEMENT_KEY,
                            updatedIdentitiesThatWillLoseEntitlement);
                    processModifyResults.put(THD_Constants_Birthright.APPROVAL_COMMENTS_KEY, approvalComments);
                }

                log.debug("Always add the results of the comparison to the map so it can be used in the workflow");
                processModifyResults.put(THD_Constants_Birthright.IDENTITIES_AFFECTED_CHANGED_KEY, identitiesAffectedHasChanged);
            }
        }

        log.trace("EXITING modifyRule_CheckIfIdentitiesAffectedChanged()");
        return processModifyResults;
    }

    public static List<ProvisioningPlan> modifyRule_Driver(Map<String, Object> processModifyResults, SailPointContext context)
            throws GeneralException, SQLException {
        setLogLevel();
        log.trace("ENTERING modifyRule_Driver()");

        // List of provisioning plans to be returned if any are required
        List<ProvisioningPlan> plansList = null;

        // Ensure the required keys are present in the processModifyResults map
        if (!processModifyResults.containsKey(THD_Constants_Birthright.APPLICATION_NAME_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.DYNAMIC_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.LOSING_ENTITLEMENT_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.MODIFY_RULE_QUERY_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY) ||
                !processModifyResults.containsKey(THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY)) {

            // Populate the default error message for any of the missing keys
            String logError = "Key '%s' is not present in processModifyResults map";
            if (!processModifyResults.containsKey(THD_Constants_Birthright.APPLICATION_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.APPLICATION_NAME_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.DYNAMIC_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.DYNAMIC_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.LOSING_ENTITLEMENT_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.LOSING_ENTITLEMENT_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.MODIFY_RULE_QUERY_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.MODIFY_RULE_QUERY_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY));
            if (!processModifyResults.containsKey(THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY))
                log.error(String.format(logError, THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY));
        } else {

            // Extract the required values
            List<String> identitiesThatWillGainEntitlement =
                    Util.otol(processModifyResults.get(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY));
            List<String> identitiesThatWillLoseEntitlement =
                    Util.otol(processModifyResults.get(THD_Constants_Birthright.LOSING_ENTITLEMENT_KEY));
            String applicationName     = Util.otos(processModifyResults.get(THD_Constants_Birthright.APPLICATION_NAME_KEY));
            String birthrightTableName = Util.otos(processModifyResults.get(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY));
            String dynamic             = Util.otos(processModifyResults.get(THD_Constants_Birthright.DYNAMIC_KEY));
            String groupAttributeName  = Util.otos(processModifyResults.get(THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY));
            String modifyRuleQuery     = Util.otos(processModifyResults.get(THD_Constants_Birthright.MODIFY_RULE_QUERY_KEY));
            String newEntitlementName  = Util.otos(processModifyResults.get(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY));
            String oldEntitlementName  = Util.otos(processModifyResults.get(THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY));
            String ruleChangelogInsertStatement =
                    Util.otos(processModifyResults.get(THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY));

            // Ensure the values that should never be null were extracted
            if (applicationName == null || birthrightTableName == null || groupAttributeName == null ||
                    modifyRuleQuery == null || newEntitlementName == null || oldEntitlementName == null ||
                    ruleChangelogInsertStatement == null) {

                // Populate the default error message for any of the keys that cannot have null values
                String logError = "Key '%s' cannot have a null value";
                if (applicationName == null)
                    log.error(String.format(logError, THD_Constants_Birthright.APPLICATION_NAME_KEY));
                if (birthrightTableName == null)
                    log.error(String.format(logError, THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY));
                if (groupAttributeName == null)
                    log.error(String.format(logError, THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY));
                if (modifyRuleQuery == null)
                    log.error(String.format(logError, THD_Constants_Birthright.MODIFY_RULE_QUERY_KEY));
                if (newEntitlementName == null)
                    log.error(String.format(logError, THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY));
                if (oldEntitlementName == null)
                    log.error(String.format(logError, THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY));
                if (ruleChangelogInsertStatement == null)
                    log.error(String.format(logError, THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY));
            } else {
                log.debug("All required keys and values are present in processModifyResults map");

                // Maintain a check to see if the modification was successful (avoid nesting)
                boolean successfullyModifiedTable = false;

                // Establish connection to SailPoint database (DO NOT CLOSE)
                Connection dbCxn = context.getJdbcConnection();
                if (dbCxn == null) log.error("Could not connect to SailPoint database");
                else {
                    log.debug("Successfully connected to SailPoint database");

                    // Use the DB MetaData to check if the birthright assignment table exists
                    DatabaseMetaData dbm = dbCxn.getMetaData();
                    ResultSet tables = dbm.getTables(null, null, birthrightTableName, null);
                    if (tables == null)
                        log.error("Could not find birthright table '" + birthrightTableName + "' in the SailPoint database");
                    else {
                        if (!tables.next())
                            log.error("Could not find birthright table '" + birthrightTableName + "' in the SailPoint database");
                        else {
                            log.debug("Successfully found birthright table '" + birthrightTableName + "' in the SailPoint database");

                            // Execute update to modify the rule based on ruleId
                            PreparedStatement prStmt = dbCxn.prepareStatement(modifyRuleQuery);
                            int rowModified = prStmt.executeUpdate();
                            prStmt.close();

                            // Check to see that a single row was modified in the table
                            if (rowModified != 1)
                                log.error("Failed to modify a row in birthright table '" + birthrightTableName + "'");
                            else {
                                log.debug("Successfully modified a row in birthright table '" + birthrightTableName + "'");
                                successfullyModifiedTable = true;
                            }
                        }
                        // Close birthright tables ResultSet if it was not null
                        tables.close();
                    }

                    // If the birthright table was successfully modified update the rule changelog
                    if (!successfullyModifiedTable)
                        log.warn("Unable to modify rule, will not attempt to add a row to the rule changelog");
                    else {

                        // Ensure the rule changelog exists
                        String ruleChangelogTableName = THD_Constants_Birthright.RULE_CHANGELOG_TABLE_NAME;
                        tables = dbm.getTables(null, null, ruleChangelogTableName, null);
                        if (tables == null) log.error("Could not find rule changelog in the SailPoint database");
                        else {
                            if (!tables.next()) log.error("Could not find rule changelog in the SailPoint database");
                            else {
                                log.debug("Successfully found rule changelog in the SailPoint database");

                                // Execute the query to add a row to the rule changelog
                                PreparedStatement prStmt = dbCxn.prepareStatement(ruleChangelogInsertStatement);
                                int rowAdded = prStmt.executeUpdate();
                                prStmt.close();

                                // Check to see that a single row was added to the table
                                if (rowAdded != 1) log.error("Failed to add a row to rule changelog");
                                else log.debug("Successfully added a row to rule changelog");
                            }
                            // Close birthright tables ResultSet if it was not null
                            tables.close();
                        }
                    }
                }

                // If the birthright table was successfully modified update the affected identities
                if (!successfullyModifiedTable)
                    log.warn("Unable to modify rule, will not attempt to add/remove entitlement to identities");
                else {

                    // Provisioning Plans mapped to identities if any are required
                    Map<String, ProvisioningPlan> plansMap = new HashMap<>();

                    // Check to see if any identities need an entitlement added
                    if ((identitiesThatWillGainEntitlement == null || identitiesThatWillGainEntitlement.isEmpty()))
                        log.debug("No identities require an entitlement be added to their account");
                    else {

                        // Add the entitlement to all the identities that require it
                        for (String identityName : identitiesThatWillGainEntitlement) {
                            log.debug("Adding entitlement '" + newEntitlementName + "' to Identity '" + identityName + "'");

                            // Get the nativeIdentity on the existing account
                            Link identityApplicationLink = THD_Util_SearchUtil.getAccount(context, identityName, applicationName);
                            if (identityApplicationLink == null)
                                log.error("Failed to get identityApplicationLink when attempting to modify account");
                            else {
                                String nativeIdentity = identityApplicationLink.getNativeIdentity();

                                // Variables used to update the entitlement (if needed) and create plan
                                Identity identityObject = context.getObjectByName(Identity.class, identityName);
                                String updatedEntitlementName;

                                // If the rule is dynamic update the entitlement name based on the identity
                                if (dynamic != null && dynamic.equalsIgnoreCase(THD_Constants_General.TRUE)) {
                                    log.debug("Rule is dynamic, will update entitlement with identity attributes");

                                    updatedEntitlementName = THD_Util_Birthright.updateDynamicEntitlementName(
                                            identityObject, newEntitlementName);
                                }
                                else updatedEntitlementName = newEntitlementName;

                                // Check if the updatedEntitlementName is null
                                if (Util.isNullOrEmpty(updatedEntitlementName))
                                    log.error("Failed to create updatedEntitlementName using identity attributes");
                                else {
                                    log.debug("Creating plan and account request with entitlement name '" +
                                            updatedEntitlementName + "'");

                                    // Variables needed to create the plan
                                    List<ProvisioningPlan.AccountRequest> accountRequests = new ArrayList<>();
                                    ProvisioningPlan plan = new ProvisioningPlan();

                                    // Create the account request
                                    ProvisioningPlan.AccountRequest acctReq = new ProvisioningPlan.AccountRequest();
                                    acctReq.setApplication(applicationName);
                                    acctReq.setNativeIdentity(nativeIdentity);
                                    acctReq.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
                                    acctReq.add(new ProvisioningPlan.AttributeRequest(groupAttributeName,
                                            ProvisioningPlan.Operation.Add, newEntitlementName));

                                    // Populate the plan
                                    accountRequests.add(acctReq);
                                    plan.setAccountRequests(accountRequests);
                                    plan.setIdentity(identityObject);
                                    plan.setNativeIdentity(identityName);

                                    // Add the plan to the overall map of plans by identity
                                    plansMap.put(identityName, plan);
                                }
                            }
                        }
                    }

                    // Check to see if any identities need an entitlement removed
                    if (identitiesThatWillLoseEntitlement == null || identitiesThatWillLoseEntitlement.isEmpty())
                        log.debug("No identities require an entitlement be removed from their account");
                    else {

                        // Remove the entitlement from all the identities that require it
                        for (String identityName : identitiesThatWillLoseEntitlement) {
                            log.debug("Removing entitlement '" + oldEntitlementName + "' from Identity '" + identityName + "'");

                            // Get the nativeIdentity on the existing account
                            Link identityApplicationLink = THD_Util_SearchUtil.getAccount(context, identityName, applicationName);
                            if (identityApplicationLink == null)
                                log.error("Failed to get identityApplicationLink when attempting to modify account");
                            else {
                                String nativeIdentity = identityApplicationLink.getNativeIdentity();

                                // Variables used to update the entitlement (if needed) and create plan
                                Identity identityObject = context.getObjectByName(Identity.class, identityName);
                                String updatedEntitlementName;

                                // If the rule is dynamic update the entitlement name based on the identity
                                if (dynamic != null && dynamic.equalsIgnoreCase(THD_Constants_General.TRUE)) {
                                    log.debug("Rule is dynamic, will update entitlement with identity attributes");

                                    updatedEntitlementName = THD_Util_Birthright.updateDynamicEntitlementName(
                                            identityObject, newEntitlementName);
                                }
                                else updatedEntitlementName = newEntitlementName;

                                // Check if the updatedEntitlementName is null
                                if (Util.isNullOrEmpty(updatedEntitlementName))
                                    log.error("Failed to create updatedEntitlementName using identity attributes");
                                else {
                                    log.debug("Creating plan and account request with entitlement name '" +
                                            updatedEntitlementName + "'");

                                    // The identity may already have a plan and list of account requests associated with them
                                    List<ProvisioningPlan.AccountRequest> accountRequests;
                                    ProvisioningPlan plan;

                                    // Check if the identity already has a plan created (is having entitlement added)
                                    if (plansMap.containsKey(identityName)) {
                                        log.debug("Identity '" + identityName + "' is already in plans map, " +
                                                "will add remove entitlement operation to existing plan");

                                        plan = plansMap.get(identityName);
                                        accountRequests = plan.getAccountRequests();
                                    } else {
                                        log.debug("Identity '" + identityName + "' is not in plans map, will create new plan");

                                        plan = new ProvisioningPlan();
                                        accountRequests = new ArrayList<>();
                                        plan.setIdentity(identityObject);
                                        plan.setNativeIdentity(identityName);
                                    }

                                    // Create the account request
                                    ProvisioningPlan.AccountRequest acctReq = new ProvisioningPlan.AccountRequest();
                                    acctReq.setApplication(applicationName);
                                    acctReq.setNativeIdentity(nativeIdentity);
                                    acctReq.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
                                    acctReq.add(new ProvisioningPlan.AttributeRequest(groupAttributeName,
                                            ProvisioningPlan.Operation.Remove, oldEntitlementName));

                                    // Add the newly created account request to the plan
                                    accountRequests.add(acctReq);
                                    plan.setAccountRequests(accountRequests);

                                    // Add the plan to the overall map of plans by identity
                                    plansMap.put(identityName, plan);
                                }
                            }
                        }
                    }

                    // Check to see if any plans were created
                    if (plansMap.isEmpty()) log.debug("No plans were created for adding or removing entitlements");
                    else {
                        log.debug("Plans were created for adding and/or removing entitlements, extracting list");

                        // Populate the list of plans with the values from the plansMap
                        plansList = new ArrayList<>(plansMap.values());
                    }
                }
            }
        }

        // Return the plans with the account requests required if any
        log.trace("EXITING modifyRule_Driver()");
        return plansList;
    }

    public static List<Map<String, Object>> modifyRules_Init(List<Object> rules, SailPointContext context,
                                                             String applicationName, String launcher)
            throws GeneralException, SQLException {
        setLogLevel();
        log.trace("ENTERING modifyRules_Init()");

        // The returnMap that will contain everything once init verifies all input and process executes for each rule
        List<Map<String, Object>> processModifyResults = null;

        // Gates used to avoid over nesting
        boolean initialInputValidated = false;
        int numValidRules = 0;

        // Variables extracted from initial check to be passed to later steps
        String groupAttributeName = null;

        // The error message to return if any are encountered
        String errorMessage = null;

        log.debug("Get the required values from SailPoint Custom Objects");
        List<String> identityAttributes = THD_Util_Birthright.getBirthrightIdentityAttributes(context);
        String birthrightTableName      = THD_Util_Birthright.getBirthrightTableName(context, applicationName);

        // Check if the required values were retrieved from Custom Objects
        if (Util.isNullOrEmpty(birthrightTableName) || identityAttributes == null || identityAttributes.isEmpty()) {
            if (Util.isNullOrEmpty(birthrightTableName))
                log.debug("Failed to retrieve birthright table name");
            if (identityAttributes == null || identityAttributes.isEmpty())
                log.error("Failed to retrieve birthright identity attributes");

            errorMessage = "Unable to retrieve required values from Custom Objects from SailPoint, " +
                    "view log for more details";
        } else {
            log.debug("Successfully retrieved required values from Custom Objects");

            // Ensure everything was retrieved from the input JSON (which is turned into workflow arguments)
            if ((rules == null || rules.isEmpty()) || Util.isNullOrEmpty(applicationName) || Util.isNullOrEmpty(launcher)) {
                if (rules == null || rules.isEmpty()) log.error("Failed to retrieve rules from input JSON");
                if (Util.isNullOrEmpty(applicationName)) log.error("Failed to retrieve application from input JSON");
                if (Util.isNullOrEmpty(launcher)) log.error("Failed to retrieve launcher from input JSON");

                errorMessage = "Failed to retrieve initial required arguments from input JSON, view log for more details";
            } else {
                log.debug("Successfully retrieved initial arguments from JSON input");

                // Ensure the application submitted exists in SailPoint
                Application application = THD_Util_SearchUtil.getApplication(context, applicationName);
                if (application == null) {
                    errorMessage = "Failed to find application '" + applicationName + "' in SailPoint";
                    log.error(errorMessage);
                } else {
                    log.debug("Successfully found application '" + applicationName + "' in SailPoint");

                    // Get the group attribute off of the application (assume only one)
                    if (application.getGroupAttributes() == null || application.getGroupAttributes().isEmpty()) {
                        errorMessage = "Failed to find a group attribute on application '" + applicationName + "'";
                        log.error(errorMessage);
                    } else {
                        groupAttributeName = application.getGroupAttributes().get(0).getName();
                        log.debug("Successfully found group attribute name '" + groupAttributeName + "' on application");

                        // At this point everything possible was checked without looping through the rules
                        initialInputValidated = true;
                    }
                }
            }
        }

        // Check if the initial input was validated, if so proceed with more fetching/validating
        if (initialInputValidated) {

            log.debug("Number of rules submitted for modification: " + rules.size());
            for (int i = 0; i < rules.size(); i++) {
                log.debug("Attempting to validate rule: " + (i + 1));

                // Ensure the current rule is not null
                Map<String, Object> rule = Util.otom(rules.get(i));
                if (rule == null) {
                    errorMessage = "Failed to validate rule, rule must not be null";
                    log.error(errorMessage);
                    break;
                } else {

                    // Ensure the current rule contains the required fields
                    if (!rule.containsKey(THD_Constants_Birthright.ASSIGNMENT_CRITERIA_JSON_FIELD) ||
                            !rule.containsKey(THD_Constants_Birthright.DESCRIPTION_JSON_FIELD) ||
                            !rule.containsKey(THD_Constants_Birthright.DYNAMIC_JSON_FIELD) ||
                            !rule.containsKey(THD_Constants_Birthright.ENTITLEMENT_JSON_FIELD) ||
                            !rule.containsKey(THD_Constants_Birthright.RULE_ID_JSON_FIELD)) {
                        errorMessage = "Failed to retrieve required arguments from input JSON, view log for more details";

                        String logError = "Key '%s' is not present in current rule map";
                        if (!rule.containsKey(THD_Constants_Birthright.ASSIGNMENT_CRITERIA_JSON_FIELD))
                            log.error(String.format(logError, THD_Constants_Birthright.ASSIGNMENT_CRITERIA_JSON_FIELD));
                        if (!rule.containsKey(THD_Constants_Birthright.DESCRIPTION_JSON_FIELD))
                            log.error(String.format(logError, THD_Constants_Birthright.DESCRIPTION_JSON_FIELD));
                        if (!rule.containsKey(THD_Constants_Birthright.DYNAMIC_JSON_FIELD))
                            log.error(String.format(logError, THD_Constants_Birthright.DYNAMIC_JSON_FIELD));
                        if (!rule.containsKey(THD_Constants_Birthright.ENTITLEMENT_JSON_FIELD))
                            log.error(String.format(logError, THD_Constants_Birthright.ENTITLEMENT_JSON_FIELD));
                        if (!rule.containsKey(THD_Constants_Birthright.RULE_ID_JSON_FIELD))
                            log.error(String.format(logError, THD_Constants_Birthright.RULE_ID_JSON_FIELD));
                        break;
                    } else {

                        // Extract the required values for validation from the current rule
                        Map<String, Object> assignmentCriteria =
                                Util.otom(rule.get(THD_Constants_Birthright.ASSIGNMENT_CRITERIA_JSON_FIELD));
                        String dynamic         = Util.otos(rule.get(THD_Constants_Birthright.DYNAMIC_JSON_FIELD));
                        String entitlementName = Util.otos(rule.get(THD_Constants_Birthright.ENTITLEMENT_JSON_FIELD));
                        String ruleId          = Util.otos(rule.get(THD_Constants_Birthright.RULE_ID_JSON_FIELD));

                        // Ensure all additional required values were retrieved from each rule input JSON
                        if (assignmentCriteria == null || assignmentCriteria.isEmpty() ||
                                Util.isNullOrEmpty(entitlementName) ||
                                Util.isNullOrEmpty(ruleId)) {
                            errorMessage = "Failed to retrieve required arguments from input JSON, view log for more details";

                            if (assignmentCriteria == null || assignmentCriteria.isEmpty())
                                log.error("Failed to retrieve assignment criteria from current rule");
                            if (Util.isNullOrEmpty(entitlementName))
                                log.error("Failed to retrieve entitlement from current rule");
                            if (Util.isNullOrEmpty(ruleId)) log.error("Failed to retrieve ruleId from current rule");
                            break;
                        } else {

                            // Ensure the assignmentCriteria map has valid input using the birthright identity attributes
                            if (!THD_Util_Birthright.verifyAssignmentCriteria(identityAttributes, assignmentCriteria)) {
                                errorMessage = "Failed to validate assignmentCriteria on current rule, " +
                                        "view log for more details";
                                log.error(errorMessage);
                                break;
                            } else {

                                // Check if the entitlement being modified is dynamic or not
                                if (dynamic != null && dynamic.equalsIgnoreCase(THD_Constants_General.TRUE)) {
                                    log.debug("Entitlement to be modified is dynamic, rule has been validated");

                                    // Since dynamic is true the initial input has been validated
                                    numValidRules++;
                                }

                                // If the entitlement is not dynamic check if it exists in SailPoint
                                else {
                                    ManagedAttribute entitlement = THD_Util_SearchUtil.getManagedAttribute(
                                            context, applicationName, groupAttributeName, entitlementName);
                                    if (entitlement == null) {
                                        errorMessage = "Failed to find entitlement '" + entitlementName + "' in SailPoint";
                                        log.error(errorMessage);
                                        break;
                                    } else {
                                        log.debug("Successfully found entitlement '" + entitlementName + "' in SailPoint");
                                        log.debug("Current rule has been validated, updating number validated thus far");
                                        numValidRules++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Check that everything in the JSON input was validated, if so begin to process the request
        if (initialInputValidated && numValidRules == rules.size()) {
            log.debug("All input has been validated, beginning to process request");
            processModifyResults = modifyRules_Process(
                    rules, identityAttributes, context, applicationName, birthrightTableName, groupAttributeName, launcher);
        }

        // Check if any errors were encountered
        if (errorMessage != null) {
            log.debug("An error was encountered, will return the error message as JSON result");

            // Create the errorMap and add the errorMessage to it so it may be returned in the JSON result
            Map<String, Object> errorMap = new HashMap<>();
            errorMap.put(THD_Constants_Birthright.ERROR_MESSAGE, errorMessage);

            // Add the errorMap to the return list
            processModifyResults = new ArrayList<>();
            processModifyResults.add(errorMap);
        }

        // Return everything done up to the point of approval
        log.trace("EXITING modifyRules_Init()");
        return processModifyResults;
    }

    private static List<Map<String, Object>> modifyRules_Process(List<Object> rules, List<String> identityAttributes,
                                                                 SailPointContext context, String applicationName,
                                                                 String birthrightTableName, String groupAttributeName,
                                                                 String launcher) throws SQLException, GeneralException {
        log.trace("ENTERING modifyRules_Process()");

        // The list that will contain all the result maps of processing the various modifications
        List<Map<String, Object>> processModifyResults = new ArrayList<>();

        // Process all of the already validated rule modifications
        for (int i = 0; i < rules.size(); i++) {
            log.debug("Attempting to process rule: " + (i + 1));

            // Get all required fields, which have already been validated
            Map<String, Object> rule = Util.otom(rules.get(i));

            // From the rule
            Map<String, Object> assignmentCriteria =
                    Util.otom(rule.get(THD_Constants_Birthright.ASSIGNMENT_CRITERIA_JSON_FIELD));
            String description        = Util.otos(rule.get(THD_Constants_Birthright.DESCRIPTION_JSON_FIELD));
            String dynamic            = Util.otos(rule.get(THD_Constants_Birthright.DYNAMIC_JSON_FIELD));
            String newEntitlementName = Util.otos(rule.get(THD_Constants_Birthright.ENTITLEMENT_JSON_FIELD));
            String ruleId             = Util.otos(rule.get(THD_Constants_Birthright.RULE_ID_JSON_FIELD));

            // From the assignmentCriteria
            Map<String, Object> equalsObjectMap    = Util.otom(assignmentCriteria.get(THD_Constants_Birthright.EQUALS_JSON_FIELD));
            Map<String, Object> notEqualsObjectMap = Util.otom(assignmentCriteria.get(THD_Constants_Birthright.NOT_EQUALS_JSON_FIELD));
            String disabled  = Util.otos(assignmentCriteria.get(THD_Constants_Birthright.DISABLED_JSON_FIELD));
            String endsInSUP = Util.otos(assignmentCriteria.get(THD_Constants_Birthright.ENDS_IN_SUP_JSON_FIELD));

            log.debug("Transform the equals and notEquals JSON input maps into types the BirthrightRule constructor can use");
            Map<String, String> equalsMap = equalsObjectMap.entrySet().stream()
                    .collect(Collectors.toMap(Map.Entry::getKey, e ->
                            (e.getValue() == null) ? THD_Constants_General.EMPTY_STRING : Util.otos(e.getValue())));
            Map<String, List<String>> notEqualsMap = notEqualsObjectMap.entrySet().stream()
                    .collect(Collectors.toMap(Map.Entry::getKey, e ->
                            (e.getValue() == null) ? new ArrayList<>() : Util.otol(e.getValue())));

            log.debug("Create the new BirthrightRule Object using what was passed in as JSON");
            THD_BirthrightRule ruleAfterModification = new THD_BirthrightRule(notEqualsMap, equalsMap,
                    applicationName, description, disabled, dynamic, endsInSUP, newEntitlementName, ruleId);

            log.debug("Create the old BirthrightRule Object from the birthright table using the ruleId");
            THD_BirthrightRule ruleBeforeModification = THD_Util_Birthright.getRuleFromRuleId(
                    identityAttributes, context, applicationName, birthrightTableName, ruleId);

            // Get the entitlement from the old rule
            String oldEntitlementName = ruleBeforeModification.getEntitlement();
            log.debug("Entitlement associated with new rule: " + newEntitlementName);
            log.debug("Entitlement associated with old rule: " + oldEntitlementName);

            // Check to see if the BirthrightRule Objects are different
            if (ruleAfterModification.equals(ruleBeforeModification))
                log.warn("The BirthrightRule Object in the database is equal to the one created from input JSON, " +
                        "should not affect any identities");
            /*
            1. Identities only meeting old rule criteria:
                - Must have their birthright entitlements recalculated to check if they get the entitlement associated with
                  the old rule from a different rule as well, in which case they should not have the entitlement removed
            2. Identities only meeting new rule criteria:
                - Must check to see if they already have the entitlement associated with the new rule from somewhere else
                  (Access Request or different birthright rule) so as to avoid trying to add it again
            3. Identities meeting both the new and old rule criteria:
                a. Entitlement has not changed:
                    - No operation necessary (they already had the entitlement from before and keep it in the new rule)
                b. Entitlement has changed:
                    - Follow the logic from steps 1 and 2 for the identity
            */
            log.debug("Get the list of identities that meet the criteria of the new BirthrightRule");
            List<String> identitiesMeetingNewRuleCriteria =
                    ruleAfterModification.getIdentitiesMeetingRuleCriteria(context, groupAttributeName);

            log.debug("Get the list of identities that meet the criteria of the old BirthrightRule");
            List<String> identitiesMeetingOldRuleCriteria =
                    ruleBeforeModification.getIdentitiesMeetingRuleCriteria(context, groupAttributeName);

            log.debug("Get the list of identities that will need to have the birthright entitlement added");
            List<String> identitiesThatWillGainEntitlement = THD_Util_Birthright.getIdentitiesThatWillGainEntitlement(
                    identitiesMeetingNewRuleCriteria, context, applicationName, newEntitlementName);

            log.debug("Get the list of identities that will need to have the birthright entitlement removed");
            List<String> identitiesThatWillLoseEntitlement = THD_Util_Birthright.getIdentitiesThatWillLoseEntitlement(
                    identitiesMeetingNewRuleCriteria, identitiesMeetingOldRuleCriteria, identityAttributes, context,
                    birthrightTableName, newEntitlementName, oldEntitlementName, ruleId);

            // Get the number of identities affected by the modification
            int numIdentitiesMeetingNewRuleCriteria = identitiesMeetingNewRuleCriteria.size();
            int numIdentitiesMeetingOldRuleCriteria = identitiesMeetingOldRuleCriteria.size();
            int numIdentitiesThatWillGainEntitlement = identitiesThatWillGainEntitlement.size();
            int numIdentitiesThatWillLoseEntitlement = identitiesThatWillLoseEntitlement.size();
            log.debug("Number of identities that meet the criteria of the new rule: " + numIdentitiesMeetingNewRuleCriteria);
            log.debug("Number of identities that meet the criteria of the old rule: " + numIdentitiesMeetingOldRuleCriteria);
            log.debug("Number of identities that will gain the entitlement: " + numIdentitiesThatWillGainEntitlement);
            log.debug("Number of identities that will lose the entitlement: " + numIdentitiesThatWillLoseEntitlement);

            log.debug("Create the SQL query that will be used to modify a specific row based on ruleId");
            String modifyRuleQuery = ruleAfterModification.toQuery_Modify(birthrightTableName);

            log.debug("Create the SQL query that will be used to add a row to the rule changelog");
            String operation = THD_Constants_Birthright.MODIFY_RULE_OPERATION;
            String ruleChangelogInsertStatement = THD_Util_Birthright.generateRuleChangelogInsertStatement(
                    launcher, operation, birthrightTableName, ruleAfterModification, ruleBeforeModification);

            log.debug("Create the approval comments that will show a preview of identities affected");
            String newRuleToString  = ruleAfterModification.toString();
            String oldRuleToString  = ruleBeforeModification.toString();
            String approvalComments = String.format(THD_Constants_Birthright.APPROVAL_COMMENTS_MODIFY_RULE_SHELL,
                    newRuleToString, numIdentitiesMeetingNewRuleCriteria, numIdentitiesThatWillGainEntitlement,
                    oldRuleToString, numIdentitiesMeetingOldRuleCriteria, numIdentitiesThatWillLoseEntitlement);

            log.debug("Populate the currentResults map with all Objects that need to be returned");
            Map<String, Object> currentResults = new HashMap<>();
            currentResults.put(THD_Constants_Birthright.APPLICATION_NAME_KEY, applicationName);
            currentResults.put(THD_Constants_Birthright.APPROVAL_COMMENTS_KEY, approvalComments);
            currentResults.put(THD_Constants_Birthright.BIRTHRIGHT_IDENTITY_ATTRIBUTES_KEY , identityAttributes);
            currentResults.put(THD_Constants_Birthright.BIRTHRIGHT_TABLE_NAME_KEY, birthrightTableName);
            currentResults.put(THD_Constants_Birthright.DYNAMIC_KEY, dynamic);
            currentResults.put(THD_Constants_Birthright.GAINING_ENTITLEMENT_KEY, identitiesThatWillGainEntitlement);
            currentResults.put(THD_Constants_Birthright.GROUP_ATTRIBUTE_NAME_KEY, groupAttributeName);
            currentResults.put(THD_Constants_Birthright.LOSING_ENTITLEMENT_KEY, identitiesThatWillLoseEntitlement);
            currentResults.put(THD_Constants_Birthright.MEET_NEW_CRITERIA_KEY, identitiesMeetingNewRuleCriteria);
            currentResults.put(THD_Constants_Birthright.MEET_OLD_CRITERIA_KEY, identitiesMeetingOldRuleCriteria);
            currentResults.put(THD_Constants_Birthright.MODIFY_RULE_QUERY_KEY, modifyRuleQuery);
            currentResults.put(THD_Constants_Birthright.NEW_ENTITLEMENT_NAME_KEY, newEntitlementName);
            currentResults.put(THD_Constants_Birthright.NEW_RULE_AS_STRING_KEY, newRuleToString);
            currentResults.put(THD_Constants_Birthright.NUM_GAINING_ENTITLEMENT_KEY, numIdentitiesThatWillGainEntitlement);
            currentResults.put(THD_Constants_Birthright.NUM_LOSING_ENTITLEMENT_KEY, numIdentitiesThatWillLoseEntitlement);
            currentResults.put(THD_Constants_Birthright.NUM_MEET_NEW_CRITERIA_KEY, numIdentitiesMeetingNewRuleCriteria);
            currentResults.put(THD_Constants_Birthright.NUM_MEET_OLD_CRITERIA_KEY, numIdentitiesMeetingOldRuleCriteria);
            currentResults.put(THD_Constants_Birthright.OLD_ENTITLEMENT_NAME_KEY, oldEntitlementName);
            currentResults.put(THD_Constants_Birthright.OLD_RULE_AS_STRING_KEY, oldRuleToString);
            currentResults.put(THD_Constants_Birthright.RULE_CHANGELOG_INSERT_STATEMENT_KEY, ruleChangelogInsertStatement);
            currentResults.put(THD_Constants_Birthright.RULE_ID_KEY, ruleId);

            log.debug("Add the currentResults map to the overall processModifyResults map");
            processModifyResults.add(currentResults);
        }

        // Return everything that has been done up to the point of approval
        log.trace("EXITING modifyRules_Process()");
        return processModifyResults;
    }

    private static void setLogLevel() {
        log.setLevel(Level.TRACE);
    }
}
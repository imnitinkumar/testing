package com.ey.iiq.object;

import com.ey.iiq.constants.THD_Constants_Birthright;
import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.util.THD_Util_Birthright;
import com.ey.iiq.util.THD_Util_SearchUtil;
import java.util.*;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.ManagedAttribute;
import sailpoint.object.QueryOptions;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

public class THD_BirthrightRule {

    private static final Logger log = Logger.getLogger(THD_BirthrightRule.class);

    private final Map<String, List<String>> notEqualsMap;
    private final Map<String, String> equalsMap;
    private final String application;
    private final String description;
    private final String disabled;
    private final String dynamic;
    private final String endsInSUP;
    private final String entitlement;
    private final String ruleId;

    public THD_BirthrightRule(Map<String, List<String>> notEqualsMap, Map<String, String> equalsMap,
                              String applicationName, String description, String disabled, String dynamic,
                              String endsInSUP, String entitlementName, String ruleId) {
        this.application  = applicationName;
        this.description  = (Util.isNullOrEmpty(description)) ? null : description;
        this.disabled     = (Util.isNullOrEmpty(disabled))    ? null : disabled;
        this.dynamic      = (Util.isNullOrEmpty(dynamic))     ? null : dynamic;
        this.endsInSUP    = (Util.isNullOrEmpty(endsInSUP))   ? null : endsInSUP;
        this.entitlement  = entitlementName;
        this.equalsMap    = equalsMap;
        this.notEqualsMap = notEqualsMap;
        this.ruleId       = ruleId;
    }

    public boolean equals(THD_BirthrightRule other) {
        setLogLevel();
        log.trace("ENTERING equals()");

        // Boolean gates for each step of the equals check
        boolean disabledSame      = false;
        boolean dynamicSame       = false;
        boolean endsInSupSame     = false;
        boolean equalsMapsSame    = false;
        boolean isEqual           = false;
        boolean notEqualsMapsSame = false;

        // Check if all the required unchangeable values equal
        if (!this.ruleId.equals(other.ruleId) || !this.application.equals(other.application))
            log.error("Either ruleId or application has changed");
        else {

            // Check if the entitlement has changed
            if (!this.entitlement.equals(other.entitlement))
                log.debug("The entitlement has changed, not equal");
            else {

                // Check that the equalsMap is the same, set to true initially if it gets this far
                equalsMapsSame = true;
                for (Map.Entry<String, String> thisEqualsMapEntry : this.equalsMap.entrySet()) {
                    String thisKey = thisEqualsMapEntry.getKey();
                    String thisVal = thisEqualsMapEntry.getValue();
                    String otherVal = other.equalsMap.get(thisKey);

                    if (thisVal == null || thisVal.isEmpty()) {
                        if (otherVal != null && !otherVal.isEmpty()) {
                            log.debug("Criteria '" + thisKey +
                                    "' is null or empty in one equalsMap and has a required value in the other");
                            equalsMapsSame = false;
                            break;
                        }
                    } else if (otherVal == null || otherVal.isEmpty()) {
                        log.debug("Criteria '" + thisKey +
                                "' is null or empty in one equalsMap and has a required value in the other");
                        equalsMapsSame = false;
                        break;
                    } else if (!thisVal.equals(otherVal)) {
                        log.debug("Criteria '" + thisKey + "' has changed required value in equalsMap");
                        equalsMapsSame = false;
                        break;
                    }
                }
            }
        }

        // Gate to check if the equalsMaps were checked and determined equal
        if (equalsMapsSame) {

            // Check that the notEqualsMap is the same, set to true initially if it gets this far
            notEqualsMapsSame = true;
            for (Map.Entry<String, List<String>> thisNotEqualsMapEntry : this.notEqualsMap.entrySet()) {
                String thisKey = thisNotEqualsMapEntry.getKey();
                List<String> thisVal = thisNotEqualsMapEntry.getValue();
                List<String> otherVal = other.notEqualsMap.get(thisKey);

                if (thisVal == null || thisVal.isEmpty()) {
                    if (otherVal != null && !otherVal.isEmpty()) {
                        log.debug("Criteria '" + thisKey +
                                "' is null or empty in one notEqualsMap and has a required value in the other");
                        notEqualsMapsSame = false;
                        break;
                    }
                } else if (otherVal == null || otherVal.isEmpty()) {
                    log.debug("Criteria '" + thisKey +
                            "' is null or empty in one notEqualsMap and has a required value in the other");
                    notEqualsMapsSame = false;
                    break;
                } else if (!thisVal.equals(otherVal)) {
                    log.debug("Criteria '" + thisKey + "' has changed required value in notEqualsMap");
                    notEqualsMapsSame = false;
                    break;
                }
            }
        }

        // Gate to check if the notEqualsMaps were checked and determined equal
        if (notEqualsMapsSame) {

            // If this endsInSUP value is null or empty, the other must also be
            if (this.endsInSUP == null || this.endsInSUP.isEmpty()) {
                if (other.endsInSUP == null || other.endsInSUP.isEmpty()) {
                    log.debug("Both endInSUP values are null/empty");
                    endsInSupSame = true;
                } else log.debug("One endsInSUP value is null/empty and the other isn't, not equal");
            } else if (other.endsInSUP == null || other.endsInSUP.isEmpty())
                log.debug("One endsInSUP value is null/empty and the other isn't, not equal");

            // If neither endsInSUP value is null or empty, they must have equal values
            else if (this.endsInSUP.equals(other.endsInSUP)) {
                log.debug("Both endsInSUP values are equal");
                endsInSupSame = true;
            }

            // The endsInSUP values are not equal
            else log.debug("The endsInSUP values are not equal");
        }

        // Gate to check if the endsInSUP values were checked and determined equal
        if (endsInSupSame) {

            // Check if the dynamic values are equal
            boolean otherDynamic = other.dynamic != null && other.dynamic.equalsIgnoreCase(THD_Constants_General.TRUE);
            boolean thisDynamic  = this.dynamic != null && this.dynamic.equalsIgnoreCase(THD_Constants_General.TRUE);
            if (thisDynamic == otherDynamic) {
                log.debug("The dynamic values are equal");
                dynamicSame = true;
            } else {
                log.debug("One dynamic value is equal to true and the other isn't, not equal");
            }
        }

        if (dynamicSame) {

            // Check if the disabled values are equal
            boolean otherDisabled = other.disabled != null && other.disabled.equalsIgnoreCase(THD_Constants_General.TRUE);
            boolean thisDisabled  = this.disabled != null && this.disabled.equalsIgnoreCase(THD_Constants_General.TRUE);
            if (thisDisabled == otherDisabled) {
                log.debug("The disabled values are equal");
                disabledSame = true;
            } else log.debug("One disabled value is equal to true and the other isn't, not equal");
        }

        if (disabledSame) {

            // Check if the description values are equal
            if ((this.description == null && other.description == null) ||
                    (this.description != null && this.description.equals(other.description))) {
                log.debug("All values are equal");
                isEqual = true;
            } else log.debug("The description value has changed, not equal(ish)");
        }

        log.trace("EXITING equals()");
        return isEqual;
    }

    public String getEntitlement() {
        return this.entitlement;
    }

    public List<String> getIdentitiesMeetingRuleCriteria(SailPointContext context, String groupAttributeName)
            throws GeneralException {
        setLogLevel();
        log.trace("ENTERING getIdentitiesMeetingRuleCriteria()");

        // The list of identities that meet this rules criteria
        List<String> identitiesMeetingRuleCriteria = new ArrayList<>();

        // If this rule is disabled no identities should meet the rule criteria
        if (this.disabled != null && this.disabled.equalsIgnoreCase(THD_Constants_General.TRUE))
            log.debug("This rule is disabled, no identities meet the criteria");
        else {
            log.debug("This rule is enabled, creating QueryOptions and Filters to get matching identities");

            // Create the QueryOptions that will fetch the identities meeting the criteria of the rule
            QueryOptions qo = new QueryOptions();

            // Add the filter to only get identities with an account on the target application
            qo.addFilter(Filter.eq(THD_Constants_Birthright.LINK_APPLICATION_NAME, this.application));

            // Iterate through the equalsMap and create a filter for all the criteria that have a required value
            for (Map.Entry<String, String> equalsMapEntry : this.equalsMap.entrySet()) {
                String criteria = equalsMapEntry.getKey();
                String value = equalsMapEntry.getValue();

                // Do not add a filter when the rule criteria has no specified value
                if (Util.isNullOrEmpty(value))
                    log.debug("Do not add equals Filter for criteria '" + criteria +
                            "' to QueryOptions as it has no required value");

                // If the value is equal to the string 'NULL' then the identity's attribute must be null
                else if (value.equals(THD_Constants_General.NULL_AS_STRING)) {
                    log.debug("Adding Filter criteria '" + criteria + "' must be null to QueryOptions");
                    qo.addFilter(Filter.isnull(criteria));
                }

                // In all other cases simply add the normal equals filter
                else {
                    log.debug("Adding Filter criteria '" + criteria + "' must equal '" + value + "' to QueryOptions");
                    qo.addFilter(Filter.eq(criteria, value));
                }
            }

            // Iterate through the notEqualsMap and create a filter for all the criteria that has required NOT values
            for (Map.Entry<String, List<String>> notEqualsMapEntry : this.notEqualsMap.entrySet()) {
                String notCriteria = notEqualsMapEntry.getKey();
                List<String> notValues = notEqualsMapEntry.getValue();

                // Only add a filter when the NOT criteria has specified values
                if (notValues == null || notValues.isEmpty())
                    log.debug("Do not add NOT equals Filter for criteria '" + notCriteria +
                            "' to QueryOptions as it has no required value");
                else {
                    for (String notValue : notValues) {

                        // If the notValue is null or empty something is wrong with the data, send warning
                        if (Util.isNullOrEmpty(notValue))
                            log.warn("Do not add NOT equals Filter for criteria '" + notCriteria +
                                    "' to QueryOptions as it has no required value");

                        // If the notValue is equal to the string 'NULL' then the identity's attribute must NOT be null
                        else if (notValue.equals(THD_Constants_General.NULL_AS_STRING)) {
                            log.debug("Adding Filter criteria '" + notCriteria + "' must NOT be null to QueryOptions");
                            qo.addFilter(Filter.notnull(notCriteria));
                        }

                        // In all other cases simply add the normal not equals filter
                        else {
                            log.debug("Adding Filter criteria '" + notCriteria + "' must NOT equal '" +
                                    notValue + "' to QueryOptions");
                            qo.addFilter(Filter.ne(notCriteria, notValue));
                        }
                    }
                }
            }

            // If endsInSUP is null or empty then no additional filtering is required
            if (this.endsInSUP == null || this.endsInSUP.isEmpty())
                log.debug("Do not add 'endsInSUP' Filter criteria to QueryOptions as it has no required value");

            // If endsInSUP is true then create a LIKE filter to get identities whose jobTitle ends in 'SUP'
            else if (this.endsInSUP.equalsIgnoreCase(THD_Constants_General.TRUE)) {
                log.debug("Adding Filter criteria 'jobTitle' must end in 'SUP'");
                qo.addFilter(Filter.like(THD_Constants_Birthright.JOB_TITLE_ATTRIBUTE,
                        THD_Constants_Birthright.SUP_SUFFIX, Filter.MatchMode.END));
            }

            // If endsInSUP is false then create a NOT LIKE filter to get identities whose jobTitle does not end in 'SUP'
            else if (this.endsInSUP.equalsIgnoreCase(THD_Constants_General.FALSE)) {
                log.debug("Adding Filter criteria 'jobTitle' must NOT end in 'SUP'");
                qo.addFilter(Filter.not(Filter.like(THD_Constants_Birthright.JOB_TITLE_ATTRIBUTE,
                        THD_Constants_Birthright.SUP_SUFFIX, Filter.MatchMode.END)));
            }

            // If endsInSUP was not empty, true, or false it has a bad value (do nothing)
            else log.error("Do not add 'endsInSUP' Filter criteria to QueryOptions as it has an invalid value");

            // The property to extract from the results of the query (name)
            List<String> property = Collections.singletonList(THD_Constants_Birthright.NAME_PROPERTY);

            log.debug("Execute the query to get all the identities that meet the rule criteria");
            Iterator<Object[]> identitiesMeetingRuleCriteriaIterator = context.search(Identity.class, qo, property);
            if (identitiesMeetingRuleCriteriaIterator != null) {
                while (identitiesMeetingRuleCriteriaIterator.hasNext()) {
                    String identityName = Util.otos(identitiesMeetingRuleCriteriaIterator.next()[0]);

                    // If dynamic is true check if the entitlement generated using identity attributes exists
                    if (this.dynamic != null && this.dynamic.equalsIgnoreCase(THD_Constants_General.TRUE)) {
                        log.debug("Checking if the dynamic entitlement name generated using attributes from identity '" +
                                identityName + "' exists in SailPoint");

                        // Get the identity object and use it to get the updatedEntitlementName
                        Identity identityObject = context.getObjectByName(Identity.class, identityName);
                        String updatedEntitlementName =
                                THD_Util_Birthright.updateDynamicEntitlementName(identityObject, this.entitlement);

                        // Check if the updatedEntitlementName value was generated successfully or not
                        if (Util.isNullOrEmpty(updatedEntitlementName))
                            log.debug("Unable to add required identity attribute(s) to entitlement, " +
                                    "identity does not meet criteria");
                        else {

                            // Search for the updated entitlement in SailPoint
                            ManagedAttribute entitlementObject = THD_Util_SearchUtil.getManagedAttribute(
                                    context, this.application, groupAttributeName, updatedEntitlementName);
                            if (entitlementObject == null)
                                log.debug("Generated dynamic entitlement name '" + updatedEntitlementName +
                                        "' does not exist in SailPoint, identity does not meet criteria");
                            else {
                                log.debug("Generated dynamic entitlement name '" + updatedEntitlementName +
                                        "' does exist in SailPoint, identity does meet criteria");

                                identitiesMeetingRuleCriteria.add(identityName);
                            }
                        }
                    }

                    // If dynamic is not true always add the identity
                    else identitiesMeetingRuleCriteria.add(identityName);
                }
            }
        }

        log.trace("EXITING getIdentitiesMeetingRuleCriteria()");
        return identitiesMeetingRuleCriteria;
    }

    public String getNotList() {
        setLogLevel();
        log.trace("ENTERING getNotList()");

        // String representation of the notEqualsMap that will be returned
        String notList = THD_Constants_General.EMPTY_STRING;

        // Transform the notEqualsMap into a single string value
        log.debug("Creating the 'notList', must check all notEquals criteria");
        StringBuilder notListBuilder = null;
        for (Map.Entry<String, List<String>> criteriaValuesPair : notEqualsMap.entrySet()) {
            String notCriteria     = criteriaValuesPair.getKey();
            List<String> notValues = criteriaValuesPair.getValue();

            // Check if the criteria has any NOT values to begin with
            if (notValues == null || notValues.size() == 0)
                log.debug("Criteria '" + notCriteria + "' has no NOT values, skipping");
            else {
                log.debug("Criteria '" + notCriteria + "' has NOT values, continue");

                // Loop through the list of NOT values associated with the current NOT criteria
                for (String notValue : notValues) {

                    // Add the NOT value to the overall notList if the value isn't null
                    if (notValue == null) log.warn("Null value found in criteriaValuePairs, skipping");
                    else {
                        log.debug("Adding NOT value '" + notValue + "' to notListBuilder");

                        // Initialize the string builder and do not add a ',' if this is the first value
                        if (notListBuilder == null) {
                            log.debug("Is the first value in notList, will create the StringBuilder");
                            notListBuilder = new StringBuilder();
                        } else {
                            log.debug("Is not the first value in notList, will append a ','");
                            notListBuilder.append(THD_Constants_General.COMMA);
                        }

                        // Append the pipe-delimited notList criteriaValuePair
                        String notCriteriaValuePair = notCriteria + THD_Constants_General.PIPE + notValue;
                        notListBuilder.append(notCriteriaValuePair);
                    }
                }
            }
        }

        // Check if anything was added to the notListBuilder
        if (notListBuilder == null) log.debug("Nothing was added to notList, returning empty string");
        else {
            notList = notListBuilder.toString();
            log.debug("NotList that was created: " + notList);
        }

        log.trace("EXITING getNotList()");
        return notList;
    }

    public String getRuleId() {
        return this.ruleId;
    }

    private static void setLogLevel(){
        log.setLevel(Level.TRACE);
    }

    public Map<String, Object> toMap() {
        setLogLevel();
        log.trace("ENTERING toMap()");

        log.debug("Construct the assignmentCriteriaMap");
        Map<String, Object> assignmentCriteriaMap = new HashMap<>();
        assignmentCriteriaMap.put(THD_Constants_Birthright.DISABLED_JSON_FIELD, this.disabled);
        assignmentCriteriaMap.put(THD_Constants_Birthright.ENDS_IN_SUP_JSON_FIELD, this.endsInSUP);
        assignmentCriteriaMap.put(THD_Constants_Birthright.EQUALS_JSON_FIELD, this.equalsMap);
        assignmentCriteriaMap.put(THD_Constants_Birthright.NOT_EQUALS_JSON_FIELD, this.notEqualsMap);

        log.debug("Construct the ruleMap");
        Map<String, Object> ruleMap = new HashMap<>();
        ruleMap.put(THD_Constants_Birthright.APPLICATION_JSON_FIELD, this.application);
        ruleMap.put(THD_Constants_Birthright.ASSIGNMENT_CRITERIA_JSON_FIELD, assignmentCriteriaMap);
        ruleMap.put(THD_Constants_Birthright.DESCRIPTION_JSON_FIELD, this.description);
        ruleMap.put(THD_Constants_Birthright.DYNAMIC_JSON_FIELD, this.dynamic);
        ruleMap.put(THD_Constants_Birthright.ENTITLEMENT_JSON_FIELD, this.entitlement);

        // Check if this rule was created with a ruleId (will not have one if first time being added)
        if (Util.isNullOrEmpty(this.ruleId)) log.debug("The current rule has no ruleId, will not add field to ruleMap");
        else {
            log.debug("Adding ruleId to ruleMap");
            ruleMap.put(THD_Constants_Birthright.RULE_ID_JSON_FIELD, this.ruleId);
        }

        log.trace("EXITING toMap()");
        return ruleMap;
    }

    public String toQuery_Add(String birthrightTableName) {
        setLogLevel();
        log.trace("ENTERING toQuery_Add()");

        log.debug("Get the notList from the notEqualsMap");
        String notList = getNotList();

        log.debug("Translate the equalsMap into part of the INSERT clause and part of the VALUES clause");
        StringBuilder insertIdentityAttributesBuilder = new StringBuilder();
        StringBuilder valuesIdentityAttributesBuilder = new StringBuilder();
        for (Map.Entry<String, String> equalsMapEntry : this.equalsMap.entrySet()) {
            String criteria = equalsMapEntry.getKey();
            String value    = equalsMapEntry.getValue();

            // Add the current criteria to the INSERT clause
            insertIdentityAttributesBuilder.append(criteria);
            insertIdentityAttributesBuilder.append(THD_Constants_General.COMMA_WITH_TRAILING_SPACE);

            // Add formatted SQL string to VALUES clause
            String identityAttributeValueSQL = THD_Util_Birthright.toStringSQL(value);
            valuesIdentityAttributesBuilder.append(identityAttributeValueSQL);
            valuesIdentityAttributesBuilder.append(THD_Constants_General.COMMA_WITH_TRAILING_SPACE);
        }
        String insertIdentityAttributesSQL = insertIdentityAttributesBuilder.toString();
        String valuesIdentityAttributesSQL = valuesIdentityAttributesBuilder.toString();
        log.debug("INSERT Identity Attributes SQL:\n" + insertIdentityAttributesSQL);
        log.debug("VALUES Identity Attributes SQL:\n" + valuesIdentityAttributesSQL);

        // Check if any of the required values are null or empty and translate them into SQL strings
        String descriptionSQL = THD_Util_Birthright.toStringSQL(this.description);
        String disabledSQL    = THD_Util_Birthright.toStringSQL(this.disabled);
        String dynamicSQL     = THD_Util_Birthright.toStringSQL(this.dynamic);
        String endsInSUPSQL   = THD_Util_Birthright.toStringSQL(this.endsInSUP);
        String notListSQL     = THD_Util_Birthright.toStringSQL(notList);

        // Get the modify rule query shell and populate it with what has been created/fetched
        String addRuleQuery = String.format(THD_Constants_Birthright.ADD_RULE_QUERY_SHELL, birthrightTableName,
                insertIdentityAttributesSQL, this.entitlement, valuesIdentityAttributesSQL, endsInSUPSQL, notListSQL,
                dynamicSQL, disabledSQL, descriptionSQL);

        log.trace("EXITING toQuery_Add()");
        return addRuleQuery;
    }

    public String toQuery_Modify(String birthrightTableName) {
        setLogLevel();
        log.trace("ENTERING toQuery_Modify()");

        log.debug("Translate the equalsMap into a string representation of part of an SQL SET clause");
        StringBuilder setIdentityAttributesBuilder = new StringBuilder();
        for (Map.Entry<String, String> equalsMapEntry : this.equalsMap.entrySet()) {
            String criteria = equalsMapEntry.getKey();
            String value    = equalsMapEntry.getValue();

            // If the current value is null or empty add formatted SQL string (identityAttribute IS NULL)
            String equalsMapEntrySQL = (Util.isNullOrEmpty(value))
                    ? String.format(THD_Constants_Birthright.COLUMN_EQUALS_NULL, criteria)
                    : String.format(THD_Constants_Birthright.COLUMN_EQUALS_VALUE, criteria, value);

            log.debug("The equalsMapEntrySQL: " + equalsMapEntrySQL);
            setIdentityAttributesBuilder.append(equalsMapEntrySQL);
        }
        String setIdentityAttributesSQL = setIdentityAttributesBuilder.toString();
        log.debug("Set Identity Attributes SQL:\n" + setIdentityAttributesSQL);

        log.debug("Get the notList from the notEqualsMap");
        String notList = getNotList();

        // Check if any of the required values are null or empty and translate them into SQL strings
        String descriptionSQL = THD_Util_Birthright.toStringSQL(this.description);
        String disabledSQL    = THD_Util_Birthright.toStringSQL(this.disabled);
        String dynamicSQL     = THD_Util_Birthright.toStringSQL(this.dynamic);
        String endsInSUPSQL   = THD_Util_Birthright.toStringSQL(this.endsInSUP);
        String notListSQL     = THD_Util_Birthright.toStringSQL(notList);

        // Get the modify rule query shell and populate it with what has been created/fetched
        String modifyRuleQuery = String.format(THD_Constants_Birthright.MODIFY_RULE_QUERY_SHELL, birthrightTableName,
                this.entitlement, setIdentityAttributesSQL, endsInSUPSQL, notListSQL, dynamicSQL, disabledSQL,
                descriptionSQL, this.ruleId);
        log.debug("Modify Query that was generated:\n" + modifyRuleQuery);

        log.trace("EXITING toQuery_Modify()");
        return modifyRuleQuery;
    }

    public String toString() {
        setLogLevel();
        log.trace("ENTERING toString()");

        log.debug("Translate the equalsMap into a string representation with only non-null values");
        StringBuilder equalsCriteriaBuilder = new StringBuilder();
        for (Map.Entry<String, String> equalsMapEntry : this.equalsMap.entrySet()) {
            String criteria = equalsMapEntry.getKey();
            String value    = equalsMapEntry.getValue();

            // If the current value is null or empty do not add anything, otherwise add the criteria-value pair
            if (Util.isNullOrEmpty(value)) {
                log.debug("Not adding criteria '" + criteria + "' to equalsCriteria string");
            } else {
                log.debug("Adding criteria '" + criteria + "' to equalsCriteria string");
                equalsCriteriaBuilder.append(String.format(
                        THD_Constants_Birthright.CRITERIA_EQUALS_VALUE, criteria, value));
            }
        }

        // Also check if endsInSUP needs to be added to the list of required equals values
        if (Util.isNullOrEmpty(this.endsInSUP)) {
            log.debug("Not adding criteria 'endsInSUP' to equalsCriteria string");
        } else {
            log.debug("Adding criteria 'endsInSUP' to equalsCriteria string");
            equalsCriteriaBuilder.append(String.format(THD_Constants_Birthright.CRITERIA_EQUALS_VALUE,
                    THD_Constants_Birthright.ENDS_IN_SUP_COLUMN_NAME, this.endsInSUP));
        }

        // Create the equalsCriteria string based on the StringBuilder
        String equalsCriteria = (equalsCriteriaBuilder.length() == 0)
                ? THD_Constants_Birthright.NO_CRITERIA
                : equalsCriteriaBuilder.toString();

        log.debug("Translate the notEqualsMap into a string representation with only non-null values");
        StringBuilder notEqualsCriteriaBuilder = new StringBuilder();
        for (Map.Entry<String, List<String>> notEqualsMapEntry : this.notEqualsMap.entrySet()) {
            String criteria    = notEqualsMapEntry.getKey();
            List<String> value = notEqualsMapEntry.getValue();

            // If the current value is null or empty do not add anything, otherwise add the criteria-value pair
            if (value == null || value.isEmpty()) {
                log.debug("Not adding criteria '" + criteria + "' to notEqualsCriteria string");
            } else {
                log.debug("Adding criteria '" + criteria + "' to notEqualsCriteria string");
                notEqualsCriteriaBuilder.append(
                        String.format(THD_Constants_Birthright.CRITERIA_EQUALS_VALUE, criteria, value));
            }
        }

        // Create the notEqualsCriteria string based on the StringBuilder
        String notEqualsCriteria = (notEqualsCriteriaBuilder.length() == 0)
                ? THD_Constants_Birthright.NO_CRITERIA
                : notEqualsCriteriaBuilder.toString();

        // Create the final string to be returned
        String ruleToString = String.format(THD_Constants_Birthright.BIRTHRIGHT_RULE_TO_STRING_SHELL, this.application,
                this.entitlement, this.ruleId, this.description, this.disabled, this.dynamic, equalsCriteria, notEqualsCriteria);

        log.debug("Results of rule toString:\n" + ruleToString);
        return ruleToString;
    }
}
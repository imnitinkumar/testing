package com.ey.iiq.util;

import com.ey.iiq.constants.THD_Constants_Birthright;
import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.constants.THD_Constants_LifecycleEvent;
import com.ey.iiq.object.THD_BirthrightRule;
import java.sql.*;
import java.util.*;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

public class THD_Util_Birthright {

    private static final Logger log = Logger.getLogger(THD_Util_Birthright.class);

    public static String generateRuleChangelogInsertStatement(String modifiedBy, String operation, String tableModified,
                                                              THD_BirthrightRule newRule, THD_BirthrightRule oldRule) {
        setLogLevel();
        log.trace("ENTERING generateRuleChangelogInsertStatement()");

        // Transform the newRule into a string that can be used in the database and get the ruleId
        Map<String, Object> newRuleMap = newRule.toMap();
        String newRuleString = newRuleMap.toString();
        String ruleId = newRule.getRuleId();

        // Transform the oldRule into a string if it's not null
        String oldRuleString = THD_Constants_General.EMPTY_STRING;
        if (oldRule == null) {
            log.debug("Do not attempt to transform null oldRule (only required for modify operations)");
        } else {
            Map<String, Object> oldRuleMap = oldRule.toMap();
            oldRuleString = oldRuleMap.toString();
        }

        // Create the query that will add a row to the rule changelog
        String addRuleChangelogQueryShell = THD_Constants_Birthright.ADD_RULE_CHANGELOG_QUERY_SHELL;
        String ruleChangelogInsertStatement = String.format(addRuleChangelogQueryShell,
                modifiedBy, tableModified, operation, ruleId, newRuleString, oldRuleString);
        log.debug("Rule Changelog Insert Statement that was generated:\n" + ruleChangelogInsertStatement);

        log.trace("EXITING generateRuleChangelogInsertStatement()");
        return ruleChangelogInsertStatement;
    }

    public static List<String> getBirthrightAccounts(SailPointContext context, String identityName)
            throws GeneralException {
        setLogLevel();
        log.trace("ENTERING getBirthrightAccounts()");

        // The list of accounts needed
        List<String> birthrightAccounts = null;

        log.debug("Get the list of all birthright applications");
        List<String> birthrightApplications = getBirthrightApplications(context);
        if (birthrightApplications != null) {

            // Iterate through the applications checking if the identity meets the requirements for an account
            for (String birthrightApplication : birthrightApplications) {
                log.debug("Checking if identity meets the requirements for a birthright account on application '" +
                        birthrightApplication + "'");

                // Call the method that compares identity attributes to the required ones in the birthright mapping
                if (identityMeetsBirthrightAccountCriteria(context, birthrightApplication, identityName)) {
                    log.debug("Adding birthright application '" + birthrightApplication +
                            "' to the list of birthright accounts to be returned");

                    // Check if the list has been initialized, if not do so
                    if (birthrightAccounts == null) birthrightAccounts = new ArrayList<>();
                    birthrightAccounts.add(birthrightApplication);
                }
            }
        }

        log.trace("EXITING getBirthrightAccounts()");
        return birthrightAccounts;
    }

    public static List<String> getBirthrightApplications(SailPointContext context) throws GeneralException {
        setLogLevel();
        log.trace("ENTERING getBirthrightApplications()");

        // The list of birthright applications
        List<String> birthrightApplicationNames = null;

        // The name of the Custom Object to fetch
        String customObjectName = THD_Constants_Birthright.CUSTOM_OBJECT_BIRTHRIGHT_MAPPINGS;

        // Get the Custom Object that holds the birthright identity attributes and check to ensure it was retrieved
        Custom customObject = context.getObjectByName(Custom.class, customObjectName);
        if (customObject == null)
            log.error("Failed to retrieve Custom Object '" + customObjectName + "'");
        else {
            log.debug("Successfully retrieved Custom Object '" + customObjectName + "'");

            // Get the list of birthright applications which are all keys
            birthrightApplicationNames = customObject.getAttributes().getKeys();
            if (birthrightApplicationNames == null || birthrightApplicationNames.isEmpty())
                log.error("Failed to retrieve Birthright Applications from Custom Object");
            else
                log.debug("Successfully retrieved Birthright Applications from Custom Object:\n" +
                        birthrightApplicationNames);
        }

        log.trace("EXITING getBirthrightApplications()");
        return birthrightApplicationNames;
    }

    public static List<String> getBirthrightEntitlements(boolean filterEntitlementsNotFoundInIIQ,
                                                         Identity identityObject, List<String> identityAttributes,
                                                         SailPointContext context, String applicationName,
                                                         String birthrightTableName, String groupAttributeName)
            throws GeneralException, SQLException {
        setLogLevel();
        log.trace("ENTERING getBirthrightEntitlements()");

        // List of birthright entitlements as strings to be returned
        List<String> birthrightEntitlements = null;

        // Variables used to create the WHERE clause of the query
        String whereIdentityAttributeSQL;
        StringBuilder whereIdentityAttributesBuilder = new StringBuilder();

        // Translate the identity attributes into a string formatted as part of a SQL WHERE statement
        for (String identityAttribute : identityAttributes) {

            // Get the value associated with the current attribute off of the current identity
            String identityAttributeValue = Util.otos(identityObject.getAttribute(identityAttribute));

            // If the identity attribute value is null then allow for the field to be null or have a value of 'NULL'
            if (identityAttributeValue == null) {
                log.debug("Identity '" + identityObject.getName() + "' has a null value for attribute '" +
                        identityAttribute + "', will set equals part of WHERE condition to be 'NULL'");

                identityAttributeValue = THD_Constants_General.NULL_AS_STRING;
            } else {
                log.debug("Identity '" + identityObject.getName() + "' has a value of '" + identityAttributeValue +
                        "' for attribute '" + identityAttribute);
            }
            whereIdentityAttributeSQL = String.format(THD_Constants_Birthright.AND_COLUMN_IS_NULL_OR_EQUALS_VALUE,
                    identityAttribute, identityAttribute, identityAttributeValue);

            // Add the formatted AND condition to the where clause builder
            whereIdentityAttributesBuilder.append(whereIdentityAttributeSQL);
            whereIdentityAttributesBuilder.append(THD_Constants_General.NEW_LINE);
        }

        log.debug("Translating StringBuilder into a string formatted as part of an SQL WHERE statement");
        String whereIdentityAttributesSQL = whereIdentityAttributesBuilder.toString();
        log.debug("Where Identity Attributes SQL:\n" + whereIdentityAttributesSQL);

        // Determine if the identity has a job title that ends in 'SUP'
        String jobTitle = Util.otos(identityObject.getAttribute(THD_Constants_Birthright.JOB_TITLE_ATTRIBUTE));
        String identityJobTitleEndsInSUP;
        if (jobTitle != null && jobTitle.endsWith(THD_Constants_Birthright.SUP_SUFFIX)) {
            log.debug("Identity's Job Title '" + jobTitle + "' ends in 'SUP'");
            identityJobTitleEndsInSUP = THD_Constants_General.TRUE;
        } else {
            log.debug("Identity's Job Title '" + jobTitle + "' does not end in 'SUP'");
            identityJobTitleEndsInSUP = THD_Constants_General.FALSE;
        }

        // Populate query shell with table name, and desired WHERE values
        String queryShell = THD_Constants_Birthright.GET_ENTITLEMENTS_QUERY_SHELL;
        String entitlementsQuery = String.format(queryShell,
                birthrightTableName, identityJobTitleEndsInSUP, whereIdentityAttributesSQL);
        log.debug("SELECT Query that has been generated:\n" + entitlementsQuery);

        // Establish connection to SailPoint database (DO NOT CLOSE)
        Connection dbCxn = context.getJdbcConnection();
        if (dbCxn == null) {
            log.error("Could not connect to SailPoint database");
        } else {
            log.debug("Successfully connected to SailPoint database");

            // Use the DB MetaData to check if the birthright assignment table exists
            DatabaseMetaData dbm = dbCxn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, birthrightTableName, null);
            if (tables == null) {
                log.error("Could not find birthright table '" + birthrightTableName + "' in the SailPoint database");
            } else {
                if (!tables.next()) {
                    log.error("Could not find birthright table '" + birthrightTableName + "' in the SailPoint database");
                } else {
                    log.debug("Successfully found birthright table '" + birthrightTableName + "' in the SailPoint database");

                    // Execute query to get initial list of entitlements then do additional filtering
                    PreparedStatement prStmt = dbCxn.prepareStatement(entitlementsQuery);
                    ResultSet rs = prStmt.executeQuery();
                    if (rs == null) {
                        log.error("ResultSet from query came back null");
                    } else {
                        log.debug("Successfully retrieved ResultSet using generated query");

                        // Initialize the birthrightEntitlements list as the query was executed successfully
                        birthrightEntitlements = new ArrayList<>();

                        // Variables used to fetch result set from birthright assignment table
                        boolean addEntitlement;
                        int numRows = 0;
                        String dynamic;
                        String entitlementName;
                        String notList;

                        log.debug("Looping through all the rows returned from the table and filtering results further");
                        while (rs.next()) {
                            numRows++;
                            dynamic         = rs.getString(THD_Constants_Birthright.DYNAMIC_COLUMN_NAME);
                            entitlementName = rs.getString(THD_Constants_Birthright.ENTITLEMENT_COLUMN_NAME);
                            notList         = rs.getString(THD_Constants_Birthright.NOT_LIST_COLUMN_NAME);

                            // The entitlement object that will be searched for in SailPoint
                            ManagedAttribute entitlementObject;

                            // If this is a dynamically named entitlement add the required identity attribute(s)
                            if (dynamic != null && dynamic.equalsIgnoreCase(THD_Constants_General.TRUE)) {
                                log.debug("Entitlement has a dynamic naming convention, " +
                                        "will attempt to add the required identity attribute(s)");

                                // Attempt to create the updatedEntitlementName and set it to the current entitlementName
                                String updatedEntitlementName = updateDynamicEntitlementName(identityObject, entitlementName);
                                if (Util.isNullOrEmpty(updatedEntitlementName))
                                    log.debug("Unable to add required identity attribute(s), " +
                                            "will search in SailPoint for entitlement as is");
                                else {
                                    log.debug("Successfully added required identity attribute(s), " +
                                            "will search in SailPoint for updated entitlement");

                                    entitlementName = updatedEntitlementName;
                                }
                            } else
                                log.debug("Entitlement has a static naming convention, will search in SailPoint as is");

                            // If the entitlement does not exist in SailPoint do not attempt to provision it
                            entitlementObject = THD_Util_SearchUtil.getManagedAttribute(
                                    context, applicationName, groupAttributeName, entitlementName);
                            if (entitlementObject == null && filterEntitlementsNotFoundInIIQ) {
                                if (dynamic != null && dynamic.equalsIgnoreCase(THD_Constants_General.TRUE))
                                    log.debug("Encountered dynamic entitlement '" + entitlementName + "' in birthright table '" +
                                            birthrightTableName + "' that does not exist in SailPoint");
                                else log.debug("Encountered static entitlement '" + entitlementName + "' in birthright table '" +
                                        birthrightTableName + "' that does not exist in SailPoint");
                            }

                            // If the entitlement has already been added to the birthright list then ignore it
                            else if (birthrightEntitlements.contains(entitlementName)) {
                                log.debug("Entitlement '" + entitlementName + "' is already in the birthright list, ignore");
                            }

                            // If neither of the previous two are true then begin checking the notList
                            else {
                                log.debug("Entitlement '" + entitlementName +
                                        "' is not in the birthright list and must be checked");

                                // Set the addEntitlement value to true before checking the notList
                                addEntitlement = true;

                                // Check if the identity can NOT have specific values
                                if (notList == null || notList.isEmpty()) {
                                    log.debug("The 'notList' has no values");
                                } else {
                                    log.debug("The 'notList' has values that must be checked against the " +
                                            "identity's attribute values");

                                    // Split the notList (jobtitle|RECSUP,prefLang|en-US) twice to get values
                                    String[] notTypeValuePairs = notList.split(THD_Constants_General.COMMA);
                                    for (String notTypeValuePair : notTypeValuePairs) {
                                        String notType = notTypeValuePair.substring(
                                                0, notTypeValuePair.indexOf(THD_Constants_General.PIPE));
                                        String notValue = notTypeValuePair.substring(
                                                notTypeValuePair.indexOf(THD_Constants_General.PIPE) + 1);

                                        log.debug("Attribute Type: " + notType);
                                        log.debug("Value to NOT have: " + notValue);
                                        log.debug("Identity's value: " + identityObject.getAttribute(notType));

                                        // Check if the value simply cannot be null
                                        if (notValue.equalsIgnoreCase(THD_Constants_General.NULL_AS_STRING) &&
                                                identityObject.getAttribute(notType) == null) {
                                            log.debug("The identity cannot be given the entitlement");
                                            addEntitlement = false;
                                            break;
                                        }

                                        // Check if the identity's attribute type value is equal to the 'notValue'
                                        else if (notValue.equalsIgnoreCase(Util.otos(identityObject.getAttribute(notType)))) {
                                            log.debug("The identity cannot be given the entitlement");
                                            addEntitlement = false;
                                            break;
                                        } else {
                                            log.debug("The identity meets the current not criteria");
                                        }
                                    }
                                }

                                // If addEntitlement is still true then add it
                                if (addEntitlement) {
                                    log.debug("Adding entitlement to birthright entitlement list");
                                    birthrightEntitlements.add(entitlementName);
                                }
                            }
                        }
                        log.debug("Result Set returned " + numRows + " row(s)");
                        log.debug("The identity will be getting " + birthrightEntitlements.size() + " entitlements");

                        // ResultSets must be closed just like JDBC connections and cursors
                        rs.close();
                    }
                    // Close PreparedStatement
                    prStmt.close();
                }
                // Close open birthright tables (will only be one)
                tables.close();
            }
        }

        log.trace("EXITING getBirthrightEntitlements()");
        return birthrightEntitlements;
    }

    public static List<String> getBirthrightIdentityAttributes(SailPointContext context) throws GeneralException {
        setLogLevel();
        log.trace("ENTERING getBirthrightIdentityAttributes()");

        // The list of birthright identity attributes to be returned if retrieved successfully
        List<String> birthrightIdentityAttributes = null;

        // The name of the Custom Object to fetch
        String customObjectName = THD_Constants_Birthright.CUSTOM_OBJECT_BIRTHRIGHT_IDENTITY_ATTRIBUTES;

        // Get the Custom Object that holds the birthright identity attributes and check to ensure it was retrieved
        Custom customObject = context.getObjectByName(Custom.class, customObjectName);
        if (customObject == null)
            log.error("Failed to retrieve Custom Object '" + customObjectName + "'");
        else {
            log.debug("Successfully retrieved Custom Object '" + customObjectName + "'");

            // Get the list of birthright identity attributes which are all keys
            birthrightIdentityAttributes = customObject.getAttributes().getKeys();
            if (birthrightIdentityAttributes == null || birthrightIdentityAttributes.isEmpty())
                log.error("Failed to retrieve Birthright Identity Attributes from Custom Object");
            else
                log.debug("Successfully retrieved Birthright Identity Attributes from Custom Object:\n" +
                        birthrightIdentityAttributes);
        }

        log.trace("EXITING getBirthrightIdentityAttributes()");
        return birthrightIdentityAttributes;
    }

    public static String getBirthrightResourceAttribute(SailPointContext context, String identityAttribute)
            throws GeneralException {
        setLogLevel();

        // The name of the birthright resource attribute to be returned if retrieved successfully
        String birthrightResourceAttribute = null;

        // The name of the Custom Object to fetch
        String customObjectName = THD_Constants_Birthright.CUSTOM_OBJECT_BIRTHRIGHT_IDENTITY_ATTRIBUTES;

        // Get the Custom Object that holds the birthright identity attribute mapping and check to ensure it was retrieved
        Custom customObject = context.getObjectByName(Custom.class, customObjectName);
        if (customObject == null)
            log.error("Failed to retrieve Custom Object '" + customObjectName + "'");
        else {

            // Get the specific attribute required in the map
            birthrightResourceAttribute = customObject.getString(identityAttribute);
            if (Util.isNullOrEmpty(birthrightResourceAttribute)) {
                log.error("Failed to retrieve Birthright Resource Attribute Name from Custom Object using Identity " +
                        "Attribute name '" + identityAttribute + "'");
                birthrightResourceAttribute = "NULL";
            } else
                log.debug("Successfully retrieved Birthright Resource Attribute Name '" + birthrightResourceAttribute +
                        "' from Custom Object using Identity Attribute Name '" + identityAttribute + "'");
        }
        return birthrightResourceAttribute;
    }

    public static String getBirthrightTableName(SailPointContext context, String applicationName) throws GeneralException {
        setLogLevel();
        log.trace("ENTERING getBirthrightTableName()");

        // The name of the birthright table to be returned if retrieved successfully
        String birthrightTableName = null;

        // The name of the Custom Object to fetch
        String customObjectName = THD_Constants_Birthright.CUSTOM_OBJECT_BIRTHRIGHT_MAPPINGS;

        // The name of the Attribute to fetch from the Custom Object
        String attributeName = THD_Constants_Birthright.CUSTOM_ATTRIBUTE_TABLE_NAME;

        // Get the Custom Object that holds the birthright mapping and check to ensure it was retrieved
        Custom customObject = context.getObjectByName(Custom.class, customObjectName);
        if (customObject == null)
            log.error("Failed to retrieve Custom Object '" + customObjectName + "'");
        else {
            log.debug("Successfully retrieved Custom Object '" + customObjectName + "'");

            // Get the birthright mapping from the Custom Object based on the application name
            Map<String, Object> birthrightMapping = Util.otom(customObject.get(applicationName));
            if (birthrightMapping == null)
                log.error("Failed to retrieve Birthright Mapping from Custom Object using Application name '" +
                        applicationName + "'");
            else {
                log.debug("Successfully retrieved Birthright Mapping from Custom Object using Application name '" +
                        applicationName + "'");

                // Get the birthright table name from the birthright mapping
                birthrightTableName = Util.otos(birthrightMapping.get(attributeName));
                if (Util.isNullOrEmpty(birthrightTableName) ||
                        birthrightTableName.equalsIgnoreCase(THD_Constants_LifecycleEvent.NONE_FLAG)) {
                    log.error("Failed to retrieve table name from Birthright Mapping using Attribute name '" +
                            attributeName + "'");

                    // Ensure the table name returned is null if it was null, empty, or 'NONE'
                    birthrightTableName = null;
                }

                // Otherwise the birthright table name was retrieved successfully
                else log.debug("Successfully retrieved table name '" + birthrightTableName +
                        "' from Birthright Mapping using Attribute name '" + attributeName + "'");
            }
        }

        log.trace("EXITING getBirthrightTableName()");
        return birthrightTableName;
    }

    public static List<String> getIdentitiesThatWillGainEntitlement(List<String> identitiesMeetingNewRuleCriteria,
                                                                    SailPointContext context, String applicationName,
                                                                    String entitlementName) throws GeneralException {
        setLogLevel();
        log.trace("ENTERING getIdentitiesThatWillGainEntitlement()");

        // The list of identities that meet the criteria of the rule and do not currently have the entitlement in IIQ
        List<String> identitiesThatWillGainEntitlement = new ArrayList<>();

        // If no identities meet the criteria of the new rule then none will gain the entitlement
        if (identitiesMeetingNewRuleCriteria == null || identitiesMeetingNewRuleCriteria.isEmpty()) {
            log.debug("No identities meet the criteria of the new rule, so none require the entitlement be added");
        } else {

            // Loop through all the identities that meet the criteria of the rule
            for (String identityName : identitiesMeetingNewRuleCriteria) {
                boolean identityAlreadyHasEntitlement = false;
                Link identityApplicationLink = THD_Util_SearchUtil.getAccount(context, identityName, applicationName);

                // Check if the link returned was null
                if (identityApplicationLink == null) {
                    log.debug("Identity '" + identityName + "' does not have a link to application '" + applicationName + "'");
                } else {

                    // Get the entitlements off of the link
                    List<Entitlement> linkEntitlements =
                            identityApplicationLink.getEntitlements(Locale.getDefault(), null);

                    // Check if the list of entitlements associated with the link is null
                    if (linkEntitlements == null) {
                        log.warn("Identity '" + identityName + "' has a null list of entitlements " +
                                "on the link associated with the application '" + applicationName + "'");
                    } else {

                        // Check to see if the identity already has the entitlement they meet the new criteria for
                        for (Entitlement entitlement : linkEntitlements) {

                            // Check if the current entitlement on the link is null
                            if (entitlement == null) {
                                log.warn("Entitlement on link associated with application '" + applicationName + "' is null");
                            } else {
                                String entitlementNameFromLink = entitlement.getAttributeValue();

                                if (entitlementNameFromLink.equals(entitlementName)) {
                                    log.debug("Identity '" + identityName + "' already has the entitlement '" +
                                            entitlementName + "' associated with newly modified rule");

                                    identityAlreadyHasEntitlement = true;
                                    break;
                                }
                            }
                        }
                        // If the identity did not have the entitlement then add them to the list of those that get it
                        if (!identityAlreadyHasEntitlement) {
                            log.debug("Identity '" + identityName + "' needs the entitlement '" +
                                    entitlementName + "' associated with newly modified rule added to their account");
                            identitiesThatWillGainEntitlement.add(identityName);
                        }
                    }
                }
            }
        }

        log.trace("EXITING getIdentitiesThatWillGainEntitlement()");
        return identitiesThatWillGainEntitlement;
    }

    public static List<String> getIdentitiesThatWillLoseEntitlement(List<String> identitiesMeetingNewRuleCriteria,
                                                                    List<String> identitiesMeetingOldRuleCriteria,
                                                                    List<String> identityAttributes,
                                                                    SailPointContext context, String birthrightTableName,
                                                                    String newEntitlementName, String oldEntitlementName,
                                                                    String ruleId)
            throws GeneralException, SQLException {
        setLogLevel();
        log.trace("ENTERING getIdentitiesThatWillLoseEntitlement()");

        // The list of identities that will lose the entitlement associated with the rule
        List<String> identitiesThatWillLoseEntitlement = new ArrayList<>();

        // The list of identities that may lose the entitlement (used to filter down those that meet old criteria)
        List<String> identitiesThatMayLoseEntitlement = null;

        // Check if any identities meet the old criteria
        if (identitiesMeetingOldRuleCriteria == null || identitiesMeetingOldRuleCriteria.isEmpty())
            log.debug("No identities met the criteria of the old rule, so none require entitlement removal");
        else {

            // Check if the entitlement changed since this is a modification
            if (oldEntitlementName.equals(newEntitlementName)) {
                log.debug("Entitlement associated with rule has not been changed");

                // If there are no identities meeting the new criteria then all meeting old may lose the entitlement
                if (identitiesMeetingNewRuleCriteria == null || identitiesMeetingNewRuleCriteria.isEmpty()) {
                    log.debug("No identities meet the new criteria, so all meeting old criteria may lose the entitlement");

                    identitiesThatMayLoseEntitlement = identitiesMeetingOldRuleCriteria;
                } else {
                    log.debug("Check for identities meeting both sets of criteria so they can be excluded from removal");

                    identitiesThatMayLoseEntitlement = new ArrayList<>();

                    // Since the entitlement did not change, get the list of identities that only meet the old criteria
                    for (String identityName : identitiesMeetingOldRuleCriteria) {

                        // If the identity also meets the new criteria they do not need it removed
                        if (identitiesMeetingNewRuleCriteria.contains(identityName))
                            log.debug("Identity '" + identityName + "' does not need to have the old entitlement removed");
                        else {
                            log.debug("Identity '" + identityName + "' may need to have the old entitlement removed");
                            identitiesThatMayLoseEntitlement.add(identityName);
                        }
                    }
                }
            } else {
                log.debug("Entitlement associated with rule has changed, " +
                        "all identities that meet the old criteria may need to have the old entitlement removed");
                identitiesThatMayLoseEntitlement = identitiesMeetingOldRuleCriteria;
            }
        }

        // Check if there are any identities that may still lose the entitlement
        if (identitiesThatMayLoseEntitlement == null || identitiesThatMayLoseEntitlement.isEmpty())
            log.debug("No identities will lose the entitlement, do not connect to database to recalculate any access");
        else {
            log.debug("At least one identity may lose the entitlement, connect to database to recalculate access");

            // Establish connection to SailPoint database (DO NOT CLOSE)
            Connection dbCxn = context.getJdbcConnection();
            if (dbCxn == null) log.error("Could not connect to SailPoint database");
            else {
                log.debug("Successfully connected to SailPoint database");

                // Use the DB MetaData to check if the birthright assignment table exists
                DatabaseMetaData dbm = dbCxn.getMetaData();
                ResultSet tables = dbm.getTables(null, null, birthrightTableName, null);
                if (tables == null)
                    log.error("Could not find birthright table '" + birthrightTableName + "' in the SailPoint database");
                else {
                    if (!tables.next())
                        log.error("Could not find birthright table '" + birthrightTableName + "' in the SailPoint database");
                    else {
                        log.debug("Successfully found birthright table '" + birthrightTableName + "' in the SailPoint database");

                        // Loop through the list of identities that may lose the entitlement and find the ones that will
                        for (String identityName : identitiesThatMayLoseEntitlement) {
                            log.debug("Creating query to check if Identity '" + identityName +
                                    "' still gets the entitlement '" + newEntitlementName + "' from the birthright table");

                            // Get the current identity based on name
                            Identity identityThatMayLoseEntitlement = context.getObjectByName(Identity.class, identityName);

                            // Translate the identity attributes into a string formatted as part of a SQL WHERE statement
                            StringBuilder whereIdentityAttributesBuilder = new StringBuilder();
                            for (String identityAttribute : identityAttributes) {

                                // Get the value associated with the current attribute off of the current identity
                                String identityAttributeValue =
                                        Util.otos(identityThatMayLoseEntitlement.getAttribute(identityAttribute));

                                // If the identity attribute value is null then also look for criteria equal to 'NULL'
                                String whereIdentityAttributeSQL;
                                if (identityAttributeValue == null) {
                                    log.debug("Identity has a null value for attribute '" + identityAttribute);

                                    whereIdentityAttributeSQL =
                                            String.format(THD_Constants_Birthright.AND_COLUMN_IS_NULL_OR_EQUALS_VALUE,
                                                    identityAttribute, identityAttribute, THD_Constants_General.NULL_AS_STRING);
                                } else {
                                    log.debug("Identity has a value of '" + identityAttributeValue + "' for attribute '" +
                                            identityAttribute);

                                    whereIdentityAttributeSQL =
                                            String.format(THD_Constants_Birthright.AND_COLUMN_IS_NULL_OR_EQUALS_VALUE,
                                                    identityAttribute, identityAttribute, identityAttributeValue);
                                }

                                // Add the formatted AND condition to the where clause builder
                                whereIdentityAttributesBuilder.append(whereIdentityAttributeSQL);
                                whereIdentityAttributesBuilder.append(THD_Constants_General.NEW_LINE);
                            }

                            log.debug("Translating StringBuilder into a string formatted as part of an SQL WHERE statement");
                            String whereIdentityAttributesSQL = whereIdentityAttributesBuilder.toString();
                            log.debug("Where Identity Attributes SQL: " + whereIdentityAttributesSQL);

                            // Determine if the identity has a job title that ends in 'SUP'
                            String jobTitle = Util.otos(identityThatMayLoseEntitlement.getAttribute(
                                    THD_Constants_Birthright.JOB_TITLE_ATTRIBUTE));
                            String identityJobTitleEndsInSUP;
                            if (jobTitle != null && jobTitle.endsWith(THD_Constants_Birthright.SUP_SUFFIX)) {
                                log.debug("Identity's Job Title '" + jobTitle + "' ends in 'SUP'");
                                identityJobTitleEndsInSUP = THD_Constants_General.TRUE;
                            } else {
                                log.debug("Identity's Job Title '" + jobTitle + "' does not end in 'SUP'");
                                identityJobTitleEndsInSUP = THD_Constants_General.FALSE;
                            }

                            // Get and populate the query shell that checks if an identity still gets a specific entitlement
                            String queryShell = THD_Constants_Birthright.CHECK_IF_IDENTITY_GETS_ENTITLEMENT_QUERY_SHELL;
                            String ruleQuery = String.format(queryShell, birthrightTableName, ruleId, newEntitlementName,
                                    identityJobTitleEndsInSUP, whereIdentityAttributesSQL);
                            log.debug("Query that has been generated:\n" + ruleQuery);

                            // Execute query to check if the identity is still getting the entitlement from a different rule
                            boolean getsEntitlementFromDifferentRule = false;
                            PreparedStatement prStmt = dbCxn.prepareStatement(ruleQuery);
                            ResultSet rs = prStmt.executeQuery();
                            if (rs == null) log.error("Result Set from query came back null");
                            else {
                                log.debug("Successfully retrieved Result Set using generated query");

                                // Vars used to extract results from ResultSet
                                int numRows = 0;
                                String notList;

                                // Attempt to iterate through the results (there may be none)
                                while (rs.next()) {
                                    numRows++;
                                    notList = rs.getString(THD_Constants_Birthright.NOT_LIST_COLUMN_NAME);

                                    // Check to see if the notList has any values
                                    if (Util.isNullOrEmpty(notList)) {
                                        log.debug("Not list is empty, identity automatically meets criteria");

                                        getsEntitlementFromDifferentRule = true;
                                        break;
                                    } else {
                                        log.debug("Not list is not empty, checking if identity still meets criteria");

                                        // Boolean used to determine if the identity meets all of the NOT criteria
                                        boolean meetsNotCriteria = true;

                                        // Split notList twice to get key-value pairs
                                        String[] notCriteriaValuePairs = notList.split(THD_Constants_General.COMMA);
                                        for (String notCriteriaValuePair : notCriteriaValuePairs) {
                                            String notCriteria = notCriteriaValuePair.substring(
                                                    0, notCriteriaValuePair.indexOf(THD_Constants_General.PIPE));
                                            String notValue = notCriteriaValuePair.substring(
                                                    notCriteriaValuePair.indexOf(THD_Constants_General.PIPE) + 1);

                                            // Get the value the current identity has associated with the NOT criteria
                                            String identityAttributeValue =
                                                    Util.otos(identityThatMayLoseEntitlement.getAttribute(notCriteria));

                                            log.debug("Attribute that cannot have a certain value: " + notCriteria);
                                            log.debug("Value the identity cannot have: " + notValue);
                                            log.debug("Identity has the value: " + identityAttributeValue);

                                            // Check if the current criteria value must be equal to null
                                            if (notValue.equals(THD_Constants_General.NULL_AS_STRING)) {
                                                if (identityAttributeValue != null) {
                                                    log.debug("Rule required a null value for identity attribute '" + notCriteria +
                                                            "' and the identity has a value that is not null, fails criteria");
                                                    meetsNotCriteria = false;
                                                    break;
                                                }
                                            } else {
                                                // If the identity has the same attribute value as the NOT value then it fails
                                                if (identityAttributeValue != null && identityAttributeValue.equals(notValue)) {
                                                    log.debug("Rule required identity attribute '" + notCriteria +
                                                            "' to NOT be equal to '" + notValue + "', fails criteria");
                                                    meetsNotCriteria = false;
                                                    break;
                                                }
                                            }
                                        }
                                        // Check to see if the identity met all of the NOT criteria
                                        if (meetsNotCriteria) {
                                            log.debug("Identity met all of the NOT criteria, meets overall rule criteria");
                                            getsEntitlementFromDifferentRule = true;
                                            break;
                                        }
                                    }
                                }
                                log.debug("Read " + numRows + " row(s) from Result Set");

                                // Close query ResultSet if it was not null
                                rs.close();
                            }
                            // Close PreparedStatement
                            prStmt.close();

                            // Check to see if the identity got the desired entitlement from a different rule
                            if (getsEntitlementFromDifferentRule)
                                log.debug("Identity '" + identityName +
                                        "' still gets the entitlement from a different birthright rule, do not remove");
                            else {
                                log.debug("Identity '" + identityName +
                                        "' does not get the entitlement from a different birthright rule, needs to be removed");
                                identitiesThatWillLoseEntitlement.add(identityName);
                            }
                        }
                    }
                    // Close birthright tables ResultSet if it was not null
                    tables.close();
                }
            }
        }

        log.trace("EXITING getIdentitiesThatWillLoseEntitlement()");
        return identitiesThatWillLoseEntitlement;
    }

    public static boolean getRequiresDisableOnDelete(SailPointContext context, String applicationName)
            throws GeneralException {
        setLogLevel();
        log.trace("ENTERING getRequiresDisableOnDelete()");

        // The name of the birthright table to be returned if retrieved successfully
        boolean requiresDisableOnDelete = false;

        // The name of the Custom Object to fetch
        String customObjectName = THD_Constants_Birthright.CUSTOM_OBJECT_BIRTHRIGHT_MAPPINGS;

        // The name of the Attribute to fetch from the Custom Object
        String attributeName = THD_Constants_Birthright.CUSTOM_ATTRIBUTE_DISABLE_ON_DELETE;

        // Get the Custom Object that holds the birthright mapping and check to ensure it was retrieved
        Custom customObject = context.getObjectByName(Custom.class, customObjectName);
        if (customObject == null)
            log.error("Failed to retrieve Custom Object '" + customObjectName + "'");
        else {
            log.debug("Successfully retrieved Custom Object '" + customObjectName + "'");

            // Get the birthright mapping from the Custom Object based on the application name
            Map<String, Object> birthrightMapping = Util.otom(customObject.get(applicationName));
            if (birthrightMapping == null)
                log.error("Failed to retrieve Birthright Mapping from Custom Object using Application name '" +
                        applicationName + "'");
            else {
                log.debug("Successfully retrieved Birthright Mapping from Custom Object using Application name '" +
                        applicationName + "'");

                // Get the disableOnDelete value from the birthright mapping
                requiresDisableOnDelete = Util.otob(birthrightMapping.get(attributeName));
                log.debug("Successfully retrieved disable on delete value '" + requiresDisableOnDelete +
                        "' from Birthright Mapping using Attribute name '" + attributeName + "'");
            }
        }

        log.trace("EXITING getRequiresDisableOnDelete()");
        return requiresDisableOnDelete;
    }

    public static THD_BirthrightRule getRuleFromRuleId(List<String> identityAttributes, SailPointContext context,
                                                       String applicationName, String birthrightTableName, String ruleId)
            throws GeneralException, SQLException {
        setLogLevel();
        log.trace("ENTERING getRuleFromRuleId()");

        // The birthright rule that will be fetched and created from the table
        THD_BirthrightRule birthrightRule = null;

        // The number of rows fetched from the database should always be 1, use as a gate to prevent over nesting
        int numRows = 0;

        // Vars used to extract rule from ResultSet
        Map<String, String> identityAssignmentCriteriaValuePairs = new HashMap<>();
        String description     = null;
        String disabled        = null;
        String dynamic         = null;
        String endsInSUP       = null;
        String entitlementName = null;
        String notList         = null;

        log.debug("Translate the identity attributes into a string formatted as part of a SQL SELECT statement");
        StringBuilder identityAttributesBuilder = new StringBuilder();
        for (String identityAttribute : identityAttributes) {

            // Create formatted SQL string
            String identityAttributeSQL = THD_Constants_General.TAB + identityAttribute + THD_Constants_General.COMMA +
                    THD_Constants_General.NEW_LINE;
            identityAttributesBuilder.append(identityAttributeSQL);
        }

        String identityAttributesSQL = identityAttributesBuilder.toString();
        log.debug("Identity Attributes SQL: " + identityAttributesSQL);

        // Establish connection to SailPoint database (DO NOT CLOSE)
        Connection dbCxn = context.getJdbcConnection();
        if (dbCxn == null) {
            log.error("Could not connect to SailPoint database");
        } else {
            log.debug("Successfully connected to SailPoint database");

            // Use the DB MetaData to check if the birthright assignment table exists
            DatabaseMetaData dbm = dbCxn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, birthrightTableName, null);
            if (tables == null) {
                log.error("Could not find birthright table '" + birthrightTableName + "' in the SailPoint database");
            } else {
                if (!tables.next()) {
                    log.error("Could not find birthright table '" + birthrightTableName + "' in the SailPoint database");
                } else {
                    log.debug("Successfully found birthright table '" + birthrightTableName + "' in the SailPoint database");

                    // Populate query shell with table name, identity attributes and values, and ruleId
                    String queryShell = THD_Constants_Birthright.GET_RULE_FROM_RULE_ID_QUERY_SHELL;
                    String ruleQuery = String.format(queryShell, identityAttributesSQL, birthrightTableName, ruleId);
                    log.debug("SELECT Query that has been generated:\n" + ruleQuery);

                    // Execute query to get the entitlement name and criteria based on ruleId
                    PreparedStatement prStmt = dbCxn.prepareStatement(ruleQuery);
                    ResultSet rs = prStmt.executeQuery();
                    if (rs == null) {
                        log.error("Result Set from query came back null");
                    } else {
                        log.debug("Successfully retrieved Result Set using generated query");

                        // Attempt to iterate through the results (there should only be 1)
                        while (rs.next()) {
                            numRows++;
                            description     = rs.getString(THD_Constants_Birthright.DESCRIPTION_COLUMN_NAME);
                            disabled        = rs.getString(THD_Constants_Birthright.DISABLED_COLUMN_NAME);
                            dynamic         = rs.getString(THD_Constants_Birthright.DYNAMIC_COLUMN_NAME);
                            endsInSUP       = rs.getString(THD_Constants_Birthright.ENDS_IN_SUP_COLUMN_NAME);
                            entitlementName = rs.getString(THD_Constants_Birthright.ENTITLEMENT_COLUMN_NAME);
                            notList         = rs.getString(THD_Constants_Birthright.NOT_LIST_COLUMN_NAME);

                            // Add the identity attribute result values to the map
                            for (String identityAttribute : identityAttributes) {
                                identityAssignmentCriteriaValuePairs.put(identityAttribute, rs.getString(identityAttribute));
                            }
                        }
                        log.debug("Result Set returned " + numRows + " row(s)");

                        // Close resources that were not null
                        rs.close();
                    }
                    prStmt.close();
                }
                tables.close();
            }
        }

        // Ensure one and only one row was fetched (ruleId should only match one entry)
        if (numRows != 1) {
            log.error("Unable to fetch one and only one row from table");
        } else {
            log.debug("Successfully fetched one and only one row from table");

            // Construct the equals map using the identityAttributes fetched
            Map<String, String> equalsMap = new HashMap<>();
            for (Map.Entry<String, String> criteriaValuePair : identityAssignmentCriteriaValuePairs.entrySet()) {

                // Get the criteria and value from the entry and check for a null value
                String identityAssignmentCriteria = criteriaValuePair.getKey();
                String identityAssignmentCriteriaValue = criteriaValuePair.getValue();
                if (identityAssignmentCriteriaValue == null) {
                    log.debug("Attribute '" + identityAssignmentCriteria + "' can equal anything");
                } else {
                    log.debug("Attribute '" + identityAssignmentCriteria + "' must equal '" +
                            identityAssignmentCriteriaValue + "'");
                }
                equalsMap.put(identityAssignmentCriteria, identityAssignmentCriteriaValue);
            }
            log.debug("The equalsMap after being populated with criteria-value pairs:\n" + equalsMap);

            // Check to see if the notList has any values
            Map<String, List<String>> notEqualsMap = new HashMap<>();
            if (notList == null || notList.equals(THD_Constants_General.EMPTY_STRING)) {
                log.debug("The notList is empty, do not attempt to populate notEqualsMap with any required NOT criteria");
            } else {
                log.debug("The notList is not empty, will attempt to populate notEqualsMap with required NOT criteria");

                // Create notEqualsMap from notList, start by splitting notList twice to get key-value pairs
                String[] notCriteriaValuePairs = notList.split(THD_Constants_General.COMMA);
                for (String notCriteriaValuePair : notCriteriaValuePairs) {
                    String notCriteria =
                            notCriteriaValuePair.substring(0, notCriteriaValuePair.indexOf(THD_Constants_General.PIPE));
                    String notValue =
                            notCriteriaValuePair.substring(notCriteriaValuePair.indexOf(THD_Constants_General.PIPE) + 1);

                    // If the notEqualsMap already contains the criteria, append the value to the value list
                    if (notEqualsMap.containsKey(notCriteria)) {
                        List<String> updatedNotValues = notEqualsMap.get(notCriteria);
                        updatedNotValues.add(notValue);
                        notEqualsMap.put(notCriteria, updatedNotValues);
                    } else {
                        ArrayList<String> newNotValue = new ArrayList<>();
                        newNotValue.add(notValue);
                        notEqualsMap.put(notCriteria, newNotValue);
                    }
                }
                log.debug("The notEqualsMap after being populated with active NOT criteria-value pairs:\n" + notEqualsMap);
            }

            log.debug("Add the identity attributes that have no required NOT criteria to the notEqualsMap");
            for (String notCriteria : identityAttributes) {
                if (notEqualsMap.containsKey(notCriteria)) {
                    log.debug("The identity attribute '" + notCriteria + "' is already in the notEqualsMap");
                } else {
                    notEqualsMap.put(notCriteria, new ArrayList<>());
                }
            }
            log.debug("The notEqualsMap after being populated with identity attributes that have no required NOT criteria:\n" +
                    notEqualsMap);

            birthrightRule = new THD_BirthrightRule(notEqualsMap, equalsMap, applicationName,
                    description, disabled, dynamic, endsInSUP, entitlementName, ruleId);
        }


        // Return the birthrightRule
        log.trace("EXITING getRuleFromRuleId()");
        return birthrightRule;
    }

    /*
    public static List<THD_BirthrightRule> getRulesFromEntitlement(List<String> identityAttributes,
                                                                   SailPointContext context, String applicationName,
                                                                   String birthrightTableName, String entitlementName)
            throws GeneralException, SQLException {
        setLogLevel();
        log.trace("ENTERING getRulesFromEntitlement()");

        // The birthright rules that will be fetched and created
        List<THD_BirthrightRule> birthrightRules = null;

        log.debug("Translate the identity attributes into a string formatted as part of a SQL SELECT statement");
        StringBuilder identityAttributesBuilder = new StringBuilder();
        for (String identityAttribute : identityAttributes) {

            // Create formatted SQL string
            String identityAttributeSQL = THD_Constants_General.TAB + identityAttribute + THD_Constants_General.COMMA +
                    THD_Constants_General.NEW_LINE;
            identityAttributesBuilder.append(identityAttributeSQL);
        }

        String identityAttributesSQL = identityAttributesBuilder.toString();
        log.debug("Identity Attributes SQL: " + identityAttributesSQL);

        // Establish connection to SailPoint database (DO NOT CLOSE)
        Connection dbCxn = context.getJdbcConnection();
        if (dbCxn == null) {
            log.error("Could not connect to SailPoint database");
        } else {
            log.debug("Successfully connected to SailPoint database");

            // Use the DB MetaData to check if the birthright assignment table exists
            DatabaseMetaData dbm = dbCxn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, birthrightTableName, null);
            if (tables == null) {
                log.error("Could not find '" + birthrightTableName + "' in the SailPoint database");
            } else {
                if (!tables.next()) {
                    log.error("Could not find '" + birthrightTableName + "' in the SailPoint database");
                } else {
                    log.debug("Successfully found '" + birthrightTableName + "' in the SailPoint database");

                    // Populate query shell with table name, identity attributes and values, and ruleId
                    String queryShell = THD_Constants_Birthright.GET_RULES_FROM_ENTITLEMENT_QUERY_SHELL;
                    String ruleQuery = String.format(queryShell, identityAttributesSQL, birthrightTableName, entitlementName);
                    log.debug("SELECT Query that has been generated:\n" + ruleQuery);

                    // Execute query to get the entitlement name and criteria based on ruleId
                    PreparedStatement prStmt = dbCxn.prepareStatement(ruleQuery);
                    ResultSet rs = prStmt.executeQuery();
                    if (rs == null) {
                        log.error("Result Set from query came back null");
                    } else {
                        log.debug("Successfully retrieved Result Set using generated query");

                        // Initialize the birthright rules list since the query was successful
                        birthrightRules = new ArrayList<>();

                        // The number of rows fetched from the database
                        int numRows = 0;

                        // Attempt to iterate through the results (there should only be 1)
                        while (rs.next()) {
                            numRows++;

                            // Vars used to extract rule from ResultSet
                            String disabled  = rs.getString(THD_Constants_Birthright.DISABLED_COLUMN_NAME);
                            String endsInSUP = rs.getString(THD_Constants_Birthright.ENDS_IN_SUP_COLUMN_NAME);
                            String notList   = rs.getString(THD_Constants_Birthright.NOT_LIST_COLUMN_NAME);

                            // Construct the equals map using the identityAttributes
                            Map<String, String> equalsMap = new HashMap<>();
                            for (String identityAssignmentCriteria : identityAttributes) {
                                String identityAssignmentCriteriaValue = rs.getString(identityAssignmentCriteria);
                                equalsMap.put(identityAssignmentCriteria, identityAssignmentCriteriaValue);
                            }
                            log.debug("The equalsMap after being populated with criteria-value pairs:\n" + equalsMap);

                            // Check to see if the notList has any values
                            Map<String, List<String>> notEqualsMap = new HashMap<>();
                            if (notList == null || notList.equals(THD_Constants_General.EMPTY_STRING)) {
                                log.debug("The notList is empty, do not attempt to populate notEqualsMap with any " +
                                        "required NOT criteria");
                            } else {
                                log.debug("The notList is not empty, will attempt to populate notEqualsMap with " +
                                        "required NOT criteria");

                                // Create notEqualsMap from notList, start by splitting notList twice to get key-value pairs
                                String[] notCriteriaValuePairs = notList.split(THD_Constants_General.COMMA);
                                for (String notCriteriaValuePair : notCriteriaValuePairs) {
                                    String notCriteria = notCriteriaValuePair
                                            .substring(0, notCriteriaValuePair.indexOf(THD_Constants_General.PIPE));
                                    String notValue = notCriteriaValuePair
                                            .substring(notCriteriaValuePair.indexOf(THD_Constants_General.PIPE) + 1);

                                    // If the notEqualsMap already contains the criteria, append the value to the value list
                                    if (notEqualsMap.containsKey(notCriteria)) {
                                        List<String> updatedNotValues = notEqualsMap.get(notCriteria);
                                        updatedNotValues.add(notValue);
                                        notEqualsMap.put(notCriteria, updatedNotValues);
                                    } else {
                                        ArrayList<String> newNotValue = new ArrayList<>();
                                        newNotValue.add(notValue);
                                        notEqualsMap.put(notCriteria, newNotValue);
                                    }
                                }
                                log.debug("The notEqualsMap after being populated with active NOT criteria-value pairs:\n" +
                                        notEqualsMap);
                            }

                            log.debug("Add the identity attributes that have no required NOT criteria to the notEqualsMap");
                            for (String notCriteria : identityAttributes) {
                                if (notEqualsMap.containsKey(notCriteria)) {
                                    log.debug("The identity attribute '" + notCriteria + "' is already in the notEqualsMap");
                                } else {
                                    notEqualsMap.put(notCriteria, new ArrayList<>());
                                }
                            }
                            log.debug("The notEqualsMap after being populated with identity attributes that have no" +
                                    " required NOT criteria:\n" + notEqualsMap);

                            // Create and add the birthright rule to the list of rules to be returned
                            THD_BirthrightRule birthrightRule = new THD_BirthrightRule(notEqualsMap, equalsMap,
                                    applicationName, disabled, endsInSUP, entitlementName, null);

                            birthrightRules.add(birthrightRule);

                        }
                        log.debug("Result Set returned " + numRows + " row(s)");

                        // Close resources that were not null
                        rs.close();
                    }
                    prStmt.close();
                }
                tables.close();
            }
        }

        // Return the birthrightRules
        log.trace("EXITING getRulesFromEntitlement()");
        return birthrightRules;
    }
    */

    public static boolean hasBirthrightTable(SailPointContext context, String applicationName) throws GeneralException {
        setLogLevel();
        log.trace("ENTERING hasBirthrightTable()");

        // The boolean value to return if the application has an associated birthright table on the custom object
        boolean hasBirthrightTable = false;

        // The name of the Custom Object to fetch
        String customObjectName = THD_Constants_Birthright.CUSTOM_OBJECT_BIRTHRIGHT_MAPPINGS;

        // The name of the Attribute to fetch from the Custom Object
        String attributeName = THD_Constants_Birthright.CUSTOM_ATTRIBUTE_TABLE_NAME;

        // Get the Custom Object that holds the birthright table mapping and check to ensure it was retrieved
        Custom customObject = context.getObjectByName(Custom.class, customObjectName);
        if (customObject == null)
            log.error("Failed to retrieve Custom Object '" + customObjectName + "'");
        else {
            log.debug("Successfully retrieved Custom Object '" + customObjectName + "'");

            // Attempt to fetch the birthright mapping based on application name
            Map<String, Object> birthrightMapping = Util.otom(customObject.get(applicationName));
            if (birthrightMapping == null)
                log.debug("Application '" + applicationName + "' is not in the Custom Object of birthright mappings");
            else {
                log.debug("Application '" + applicationName + "' is in the Custom Object of birthright mappings");

                // Attempt to get the birthright table name from the birthright mapping
                String birthrightTableName = Util.otos(birthrightMapping.get(attributeName));
                if (Util.isNullOrEmpty(birthrightTableName) ||
                        birthrightTableName.equalsIgnoreCase(THD_Constants_LifecycleEvent.NONE_FLAG))
                    log.debug("Application does not have an associated birthright table");

                // Otherwise the birthright table name exists
                else {
                    log.debug("Successfully retrieved table name '" + birthrightTableName +
                            "' from Birthright Mapping using Attribute name '" + attributeName + "'");

                    hasBirthrightTable = true;
                }
            }
        }

        log.trace("EXITING hasBirthrightTable()");
        return hasBirthrightTable;
    }

    public static boolean identityMeetsBirthrightAccountCriteria(SailPointContext context, String applicationName,
                                                                 String identityName) throws GeneralException {
        setLogLevel();
        log.trace("ENTERING identityMeetsBirthrightAccountCriteria()");

        // The boolean value to return if the identity meets the criteria for a birthright account on the application
        boolean meetsAccountCriteria = false;

        // Ensure the application exists in SailPoint
        Application application = context.getObjectByName(Application.class, applicationName);
        if (application == null) log.error("Unable to get find Application '" + applicationName + "' in SailPoint");
        else {
            log.debug("Get the birthright rule off of the '" + applicationName + "' Application");

            // The birthright rule on all applications is 'needsJoinerExtendedRule'
            String ruleName = Util.otos(application.getAttributeValue("needsJoinerExtendedRule"));
            if (Util.isNullOrEmpty(ruleName)) log.warn("Unable to retrieve birthright rule name from Application");
            else {
                log.debug("Successfully retrieved birthright rule name '" + ruleName + "' from Application");

                // Fetch the actual rule object using the rule name
                Rule rule = context.getObjectByName(Rule.class, ruleName);
                if (rule == null) log.warn("Unable to retrieve Rule object using rule name '" + ruleName + "'");
                else {
                    log.debug("Successfully retrieved Rule object using rule name '" + ruleName + "'");

                    // Create the rule parameters that will be passed in to the rule
                    Map<String, Object> ruleParams = new HashMap<>();
                    ruleParams.put("context", context);
                    ruleParams.put("identityName", identityName);

                    log.debug("Calling rule to check if identity is eligible for a birthright account");
                    meetsAccountCriteria = Util.otob(context.runRule(rule, ruleParams));
                    if (meetsAccountCriteria)
                        log.debug("Identity meets the criteria for a birthright '" + applicationName + "' account");
                    else log.debug("Identity does not meet the criteria for a birthright '" + applicationName + "' account");
                }
            }
        }

        log.trace("EXITING identityMeetsBirthrightAccountCriteria()");
        return meetsAccountCriteria;
    }

    private static void setLogLevel(){
        log.setLevel(Level.TRACE);
    }

    public static String toStringSQL(String value) {
        return (Util.isNullOrEmpty(value))
                ? THD_Constants_General.NULL_AS_STRING
                : String.format(THD_Constants_Birthright.VALUE_TO_SQL_STRING, value);
    }

    public static String updateDynamicEntitlementName(Identity identityObject, String dynamicEntitlementName) {
        log.trace("ENTERING updateDynamicEntitlementName()");

        // The final entitlement name to return after an identity attribute is added
        String updatedEntitlementName = null;

        // The string that will be added to the entitlement (can be multiple identity attribute values)
        String stringToAddToEntitlement = null;

        // Transform the dynamic entitlement name to lowercase so the contains searches can be done
        dynamicEntitlementName = dynamicEntitlementName.toLowerCase();

        log.debug("Checking what kind of identity attribute needs to be added to the dynamic entitlement");

        // Check if the entitlement contains _district_
        if (dynamicEntitlementName.contains(THD_Constants_Birthright.DYNAMIC_DISTRICT_ATTRIBUTE)) {
            log.debug("Dynamic entitlement contains '" + THD_Constants_Birthright.DYNAMIC_DISTRICT_ATTRIBUTE +
                    "' will add corresponding identity attribute");

            String districtNumber = Util.otos(identityObject.getAttribute(THD_Constants_Birthright.DISTRICT_NUMBER_ATTRIBUTE));
            if (Util.isNotNullOrEmpty(districtNumber)) {
                stringToAddToEntitlement = districtNumber;
            }
        }

        // Check if the entitlement contains _division_
        else if (dynamicEntitlementName.contains(THD_Constants_Birthright.DYNAMIC_DIVISION_ATTRIBUTE)) {
            log.debug("Dynamic entitlement contains '" + THD_Constants_Birthright.DYNAMIC_DIVISION_ATTRIBUTE +
                    "' will attempt to add corresponding identity attributes");

            String divisionName = Util.otos(identityObject.getAttribute(THD_Constants_Birthright.DIVISION_NAME_ATTRIBUTE));
            String divisionNumber = Util.otos(identityObject.getAttribute(THD_Constants_Birthright.DIVISION_NUMBER_ATTRIBUTE));
            if (Util.isNotNullOrEmpty(divisionName) && Util.isNotNullOrEmpty(divisionNumber)) {

                // Replace spaces with underscores in the name and generate the string to add
                divisionName = divisionName.replaceAll(THD_Constants_General.SPACE, THD_Constants_General.UNDERSCORE);
                stringToAddToEntitlement = divisionNumber + THD_Constants_General.UNDERSCORE + divisionName;
            }
        }

        // Check if the entitlement contains _province_
        else if (dynamicEntitlementName.contains(THD_Constants_Birthright.DYNAMIC_PROVINCE_ATTRIBUTE)) {
            log.debug("Dynamic entitlement contains '" + THD_Constants_Birthright.DYNAMIC_PROVINCE_ATTRIBUTE +
                    "' will add corresponding identity attribute");

            String province = Util.otos(identityObject.getAttribute(THD_Constants_Birthright.STATE_PROVINCE_CODE_ATTRIBUTE));
            if (Util.isNotNullOrEmpty(province)) {
                stringToAddToEntitlement = province;
            }
        }

        // Check if the entitlement contains _region_
        else if (dynamicEntitlementName.contains(THD_Constants_Birthright.DYNAMIC_REGION_ATTRIBUTE)) {
            log.debug("Dynamic entitlement contains '" + THD_Constants_Birthright.DYNAMIC_REGION_ATTRIBUTE +
                    "' will attempt to add corresponding identity attributes");

            String regionName = Util.otos(identityObject.getAttribute(THD_Constants_Birthright.REGION_NAME_ATTRIBUTE));
            String regionNumber = Util.otos(identityObject.getAttribute(THD_Constants_Birthright.REGION_NUMBER_ATTRIBUTE));
            if (Util.isNotNullOrEmpty(regionName) && Util.isNotNullOrEmpty(regionNumber)) {

                // Replace spaces with underscores in the name and generate the string to add
                regionName = regionName.replaceAll(THD_Constants_General.SPACE, THD_Constants_General.UNDERSCORE);
                stringToAddToEntitlement = regionNumber + THD_Constants_General.UNDERSCORE + regionName;
            }
        }

        // Check if the entitlement contains _state_
        else if (dynamicEntitlementName.contains(THD_Constants_Birthright.DYNAMIC_STATE_ATTRIBUTE)) {
            log.debug("Dynamic entitlement contains '" + THD_Constants_Birthright.DYNAMIC_STATE_ATTRIBUTE +
                    "' will add corresponding identity attribute");

            String state = Util.otos(identityObject.getAttribute(THD_Constants_Birthright.STATE_PROVINCE_CODE_ATTRIBUTE));
            if (Util.isNotNullOrEmpty(state)) {
                stringToAddToEntitlement = state;
            }
        }

        // Check if the entitlement contains _store_
        else if (dynamicEntitlementName.contains(THD_Constants_Birthright.DYNAMIC_STORE_ATTRIBUTE)) {
            log.debug("Dynamic entitlement contains '" + THD_Constants_Birthright.DYNAMIC_STORE_ATTRIBUTE +
                    "' will add corresponding identity attribute");

            String locationNumber = Util.otos(identityObject.getAttribute(THD_Constants_Birthright.LOCATION_NUMBER_ATTRIBUTE));
            if (Util.isNotNullOrEmpty(locationNumber)) {
                stringToAddToEntitlement = locationNumber;
            }
        }

        // If the entitlement contained none of the previous values attempt to add the location number
        else {
            log.debug("Dynamic entitlement did not contain any of the specified attribute types, " +
                    "will attempt to add identity's location number");

            String locationNumber = Util.otos(identityObject.getAttribute(THD_Constants_Birthright.LOCATION_NUMBER_ATTRIBUTE));
            if (Util.isNotNullOrEmpty(locationNumber)) {
                stringToAddToEntitlement = locationNumber;
            }
        }

        // Check if stringToAddToEntitlement is still null
        if (stringToAddToEntitlement == null) {
            log.debug("Identity does not possess the required attribute(s) to add to the dynamic entitlement");
        } else {
            log.debug("Identity does possess the required attribute(s) to add to the dynamic entitlement");

            // Replace the pipe in the dynamic entitlement with the stringToAddToEntitlement
            updatedEntitlementName = dynamicEntitlementName.replace(THD_Constants_General.PIPE, stringToAddToEntitlement);
            log.debug("The updated entitlement name that was generated:\n" + updatedEntitlementName);
        }

        log.trace("EXITING updateDynamicEntitlementName()");
        return updatedEntitlementName;
    }

    public static boolean verifyAssignmentCriteria(List<String> identityAttributes, Map<String, Object> assignmentCriteria) {
        setLogLevel();
        log.trace("Entering verifyAssignmentCriteria()");

        // The verified status that will be returned
        boolean assignmentCriteriaVerified = false;

        // Ensure the disabled, equals, notEquals, and endsInSUP keys exist in the assignmentCriteria map
        if (!assignmentCriteria.containsKey(THD_Constants_Birthright.DISABLED_JSON_FIELD) ||
                !assignmentCriteria.containsKey(THD_Constants_Birthright.ENDS_IN_SUP_JSON_FIELD) ||
                !assignmentCriteria.containsKey(THD_Constants_Birthright.EQUALS_JSON_FIELD) ||
                !assignmentCriteria.containsKey(THD_Constants_Birthright.NOT_EQUALS_JSON_FIELD)) {
            String logError = "Criteria '%s' is not present in assignment criteria JSON Object";

            if (!assignmentCriteria.containsKey(THD_Constants_Birthright.DISABLED_JSON_FIELD))
                log.error(String.format(logError, THD_Constants_Birthright.DISABLED_JSON_FIELD));
            if (!assignmentCriteria.containsKey(THD_Constants_Birthright.ENDS_IN_SUP_JSON_FIELD))
                log.error(String.format(logError, THD_Constants_Birthright.ENDS_IN_SUP_JSON_FIELD));
            if (!assignmentCriteria.containsKey(THD_Constants_Birthright.EQUALS_JSON_FIELD))
                log.error(String.format(logError, THD_Constants_Birthright.EQUALS_JSON_FIELD));
            if (!assignmentCriteria.containsKey(THD_Constants_Birthright.NOT_EQUALS_JSON_FIELD))
                log.error(String.format(logError, THD_Constants_Birthright.NOT_EQUALS_JSON_FIELD));
        } else {
            log.debug("Successfully checked that all required keys are present in assignment criteria JSON Object");

            // Extract the equalsMap, notEqualsMap, disabled value, and endsInSUP value from the assignmentCriteria map
            Map<String, Object> equalsMap    = Util.otom(assignmentCriteria.get(THD_Constants_Birthright.EQUALS_JSON_FIELD));
            Map<String, Object> notEqualsMap = Util.otom(assignmentCriteria.get(THD_Constants_Birthright.NOT_EQUALS_JSON_FIELD));
            String disabled                  = Util.otos(assignmentCriteria.get(THD_Constants_Birthright.DISABLED_JSON_FIELD));
            String endsInSUP                 = Util.otos(assignmentCriteria.get(THD_Constants_Birthright.ENDS_IN_SUP_JSON_FIELD));

            // Check if disabled has a valid input (null, "", True, False)
            if (Util.isNotNullOrEmpty(disabled) &&
                    !disabled.equalsIgnoreCase(THD_Constants_General.FALSE) &&
                    !disabled.equalsIgnoreCase(THD_Constants_General.TRUE)) {
                log.error("Value '" + disabled + "' in 'disabled' JSON Object must be True, False, null, or empty");
            } else {
                log.debug("Successfully checked that 'disabled' JSON Object has a valid value");

                // Check if endsInSUP has valid input (null, "", True, False)
                if (Util.isNotNullOrEmpty(endsInSUP) &&
                        !endsInSUP.equalsIgnoreCase(THD_Constants_General.FALSE) &&
                        !endsInSUP.equalsIgnoreCase(THD_Constants_General.TRUE)) {
                    log.error("Value '" + endsInSUP + "' in 'endsInSUP' JSON Object must be True, False, null, or empty");
                } else {
                    log.debug("Successfully checked that 'endsInSUP' JSON Object has a valid value");

                    // Ensure that the maps were extracted
                    if (equalsMap == null || equalsMap.isEmpty() || notEqualsMap == null || notEqualsMap.isEmpty()) {
                        if (equalsMap == null || equalsMap.isEmpty())
                            log.error("Unable to retrieve 'Equals' criteria from input JSON");
                        if (notEqualsMap == null || notEqualsMap.isEmpty())
                            log.error("Unable to retrieve 'Not Equals' criteria from input JSON");
                    } else {
                        log.debug("Successfully retrieved equals and notEquals maps from assignment criteria map");

                        // Ensure all birthright identity attributes are present in the equalsMap and notEqualsMap
                        boolean allIdentityAttributesPresent = true;
                        for (String identityAttribute : identityAttributes) {
                            if (!equalsMap.containsKey(identityAttribute)) {
                                log.error("'equals' JSON is missing required identity attribute '" + identityAttribute + "'");
                                allIdentityAttributesPresent = false;
                            }
                            if (!notEqualsMap.containsKey(identityAttribute)) {
                                log.error("'notEquals' JSON is missing required identity attribute '" + identityAttribute + "'");
                                allIdentityAttributesPresent = false;
                            }
                        }
                        if (allIdentityAttributesPresent) {
                            log.debug("Successfully checked that all required identity attributes are present in " +
                                    "both the equalsMap and notEqualsMap");

                            assignmentCriteriaVerified = true;
                        }
                    }
                }
            }
        }

        log.trace("EXITING verifyAssignmentCriteria()");
        return assignmentCriteriaVerified;
    }
}
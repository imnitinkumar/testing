package com.ey.iiq.util;

import com.google.common.primitives.Chars;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import sailpoint.api.SailPointContext;
import sailpoint.object.Custom;
import sailpoint.tools.GeneralException;

/**
 *
 * This utility is used to randomly generate a password, using the inputs from the configuration object. T`he name of the
 * object is defined in CONFIG_NAME. This password utility implements features that the OOB password generation does not,
 * for instance you can define a list of words that cannot exist in the generated password. You can also define in the
 * Custom object, how many of each character type are required in the password, and which characters to use for each character type.
 */
public class THD_Util_PasswordUtil {

  private static final Log log = LogFactory.getLog(THD_Util_PasswordUtil.class);

  private static final Random rand = new SecureRandom();

  /**
   * Private constructor to prevent instantiation of class with static methods only
   */
  private THD_Util_PasswordUtil() {}

  /**
   * Custom configuration object name
   */
  private static final String CONFIG_NAME                  = "THD-Custom-PasswordRequirements";

  /**
   * Attribute names in the configuration object
   */
  private static final String KEY_SPECIAL                  = "special";
  private static final String KEY_NUMERIC                  = "numeric";
  private static final String KEY_CHARSET                  = "charset";
  private static final String KEY_MIN_LENGTH               = "minLength";
  private static final String KEY_MAX_LENGTH               = "maxLength";
  private static final String KEY_UPPERCASE_COUNT          = "uppercaseCount";
  private static final String KEY_LOWERCASE_COUNT          = "lowercaseCount";
  private static final String KEY_NUMERIC_COUNT            = "numericCount";
  private static final String KEY_SPECIAL_COUNT            = "specialCount";
  private static final String KEY_RESTRICTED_WORDS         = "restrictedWords";

  /**
   * This method uses the configuration from a custom object to generate a new password. It uses the special, numeric,
   * uppercase, and lowercase strings as valid characters that can be randomly selected for the password.
   *
   * The uppercaseCount, lowercaseCount, numericCount, and specialCount are used to specify how many of each type of
   * character the password must contain. The method first randomly selects characters for the proper number
   * of required characters. Then it fills in additional random characters until the minLength is reached. After that
   * it shuffles all the characters in the password, so they aren't in a predictable order and then adds a random
   * character to the beginning of the password to ensure the password starts with a character. Finally is loops through
   * the restricted words list and ensures the password does not contain any of the restricted words, if it does the
   * process is started over and a new password is generated.
   *
   * @param context           the current SailPoint connection to the persistent store
   * @return                  a randomly-generated {@code String} password
   * @throws GeneralException thrown if we cannot find the Custom object or there is an error generating the password
   */
  public static String getPassword(SailPointContext context) throws GeneralException {
    log.trace("Enter getPassword");

    String password;

    Custom config = context.getObjectByName(Custom.class, CONFIG_NAME);
    if(config != null) {
      log.trace("Fetch configuration attributes");
      validateInput(config);

      int iterationCount = 0;
      boolean validPassword;
      do {
        password = createPassword(config);
        validPassword = isValidPassword(config, password);
        iterationCount++;
      } while(!validPassword && iterationCount < 10000);

      if(!validPassword) {
        String msg = "No valid password was generated - check configuration " + CONFIG_NAME;
        GeneralException ex = new GeneralException(msg);
        log.error(ex.toString());
        throw ex;
      }
    } else {
      String msg = "Unable to retrieve custom object " + CONFIG_NAME;
      GeneralException ex = new GeneralException(msg);
      log.error(ex.toString());
      throw ex;
    }

    log.trace("Exit getPassword");
    return password;
  }

  /**
   * Validates input from the configuration object and ensures all data is of the proper type and is not null.
   * <p>
   * NOTE: if the Custom config input has a null value for any specified attribute, an exception will be thrown.
   *
   * @param config the configuration object used to retrieve all settings
   */
  private static void validateInput(Custom config) {
    log.trace("Fetch configuration attributes");

    Objects.requireNonNull(config.getString(KEY_SPECIAL), "Attribute " + KEY_SPECIAL + " cannot be null");
    Objects.requireNonNull(config.getString(KEY_NUMERIC), "Attribute " + KEY_NUMERIC + " cannot be null");
    Objects.requireNonNull(config.getString(KEY_CHARSET), "Attribute " + KEY_CHARSET + " cannot be null");
    Objects.requireNonNull(config.getString(KEY_MIN_LENGTH), "Attribute " + KEY_MIN_LENGTH + " cannot be null");
    Objects.requireNonNull(config.getString(KEY_MAX_LENGTH), "Attribute " + KEY_MAX_LENGTH + " cannot be null");
    Objects.requireNonNull(config.getString(KEY_UPPERCASE_COUNT), "Attribute " + KEY_UPPERCASE_COUNT + " cannot be null");
    Objects.requireNonNull(config.getString(KEY_LOWERCASE_COUNT), "Attribute " + KEY_LOWERCASE_COUNT + " cannot be null");
    Objects.requireNonNull(config.getString(KEY_NUMERIC_COUNT), "Attribute " + KEY_NUMERIC_COUNT + " cannot be null");
    Objects.requireNonNull(config.getString(KEY_SPECIAL_COUNT), "Attribute " + KEY_SPECIAL_COUNT + " cannot be null");
    Objects.requireNonNull(config.getString(KEY_RESTRICTED_WORDS), "Attribute " + KEY_RESTRICTED_WORDS + " cannot be null");

    int minLength = Integer.parseInt(config.getString(KEY_MIN_LENGTH));
    int maxLength = Integer.parseInt(config.getString(KEY_MAX_LENGTH));
    int uppercaseCount = Integer.parseInt(config.getString(KEY_UPPERCASE_COUNT));
    int lowercaseCount = Integer.parseInt(config.getString(KEY_LOWERCASE_COUNT));
    int numericCount = Integer.parseInt(config.getString(KEY_NUMERIC_COUNT));
    int specialCount = Integer.parseInt(config.getString(KEY_SPECIAL_COUNT));

    if(!(config.get(KEY_RESTRICTED_WORDS) instanceof List))
      throw new IllegalArgumentException(KEY_RESTRICTED_WORDS + " must be of type List.");

    if(minLength <= 0) throw new IllegalArgumentException(KEY_MIN_LENGTH + " must be greater than 0");
    if(maxLength <= 0) throw new IllegalArgumentException(KEY_MAX_LENGTH + " must be greater than 0");
    if(minLength >= maxLength) throw new IllegalArgumentException(KEY_MIN_LENGTH + " must be less than " + KEY_MAX_LENGTH);

    if(uppercaseCount < 0) throw new IllegalArgumentException(KEY_UPPERCASE_COUNT + " must be greater than or equal to 0");
    if(lowercaseCount < 0) throw new IllegalArgumentException(KEY_LOWERCASE_COUNT + " must be greater than or equal to 0");
    if(numericCount < 0) throw new IllegalArgumentException(KEY_NUMERIC_COUNT + " must be greater than or equal to 0");
    if(specialCount < 0) throw new IllegalArgumentException(KEY_SPECIAL_COUNT + " must be greater than or equal to 0");
  }

  /**
   * Creates a new password using inputs from the configuration object.
   * <p>
   * Randomly determines a password length.
   * Creates all the types of required characters, then creates random characters, from the lists of valid characters,
   * to fill up the rest of the password. Then shuffles the password and starts the password with a lowercase character.
   *
   * @param config    the configuration object used to retrieve all settings
   * @return          a password generated from the constraints laid out in the custom configuration
   */
  private static String createPassword(Custom config) {
    log.trace("Create password");
    StringBuilder passwordStrBld = new StringBuilder();

    int uppercaseCount = Integer.parseInt(config.getString(KEY_UPPERCASE_COUNT));
    int lowercaseCount = Integer.parseInt(config.getString(KEY_LOWERCASE_COUNT));
    int numericCount = Integer.parseInt(config.getString(KEY_NUMERIC_COUNT));
    int specialCount = Integer.parseInt(config.getString(KEY_SPECIAL_COUNT));
    int allCount = uppercaseCount + lowercaseCount + numericCount + specialCount;

    String uppercase = config.getString(KEY_CHARSET).toUpperCase();
    String lowercase = config.getString(KEY_CHARSET).toLowerCase();
    String numeric = config.getString(KEY_NUMERIC);
    String special = config.getString(KEY_SPECIAL);
    String allChars = uppercase + lowercase + numeric + special;

    log.trace("Get uppercase required characters");
    passwordStrBld.append(com.ey.iiq.util.THD_Util_PasswordUtil.getRandomCharacters(uppercase, uppercaseCount));

    log.trace("Get lowercase required characters");
    passwordStrBld.append(com.ey.iiq.util.THD_Util_PasswordUtil.getRandomCharacters(lowercase, lowercaseCount));

    log.trace("Get numeric required characters");
    passwordStrBld.append(com.ey.iiq.util.THD_Util_PasswordUtil.getRandomCharacters(numeric, numericCount));

    log.trace("Get special required characters");
    passwordStrBld.append(com.ey.iiq.util.THD_Util_PasswordUtil.getRandomCharacters(special, specialCount));

    log.trace("Get remaining characters to fill up the password");
    int passwordLength = com.ey.iiq.util.THD_Util_PasswordUtil.getPasswordLength(Integer.parseInt(config.getString(KEY_MIN_LENGTH)), Integer.parseInt(config.getString(KEY_MAX_LENGTH)));
    passwordStrBld.append(com.ey.iiq.util.THD_Util_PasswordUtil.getRandomCharacters(allChars, passwordLength - (allCount - 1)));

    log.trace("Shuffle password");
    char[] passwdChars = passwordStrBld.toString().toCharArray();
    List<Character> characterList = Chars.asList(passwdChars);
    Collections.shuffle(characterList, rand);

    log.trace("Convert shuffled password back to string and start password with a character");
    passwordStrBld = new StringBuilder();
    passwordStrBld.append(lowercase.charAt((Integer.parseInt(RandomStringUtils.randomNumeric(3))) % lowercase.length()));
    for (char c : characterList) {
      passwordStrBld.append(c);
    }

    return passwordStrBld.toString();
  }

  /**
   * Returns true if the password is valid.
   * <p>
   * Ensures the password is a valid length and does not contain any restricted
   * words form the configuration object.
   *
   * @param config    the configuration object used to retrieve all settings
   * @param password  the randomly generated password
   * @return          true if the randomly generated password fits the constraints
   *                  laid out in the configuration object
   */
  private static boolean isValidPassword(Custom config, String password) {
    log.trace("Validate password");

    log.trace("Checking password length");
    if(password.length() > Integer.parseInt(config.getString(KEY_MAX_LENGTH))) {
      log.error("Generated password too long: " + password);
      return false;
    }

    if (password.length() < Integer.parseInt(config.getString(KEY_MIN_LENGTH))) {
      log.error("Generated password too short: " + password);
      return false;
    }

    log.trace("Checking for restricted words");

    List<String> restrictedWords = (List) config.get(KEY_RESTRICTED_WORDS);

    boolean containsWord = false;
    for(String word : restrictedWords) {
      if(password.toUpperCase().contains(word.toUpperCase())) {
        containsWord = true;
        log.error("Invalid Password: " + password + " contains word " + word);
        break;
      }
    }

    return !containsWord;
  }

  private static String getRandomCharacters(String charSet, int numberChars) {
    if(log.isTraceEnabled()) log.trace("enter getRandomCharacters");
    StringBuilder stringBuilder = new StringBuilder();

    if(charSet.length() > 0 && numberChars > 0) {
      for (int i = 0; i < numberChars; i++) {
        stringBuilder.append(charSet.charAt((Integer.parseInt(RandomStringUtils.randomNumeric(3))) % charSet.length()));
      }
    }

    if(log.isTraceEnabled()) log.trace("Exit getRandomCharacters");
    return stringBuilder.toString();
  }

  /**
   * Returns a random password length between minLength and maxLength. Requires the difference between min and max
   * length to be greater than 0.
   *
   * @param minLength the maximum length of the desired password
   * @param maxLength the minimum length of the desired password
   * @return          the actual length of the desired password
   */
  private static int getPasswordLength(int minLength, int maxLength) {
    if(log.isTraceEnabled()) log.trace("enter getPasswordLength");
    int diff = maxLength - minLength;
    if(diff <= 0) throw new IllegalArgumentException(KEY_MAX_LENGTH + " - " + KEY_MIN_LENGTH + " must be greater than 0");

    int length = Integer.parseInt(RandomStringUtils.randomNumeric(3)) % diff;
    length += minLength;

    if(log.isTraceEnabled()) log.trace("exit getPasswordLength");
    return length;
  }
}

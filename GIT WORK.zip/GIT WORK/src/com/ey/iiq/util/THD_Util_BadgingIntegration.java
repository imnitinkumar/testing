package com.ey.iiq.util;

import com.ey.iiq.constants.THD_Constants_BadgingIntegration;
import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import net.schmizz.sshj.transport.verification.PromiscuousVerifier;
import org.apache.log4j.Level;
import sailpoint.api.SailPointContext;
import org.apache.log4j.Logger;

import java.io.*;
import java.lang.Object;
import java.lang.String;

import sailpoint.integration.ProvisioningPlan;
import sailpoint.integration.RequestResult;
import sailpoint.object.*;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

import java.text.SimpleDateFormat;
import java.util.*;

import net.schmizz.sshj.SSHClient;
import net.schmizz.sshj.sftp.SFTPClient;
import net.schmizz.sshj.xfer.FileSystemFile;


public class THD_Util_BadgingIntegration {
    private SailPointContext context;
    static Logger log = Logger.getLogger("com.ey.com.THD-Util-BadgingIntegration");

    private static String getDate(String newDatePattern){
        String standardDatePattern="yyyy-MM-dd-hhmmss";
        log.setLevel(Level.TRACE);
        if (log.isTraceEnabled()) log.trace("Entering getDate");
        String date;
        String pattern = (Util.isNullOrEmpty(newDatePattern)?standardDatePattern:newDatePattern);
        if(log.isDebugEnabled()) log.debug("Date Pattern: " + pattern);
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        date = sdf.format(new Date());
        if (log.isTraceEnabled()) log.trace("Exiting getDate");
        return date;
    }

    private static byte[] getRecordBytes(Identity id, List<String> fileAttributes, List<ProvisioningPlan.AttributeRequest> attReqs) throws GeneralException {
        String record;
        log.setLevel(Level.TRACE);
        if (log.isTraceEnabled()) log.trace("Entering THD-Util-BadgingIntegration-getRecordBytes");
        StringBuilder sb = new StringBuilder();
        String status="";
        String locationNumber="";

        for (ProvisioningPlan.AttributeRequest attReq : attReqs){
            if (THD_Constants_BadgingIntegration.BADGE_STATUS.equalsIgnoreCase(attReq.getName())){
                status=Util.otos(attReq.getValue());
            }
            else if (THD_Constants_IdentityAttributes.LOCATION_NUMBER.equalsIgnoreCase(attReq.getName())){
                locationNumber=Util.otos(attReq.getValue());
            }
            else{
                log.debug("Unknown attribute name: " + attReq.getName());
            }
        }

        for (String i : fileAttributes) {
            sb.append(i);
            sb.append(",");
        }
        sb.append("Date");
        sb.append("\n");

        for (String i : fileAttributes) {
            String attVal;
            if (THD_Constants_IdentityAttributes.STATUS.equalsIgnoreCase(i) && Util.isNotNullOrEmpty(status))
                attVal=status;
            else if (THD_Constants_IdentityAttributes.LOCATION_NUMBER.equalsIgnoreCase(i) && Util.isNotNullOrEmpty(locationNumber))
                attVal=locationNumber;
            else
                attVal=Util.otos(id.getAttribute(i));

            if (attVal==null || attVal.equals("") || attVal.equals("NULL"))
                attVal="\"\"";

            sb.append(attVal);
            sb.append(",");
        }
        sb.append(getDate(THD_Constants_BadgingIntegration.DATE_PATTERN));
        record = sb.toString();

        if (log.isDebugEnabled()) log.debug("Badging Integration Record: "+record);
        byte[]recordBytes = record.getBytes();

        if (log.isTraceEnabled()) log.trace("Exiting THD-Util-BadgingIntegration-getRecordBytes()");

        return recordBytes;
    }


    private static void transferFile(SailPointContext context, Application app, Custom badgingIntegrationMapping, String fileName) throws IOException, GeneralException {
        final SSHClient ssh = new SSHClient();
        log.setLevel(Level.TRACE);
        if (log.isTraceEnabled()) log.trace("Entering THD-Util-BadgingIntegration-writeFile");

        //SFTP connection parameters pulled from application
        final String server = Util.otos(app.getAttributeValue(THD_Constants_BadgingIntegration.SFTP_HOST));
        final int port = Util.otoi(app.getAttributeValue(THD_Constants_BadgingIntegration.SFTP_PORT));
        final String username = Util.otos(app.getAttributeValue(THD_Constants_BadgingIntegration.SFTP_USER));
        final String secret = Util.otos(app.getAttributeValue(THD_Constants_BadgingIntegration.SFTP_USER_PASSWORD));

        //File Paths pulled from custom object
        final String dest = Util.otos(badgingIntegrationMapping.get("SFTP_PATH"));
        final String sourceBase = Util.otos(badgingIntegrationMapping.get("baseFilePath"));

        String fullSourcePath = sourceBase+fileName;
        String fullDestPath = dest+fileName;
        if (log.isDebugEnabled()) log.debug("SERVER: " + server);
        if (log.isDebugEnabled()) log.debug ("PORT: " + Util.itoa(port));
        if (log.isDebugEnabled()) log.debug ("USERNAME: " + username);
        if (log.isDebugEnabled()) log.debug ("DESTINATION PATH: " + dest);

        ssh.addHostKeyVerifier(new PromiscuousVerifier());
        ssh.connect(server, port);

        try {
            ssh.authPassword(username, context.decrypt(secret));
            final SFTPClient sftp = ssh.newSFTPClient();
            try {
                sftp.put(new FileSystemFile(fullSourcePath), fullDestPath);
                if (log.isDebugEnabled()) log.debug("File Transfer Success");
            }
            finally {
                sftp.close();
            }
        } finally {
            ssh.disconnect();
            if (log.isDebugEnabled()) log.trace("Exiting THD-Util-BadgingIntegration-writeFile");

        }
    }

    private static void sendFailoverEmail(Identity id, List<String> toList, String fileName, byte[] recordBytes, SailPointContext context ) throws GeneralException {
        log.setLevel(Level.TRACE);
        if (log.isTraceEnabled()) log.trace("Entering sendFailoverEmail");

        //instantiating objects
        EmailOptions eo = new EmailOptions();
        Map<String,Object> m = new HashMap<String, Object>();
        EmailTemplate et = context.getObject(EmailTemplate.class, THD_Constants_BadgingIntegration.FAILURE_EMAIL_TEMPLATE);
        EmailFileAttachment efa = new EmailFileAttachment();

        //building map with required email template variables
        m.put(THD_Constants_BadgingIntegration.FAILURE_EMAIL_DATE, getDate(THD_Constants_BadgingIntegration.DATE_PATTERN));
        m.put(THD_Constants_BadgingIntegration.FAILURE_EMAIL_UID, Util.otos(id.getAttribute(THD_Constants_IdentityAttributes.UID)));
        m.put(THD_Constants_BadgingIntegration.FAILURE_EMAIL_FIRST_NAME, Util.otos(id.getAttribute(THD_Constants_IdentityAttributes.FIRST_NAME)));
        m.put(THD_Constants_BadgingIntegration.FAILURE_EMAIL_LAST_NAME, Util.otos(id.getAttribute(THD_Constants_IdentityAttributes.LAST_NAME)));
        m.put(THD_Constants_BadgingIntegration.FAILURE_EMAIL_EMAIL, Util.otos(id.getAttribute(THD_Constants_IdentityAttributes.EMAIL)));
        m.put(THD_Constants_BadgingIntegration.FAILURE_EMAIL_USER_TYPE, Util.otos(id.getAttribute(THD_Constants_IdentityAttributes.PERSON_TYPE)));

        //assigning email template variables and recipients
        eo.addVariables(m);
        eo.setTo(toList);

        //constructing and adding file attachment
        efa.setData(recordBytes);
        efa.setMimeType(EmailFileAttachment.MimeType.MIME_CSV);
        efa.setFileName(fileName);
        eo.addAttachment(efa);

        //sending email notification to designated recipients
        context.sendEmailNotification(et,eo);

        if (log.isTraceEnabled()) log.trace("Exiting sendFailoverEmail");
    }

    private static void deleteBadgingFile(String filename){
        log.setLevel(Level.TRACE);
        if (log.isTraceEnabled()) log.trace("Entering deleteBadgingFile with File: " + filename);

        if (new File(filename).delete()){
            log.debug("File Deleted");
        }
        else{
            log.debug("File Not Deleted");
        }
        if (log.isTraceEnabled()) log.trace("Exiting deleteBadgingFile with File: " + filename);
    }

    public static String generateBadgingSystemFile(SailPointContext context, Identity id, Application app, List<ProvisioningPlan.AttributeRequest> attReqs) throws GeneralException {
        log.setLevel(Level.TRACE);
        if(log.isTraceEnabled()) log.trace("Entering THD-Util-BadgingIntegration-generateBadgingSystemFile with Identity: " + id.getName());

        String outputfileName;
        String baseFilePath;
        Custom badgingIntegrationMapping = null;
        List<String> fileAttributes = new ArrayList<String>();
        List<String> toList = new ArrayList<String>();
        String reqResult = RequestResult.STATUS_FAILURE;
        FileOutputStream ostream = null;
        outputfileName = Util.otos(id.getAttribute(THD_Constants_IdentityAttributes.UID))+"_"+getDate(THD_Constants_BadgingIntegration.DATE_PATTERN)+".csv";

        try{
            badgingIntegrationMapping = context.getObjectByName(Custom.class, THD_Constants_BadgingIntegration.CUSTOM_MAPPINGS);
            baseFilePath = Util.otos(badgingIntegrationMapping.get(THD_Constants_BadgingIntegration.CUSTOM_MAPPINGS_BASE_PATH));
            fileAttributes = Util.otol(badgingIntegrationMapping.get(THD_Constants_BadgingIntegration.CUSTOM_MAPPINGS_FILE_ATTRIBUTES));
            toList = Util.otol(badgingIntegrationMapping.get(THD_Constants_BadgingIntegration.CUSTOM_MAPPINGS_TO_LIST));
            if(log.isDebugEnabled()) log.debug("setting baseFilePath to: " + baseFilePath);
        }
        catch (GeneralException e){
            if(log.isDebugEnabled()) log.debug("Unable to access custom object " + THD_Constants_BadgingIntegration.CUSTOM_MAPPINGS);
            throw e;
        }

        //Getting Bytes for Record (Used to write to file or append to email)
        byte [] recordBytes = getRecordBytes(id, fileAttributes, attReqs);

        try {
            //try to write data to file share
            if(log.isDebugEnabled()) log.debug("Writing file to: " + baseFilePath+outputfileName);
            ostream = new FileOutputStream(baseFilePath+outputfileName);
            ostream.write(recordBytes);
            if(log.isDebugEnabled()) log.debug("File written to: " + baseFilePath+outputfileName);
            //transferFile(context, app, badgingIntegrationMapping, outputfileName);
            reqResult = RequestResult.STATUS_COMMITTED;

        } catch (IOException e) {
            //If data is unable to be written to output file stream then send an email notification with the file attached
            if(log.isDebugEnabled()) log.debug("Unable to write to file: " + outputfileName);
            if(log.isDebugEnabled()) log.debug("Sending Error Email");
            sendFailoverEmail(id, toList, outputfileName, recordBytes, context);
            reqResult = RequestResult.STATUS_WARNING;
        }
        finally {
            try {
                //try to close output file stream
                if (ostream != null) {
                    ostream.close();
                }
                //deleteBadgingFile(baseFilePath+outputfileName);
                if(log.isTraceEnabled()) log.trace("Exiting THD-Util-BadgingIntegration-generateBadgingSystemFile with Identity: " + id.getName());
                return reqResult;

            } catch (IOException e) {
                //unable to close file stream
                if(log.isDebugEnabled()) log.debug("Unable to close filestream");
                e.printStackTrace();
                //deleteBadgingFile(baseFilePath+outputfileName);
                if(log.isTraceEnabled()) log.trace("Exiting THD-Util-BadgingIntegration-generateBadgingSystemFile with Identity: " + id.getName());
                return reqResult;
            }
        }
    }
}


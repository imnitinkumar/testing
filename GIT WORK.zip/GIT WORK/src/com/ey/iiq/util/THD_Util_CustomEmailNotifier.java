package com.ey.iiq.util;
import sailpoint.api.EmailNotifier;
import sailpoint.api.SailPointContext;
import sailpoint.server.SMTPEmailNotifier;
import sailpoint.object.Configuration;
import sailpoint.object.EmailOptions;
import sailpoint.object.EmailTemplate;
import sailpoint.object.Filter;
import sailpoint.object.QueryOptions;
import sailpoint.object.Identity;
import org.apache.log4j.Logger;
import org.apache.log4j.Level;
import sailpoint.tools.GeneralException;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import sailpoint.object.Resolver;
import sailpoint.server.RedirectingEmailNotifier;

public class THD_Util_CustomEmailNotifier implements EmailNotifier {
	public void sendEmailNotification(SailPointContext context, EmailTemplate template, EmailOptions options) throws GeneralException {
		Logger log = Logger.getLogger("com.ey.com.THD_Util_CustomEmailNotifier");
		String lang_suffix = null;
		EmailTemplate newTemplate = template;
		String templ_name = "";
		Filter myFilter = Filter.eq("email", template.getTo());
		QueryOptions qo = new QueryOptions();
		qo.addFilter(myFilter);
		List<Identity>  IdentList= new ArrayList<Identity>(); 
		IdentList=context.getObjects(Identity.class, qo);
		if (null != IdentList){
		 for (Identity toIdent : IdentList) {
			lang_suffix = toIdent.getStringAttribute("countryCode");
		 }
		}
		log.debug("lang_suffix is -->" + lang_suffix);
		if (lang_suffix != null) {
			if(lang_suffix.equalsIgnoreCase("CA")){
				templ_name = template.getName() + "-CA";
			}
			else{
				templ_name = template.getName();
			}
		}
		else{
			templ_name = template.getName();
		}
		log.debug("templ_name is -->" + templ_name);
		EmailTemplate templ = context.getObject(EmailTemplate.class,templ_name);
		if(templ!=null){
			newTemplate = templ.compile(context, context.getConfiguration(), options);
		}
		else{
		    newTemplate = template.compile(context, context.getConfiguration(), options);
		}
		
		 Configuration conf = (Configuration)context.getObjectByName(Configuration.class, "SystemConfiguration");
      String type = (String)conf.get("emailNotifierType");
      if (null == type)
        throw new GeneralException("emailNotifierType not configured in system config."); 
      if ("smtp".equals(type)) {
		SMTPEmailNotifier smtp = new SMTPEmailNotifier();
		smtp.sendEmailNotification(context, newTemplate, options);
      } else if ("redirectToEmail".equals(type) || "redirectToFile".equals(type)) {
        RedirectingEmailNotifier redirecting = new RedirectingEmailNotifier();
        redirecting.setDelegate((EmailNotifier)new SMTPEmailNotifier());
        redirecting.setEmailAddress(conf.getString("redirectingEmailNotifierAddress"));
        if ("redirectToFile".equals(type)) {
          redirecting.setFileName(conf.getString("redirectingEmailNotifierFilename"));
		  		redirecting.sendEmailNotification(context, newTemplate, options);
        } else {
          redirecting.setFileName(null);
		  		redirecting.sendEmailNotification(context, newTemplate, options);
        } 
      } else {
        throw new GeneralException("Unknown email notifier type: " + type);
      } 
	}
	
	public Boolean sendImmediate(){
		return Boolean.valueOf(true);
	}
	  
	public void setSendImmediate(Boolean arg0) {}
}
 
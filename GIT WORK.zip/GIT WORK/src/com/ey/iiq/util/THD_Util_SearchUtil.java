package com.ey.iiq.util;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import sailpoint.api.IdentityService;
import sailpoint.api.SailPointContext;
import sailpoint.object.Application;
import sailpoint.object.Configuration;
import sailpoint.object.Custom;
import sailpoint.object.Filter;
import sailpoint.object.Identity;
import sailpoint.object.Link;
import sailpoint.object.ManagedAttribute;
import sailpoint.object.QueryOptions;
import sailpoint.object.SailPointObject;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

import java.util.Objects;

/**
 * A set of utility methods to aid in searching the IIQ Database for SailPointObjects
 */
@SuppressWarnings("unused")
public class THD_Util_SearchUtil {
    private THD_Util_SearchUtil() {}

    private static final Log LOG = LogFactory.getLog(THD_Util_SearchUtil.class);
    /*
     * Identity Methods
     */

    /**
     * Get the application object given the application name
     *
     * @param context           the current SailPoint context
     * @param name              the name of the application
     * @return                  the application object
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static Application getApplication(SailPointContext context, String name)
            throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("name", name));

        return (Application) getObject(context, Application.class, qo);
    }

    /**
     * Get an identity's manager
     *
     * @param context           the current SailPoint context
     * @param name              the name of the identity
     * @return                  the Identity object of the manager
     * @throws GeneralException if unable to retrieve object in SailPoint
     */
    public static Identity getIdentityManager(SailPointContext context, String name)
            throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("name", name));

        return (Identity) getObjectProperty(context, Identity.class, qo, "manager");
    }

    /**
     * Get the identity given an account name
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param name              the name of the identity
     * @return                  the Identity object or null
     * @throws GeneralException if unable to retrieve object in SailPoint
     */
    public static Identity getIdentityIgnoreCase(SailPointContext context, String name)
            throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.ignoreCase(Filter.eq("name", name)));

        return (Identity) getObject(context, Identity.class, qo);
    }

    /**
     * Get the identity given an account name.
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param accountName       the native identity on the account
     * @return                  the Identity object or null
     * @throws GeneralException if unable to retrieve object in SailPoint
     */
    public static Identity getIdentityGivenAccount(SailPointContext context, String accountName) throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("links.nativeIdentity", accountName));

        return (Identity) getObject(context, Identity.class, qo);
    }

    /**
     * Get the identity given the account name and application name
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param application       the application name
     * @param accountName       the account native identity
     * @return                  the Identity object or null
     * @throws GeneralException if unable to retrieve object in SailPoint
     */
    public static Identity getIdentityGivenAccount(SailPointContext context, String application, String accountName)
            throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("links.application.name", application));
        qo.addFilter(Filter.eq("links.nativeIdentity", accountName));

        return (Identity) getObject(context, Identity.class, qo);
    }

    /**
     * Get a Workgroup object
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param workgroup         the workgroup name
     * @return                  the Identity object or null
     * @throws GeneralException if unable to retrieve object in SailPoint
     */
    public static Identity getWorkgroup(SailPointContext context, String workgroup) throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("workgroup", true));
        qo.addFilter(Filter.eq("name", workgroup));

        return (Identity) getObject(context, Identity.class, qo);
    }

    /**
     * Get a specific property or attribute for an identity
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param name              the name of the identity
     * @param property          the property to retrieve
     * @return                  the value of the property or null
     * @throws GeneralException if unable to retrieve object in SailPoint
     */
    public static Object getIdentityProperty(SailPointContext context, String name, String property)
            throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("name", name));

        return getObjectProperty(context, Identity.class, qo, property);
    }


    /**
     * Checks whether an identity matches the given filter
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param identity          the identity object
     * @param filter            the filter to match
     * @return                  iff the identity matches the filter
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static boolean identityMatches(SailPointContext context, Identity identity, Filter filter)
            throws GeneralException {
        Objects.requireNonNull(identity, "Identity argument is null.");
        Filter searchFilter = Filter.and(Filter.eq("id", identity.getId()), filter);

        return doesExist(context, Identity.class, searchFilter);
    }

    /**
     * Checks whether an identity matches the given filter
     *
     * @param context             the current SailPoint connection to the persistent store
     * @param name                the name of the identity
     * @param filter              the filter to match
     * @return                    true iff the identity matches the filter
     * @throws GeneralException   if unable to search for object in SailPoint
     */
    public static boolean identityMatches(SailPointContext context, String name, Filter filter)
            throws GeneralException {
        Filter searchFilter = Filter.and(Filter.eq("name", name), filter);

        return doesExist(context, Identity.class, searchFilter);
    }

    /*
     * Link Methods
     */

    /**
     * Get the first account for an identity on the specified application
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param identity          the Identity object
     * @param application       the application name
     * @return                  the Link object or null
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static Link getAccount(SailPointContext context, Identity identity, String application)
            throws GeneralException {
        Objects.requireNonNull(identity, "Identity argument is null.");
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("identity.id", identity.getId()));
        qo.addFilter(Filter.eq("application.name", application));

        return (Link) getObject(context, Link.class, qo);
    }

    /**
     * Get the first account for an identity on the specified application
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param name              the identity name
     * @param application       the application name
     * @return                  the Link object or null
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static Link getAccount(SailPointContext context, String name, String application) throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("identity.name", name));
        qo.addFilter(Filter.eq("application.name", application));

        return (Link) getObject(context, Link.class, qo);
    }

    /**
     * Get a specific property or attribute for an account
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param name              the native identity of the account
     * @param property          the property to get
     * @return                  the value of the property or null
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static Object getAccountProperty(SailPointContext context, String name, String property)
            throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("nativeIdentity", name));

        return getObjectProperty(context, Link.class, qo, property);
    }

    /*
     * Application Methods
     */

    /**
     * Get a specific property or attribute for an application
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param name              the name of the application
     * @param property          the property to get
     * @return                  the value of the property or null
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static Object getApplicationProperty(SailPointContext context, String name,
                                                String property) throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("name", name));

        return getObjectProperty(context, Application.class, qo, property);
    }

    /*
     * Custom and Configuration helpers
     */

    /**
     * Get the value of a Custom object entry
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param name              the name of the custom object
     * @param key               the key in the map
     * @return                  the value of the key or null
     * @throws GeneralException if unable to retrieve object in SailPoint
     */
    public static Object getCustomValue(SailPointContext context, String name, String key) throws GeneralException {
        Custom custom = context.getObject(Custom.class, name);
        Objects.requireNonNull(custom, "Could not find Custom object: " + name);
        return custom.get(key);
    }

    /**
     * Get the value of a Configuration object entry
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param name              the name of the configuration object
     * @param key               the key in the map
     * @return                  the value of the key or null
     * @throws GeneralException if unable to retrieve specific {@code Configuration} object in SailPoint
     */
    public static Object getConfigurationValue(SailPointContext context, String name, String key) throws GeneralException {
        Configuration config = context.getObject(Configuration.class, name);
        Objects.requireNonNull(config, "Could not find Configuration object: " + name);

        return config.get(key);
    }

    /**
     * Get the value of a key in the system configuration
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param key               the key in the map
     * @return                  the value of the key or null
     * @throws GeneralException if unable to retrieve SailPoint configuration
     */
    public static Object getSysConfigValue(SailPointContext context, String key) throws GeneralException {
        Configuration config = context.getConfiguration();
        return config.get(key);
    }

    /*
     * Main methods that are used to search by other methods
     */

    /**
     * Search for a SailPointObject given the class and filter
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param klass             a class that extends SailPointObject
     * @param filter            the filter that should be applied
     * @return                  the first object found or null
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static SailPointObject getObject(SailPointContext context, Class<? extends SailPointObject> klass,
                                            Filter filter) throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(filter);

        return getObject(context, klass, qo);
    }

    /**
     * Search for a SailPoint object given the provided Class and query.
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param klass             a class that extends SailPointObject
     * @param qo                the query options that should be applied
     * @return                  the first object found or null
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static SailPointObject getObject(SailPointContext context, Class<? extends SailPointObject> klass, QueryOptions qo)
            throws GeneralException {

        SailPointObject object = null;
        Iterator<? extends SailPointObject> it = context.search(klass, qo);

        if (it.hasNext()) object = it.next();

        Util.flushIterator(it);

        return object;
    }

    /**
     * Search for a specific property for the given class and filter
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param klass             a class that extends SailPointObject
     * @param filter            the filter that should be applied
     * @param property          the property to get
     * @return                  the value of the property or null
     * @throws GeneralException if unable to search for the object in SailPoint
     */
    public static Object getObjectProperty(SailPointContext context,
                                           Class<? extends SailPointObject> klass, Filter filter, String property)
            throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(filter);

        return getObjectProperty(context, klass, qo, property);
    }

    /**
     * Search for a specific property for the given class and query options.
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param klass             a class that extends SailPointObject
     * @param qo                the query options that should be applied
     * @param property          the property to get
     * @return                  the value of the property or null
     * @throws GeneralException if unable to search for the object in SailPoint
     */
    public static Object getObjectProperty(SailPointContext context, Class<? extends SailPointObject> klass,
                                           QueryOptions qo, String property) throws GeneralException {
        Object value = null;

        Iterator<Object[]> it = context.search(klass, qo, property);

        if (it.hasNext())
            value = it.next()[0];

        Util.flushIterator(it);

        return value;
    }

    /**
     * Search for multiple properties for the given class and filter.
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param klass             a class that extends SailPointObject
     * @param filter            the filter that should be applied
     * @param properties        the properties to get
     * @return                  the values of the properties in an array
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static Object[] getObjectProperties(SailPointContext context, Class<? extends SailPointObject> klass,
                                               Filter filter, String properties) throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(filter);

        return getObjectProperties(context, klass, qo, properties);
    }

    /**
     * Search for multiple properties for the given class and query options.
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param klass             a class that extends SailPointObject
     * @param qo                the query options that should be applied
     * @param properties        the properties to get
     * @return                  the values of the properties in an array
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static Object[] getObjectProperties(SailPointContext context, Class<? extends SailPointObject> klass,
                                               QueryOptions qo, String properties) throws GeneralException {
        Object[] value = null;

        Iterator<Object[]> it = context.search(klass, qo, properties);

        if (it.hasNext())
            value = it.next();

        Util.flushIterator(it);
        return value;
    }

    /**
     * Checks whether an object exists that matches the given query options
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param klass             a class that extends SailPointObject
     * @param qo                the query options that should be applied
     * @return                  if an object matching the query options exists
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static boolean doesExist(SailPointContext context, Class<? extends SailPointObject> klass, QueryOptions qo)
            throws GeneralException {
        boolean exists = false;

        Iterator<Object[]> it = context.search(klass, qo, "id");
        if (it.hasNext())
            exists = true;

        Util.flushIterator(it);
        return exists;
    }

    /**
     * Checks whether an object exists that matches the given filter
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param klass             a class that extends SailPointObject
     * @param filter            the filter that should be applied
     * @return                  if an object matching the filter exists
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static boolean doesExist(SailPointContext context, Class<? extends SailPointObject> klass, Filter filter)
            throws GeneralException {
        QueryOptions qo = new QueryOptions();
        qo.addFilter(filter);

        return doesExist(context, klass, qo);
    }

    /**
     * Checks whether an attribute for a Sailpoint object is unique.
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param klass             a class that extends SailPointObject
     * @param attributeName     name of the attribute for the object
     * @param attributeValue    value for which you are checking uniqueness
     * @return                  true iff an object matching the filter exists
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static boolean isAttributeUnique(SailPointContext context, Class<? extends SailPointObject> klass,
                                            String attributeName, Object attributeValue) throws GeneralException {
        Filter filter = Filter.eq(attributeName, attributeValue);
        QueryOptions qo = new QueryOptions(filter);
        Iterator<? extends SailPointObject> results = context.search(klass, qo);

        return !(results != null && results.hasNext());
    }

    /**
     * Checks whether an attribute for an Identity is unique.
     *
     * @param context           the current SailPoint connection to the persistent store
     * @param attributeName     name of the attribute for the object
     * @param attributeValue    value for which you are checking uniqueness
     * @return                  true iff an object matching the filter exists
     * @throws GeneralException if unable to search for object in SailPoint
     */
    public static boolean isIdentityAttributeUnique(SailPointContext context, String attributeName, Object attributeValue)
            throws GeneralException {
        return isAttributeUnique(context, Identity.class, attributeName, attributeValue);
    }


    /**
     * Search for identities that have a link to a given application and a given searchable attribute
     * and attribute value
     *
     * NOTE:  At this time this method will only work for single value attributes.  Multi-value
     * attributes are represented as a comma-delimited string in the IIQ DB meaning that they are not
     * readily searchable by the QueryOptions object.
     *
     * @param context the SailPointContext
     * @param appName the name of the application
     * @param attrName the name of the attribute
     * @param value the value of the attribute
     * @return a set of Identity objects matching the search criteria
     * @throws GeneralException if something goes wrong
     */
    public Set<Identity> getIdentitiesByIDAttribute(SailPointContext context, String appName,
                                                    String attrName, String value) throws GeneralException {

        Set<Identity> idSet = new HashSet<>();

        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.and(
                Filter.eq("links.application.name", appName),
                Filter.eq(attrName, value)));

        Iterator<Identity> idItr = context.search(Identity.class, qo);
        while (idItr.hasNext()) {
            idSet.add(idItr.next());
        }
        return idSet;
    }

    /**
     * Search for identities that have an entitlement with a given application, name, and value
     *
     * @param context the SailPointContext
     * @param appName the name of the application
     * @param attrName the name of the attribute
     * @param value the value of the attribute
     * @return a set of Identity objects matching the search criteria
     * @throws GeneralException if something goes wrong
     */
    public Set<Identity> getIdentitiesByEntitlement(SailPointContext context, String appName,
                                                    String attrName, String value) throws GeneralException {

        Set<Identity> idSet = new HashSet<>();

        QueryOptions qo = new QueryOptions();
        qo.add(Filter.and(
                Filter.eq("identityEntitlements.application.name", appName),
                Filter.eq("identityEntitlements.name", attrName),
                Filter.eq("identityEntitlements.value", value)));

        Iterator<Identity> idItr = context.search(Identity.class, qo);
        while (idItr.hasNext()) {
            idSet.add(idItr.next());
        }
        return idSet;
    }

    /**
     * Search for identities with a link to the given application, check the link for given attribute
     * name and given value
     *
     * WARNING: This method will loop over ALL links of ALL identities with the given application and
     * runs the risk of being HIGHLY RESOURCE INTENSIVE and may take a significant amount of time to
     * complete.
     *
     * @param context the SailPointContext
     * @param appName the name of the application
     * @param attrName the name of the attribute
     * @param value the value of the attribute
     * @return a set of Identity objects matching the search criteria
     * @throws GeneralException if something goes wrong
     */
    @SuppressWarnings("unchecked")
    public Set<Identity> getIdentitiesByAppAttribute(SailPointContext context, String appName,
                                                     String attrName, String value) throws GeneralException {

        Set<Identity> idSet = new HashSet<>();

        QueryOptions qo = new QueryOptions();
        qo.add(Filter.eq("links.application.name", appName));


        Iterator<Object[]> it = context.search(Identity.class, qo, "id");

        //Use the identity service to get identities from DB
        IdentityService idService = new IdentityService(context);
        Application app = THD_Util_SearchUtil.getApplication(context, appName);

        //For each identity, examine link
        while (it.hasNext()) {
            Identity identity = context.getObject(Identity.class, (String) it.next()[0]);

            List<Link> linkList = idService.getLinks(identity, app);

            if (linkList != null && !linkList.isEmpty()) {
                //For each link, examine attributes
                for (Link lnk : linkList) {

                    //Get values from link for given name, add identity if value is found
                    List<String> linkPropertyValues = Util.asList(lnk.getAttribute(attrName));
                    if (linkPropertyValues != null && linkPropertyValues.contains(value)) {
                        idSet.add(identity);
                        break;
                    }
                }
            }
        }
        Util.flushIterator(it);

        return idSet;
    }

    /**
     * Retrieve a ManagedAttribute from the context based on its application, attribute name, and attribute value.
     *
     * @param context the SailPointContext
     * @param applicationName the Application object's name attribute
     * @param attributeName the attribute name of the MA (ex: "groups")
     * @param attributeValue the attribute value of the MA (ex: "VMWorkStation");
     * @return the ManagedAttribute, if it can be found.
     * @throws GeneralException if something goes wrong in retrieving the from the context
     */
    public static ManagedAttribute getManagedAttribute(SailPointContext context, String applicationName, String attributeName, String attributeValue)
            throws GeneralException {
        if(LOG.isTraceEnabled()) LOG.trace("Enter getManagedAttribute");
        Filter fApplication = Filter.eq("application.name", applicationName);
        Filter fAttribute   = Filter.eq("attribute"       , attributeName);
        Filter fValue       = Filter.eq("value"           , attributeValue);
        Filter filter       = Filter.and(fApplication, fAttribute, fValue);

        ManagedAttribute managedAttribute = context.getUniqueObject(ManagedAttribute.class, filter);
        if(LOG.isTraceEnabled()) LOG.trace("Exit getManagedAttribute: " + managedAttribute);
        return managedAttribute;
    }
}


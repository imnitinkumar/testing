package com.ey.iiq.sp2xml;
import com.ey.iiq.constants.THD_Constants_ProvisioningPolicy;
import sailpoint.api.SailPointContext;
import sailpoint.object.ResourceObject;
import org.apache.log4j.Logger;
import org.apache.log4j.Level;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Date;
import java.text.ParseException;
import org.joda.time.Days;
import sailpoint.tools.Util;
import java.lang.Object;
import java.lang.String;
import org.joda.time.LocalDate;
import sailpoint.object.TaskResult;
import sailpoint.tools.Util;
import sailpoint.object.Application;
import sailpoint.object.*;
import sailpoint.tools.Util;
import sailpoint.tools.GeneralException;
import java.lang.Exception;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import sailpoint.object.EmailOptions;
import sailpoint.object.EmailFileAttachment;
import sailpoint.object.EmailTemplate;
import com.ey.iiq.util.THD_Util_PasswordUtil;


import com.magnolia.iiq.build.Rule;
import sailpoint.api.SailPointContext;

@Rule(name="THD-Rule-Anything-Jackson",filename = "THD-Rule-Anything-Jackson.xml")
public class THD_Rule_Anything_Jackson {

    public String createBirthrightAssignmentTables(SailPointContext context) throws GeneralException {
        Logger log = Logger.getLogger("thd.iam.rule.THD-Rule-Anything-Jackson");
        log.setLevel(Level.TRACE);
        log.trace("Entering THD-Rule-Anything-Jackson");

        Application a = context.getObjectByName(Application.class, "CorpSecHRBadgeInterface");
        StringBuilder sb = new StringBuilder();
        a.getAttributeValue("host");
        Map<String, Object> attrs = a.getAttributes();
        for (Map.Entry<String, Object> entry : attrs.entrySet()){
            sb.append(entry.getKey() + ": " + entry.getValue() + "\n");
        }
        return sb.toString();



//        Getting specific identity for testing
//        TODO Test with specific identity
//        TODO Send email when task fails
//        TODO Gather Requirements for the following
//        1. Real-Time or Batched File Delivery
//        2. Separate File For Each LCE
//        3. File Share Connection Parameters
//        4. Move File Path to constants file
//        5. Service Account Permissions
//        6. Required Values
//        a) Contractor
//        b) Associate
//        7. Additional Optional Values
//        Getting specific identity for testing
//
//
//        IdentityRequest idReq = context.getObjectByName(IdentityRequest.class, 0000001955);
//        if (idReq == null){
//            return idReq is null;
//        }
//        else{
//
//            List requestItems = idReq.getItems();
//            if (requestItems != null){
//                log.debug(Req Items is not null);
//                for (IdentityRequestItem i  requestItems){
//                    if (i.getApplication().equalsIgnoreCase(CorpSecHRBadgeInterface)){
//                        log.debug(PRINTING REQUEST ITEM);
//                        log.debug(i.toString());
//                        log.debug(i.getApplication());
//                        log.debug(i.getValue());
//                        log.debug(i.getManagedAttributeType());
//                        log.debug(i.getOperation());
//                        i.setProvisioningState(ApprovalItem.ProvisioningState.Unverifiable);
//                        log.debug(i.getProvisioningState());
//                        context.saveObject(i);
//                    }
//                }
//                context.commitTransaction();
//
//                return idReq is not null;
//
//            }
//        }
//
//
//
//
//
//        String fileName = Test-OutputBadgingIntegration-Output.csv;
//        FileWriter fw = null;
//        BufferedWriter br = null;
//        EmailOptions eo = new EmailOptions();
//
//        Map m = new HashMap();
//        m.put(date,TESTDATE);
//        m.put(uid, TESTUID);
//        m.put(fName, TESTFNAME);
//        m.put(lName, TESTLNAME);
//        m.put(email, TESTEMAIL);
//        m.put(userType, TESTUSERTYPE);
//        eo.addVariables(m);
//        eo.setTo(TESTTO);
//
//        EmailTemplate et = context.getObject(EmailTemplate.class, THD-EmailTemplate-BadgingIntegration-FileWriteError);
//
//        context.sendEmailNotification(et,eo);

    }
}

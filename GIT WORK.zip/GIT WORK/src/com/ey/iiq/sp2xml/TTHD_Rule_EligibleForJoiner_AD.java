package com.ey.iiq.sp2xml;

import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Logger;

@Rule(name="THD-Rule-EligibleForJoiner-AD",filename="THD-Rule-EligibleForJoiner-AD.xml")
public class THD_Rule_EligibleForJoiner_AD {
    public boolean execute() {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-EligibleForJoiner-AD");
        log.trace("ENTERING THD-Rule-EligibleForJoiner-AD");

        // All identities meet the criteria for an AD account

        log.trace("EXITING THD-Rule-EligibleForJoiner-AD");
        return true;
    }
}

package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_Birthright;
import com.magnolia.iiq.build.Rule;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.tools.GeneralException;

@Rule(name = "THD-Rule-CreateBirthrightChangelogTables", filename = "THD-Rule-CreateBirthrightChangelogTables.xml")
public class THD_Rule_CreateBirthrightChangelogTables {

    public String createBirthrightChangelogTables(SailPointContext context) {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-CreateBirthrightChangelogTables");
        log.setLevel(Level.TRACE);
        log.trace("ENTERING createBirthrightChangelogTables()");

        // Flags that can be set in debug (Should never be true in Prod)
        boolean deleteOldTables = false;
        String resultString     = "Birthright Changelog Tables\n";

        // All the tables that will be created
        String ruleChangelogTableName = THD_Constants_Birthright.RULE_CHANGELOG_TABLE_NAME;
        //String identityChangelogTableName = THD_Constants_Birthright.IDENTITY_CHANGELOG_TABLE_NAME;

        try {
            // Connect to IdentityIQ database
            Connection dbCxn = context.getJdbcConnection();
            if (dbCxn == null) {
                return "Failed to get JDBC connection from context.getJdbcConnection()";
            }

            // The list of statements that need to be executed
            List<String> sqlStatements = new ArrayList<>();

            // Use the DB MetaData to check if the birthright assignment table exists
            DatabaseMetaData dbm = dbCxn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, ruleChangelogTableName, null);
            if (tables != null && tables.next()) {
                log.debug("The birthright changelog table '" + ruleChangelogTableName + "' already exists");

                // Only delete tables during the testing phase then run again to create it
                if (deleteOldTables) {
                    String deleteTableSql = "DROP TABLE " + ruleChangelogTableName + ";";
                    sqlStatements.add(deleteTableSql);
                    resultString += "Table '" + ruleChangelogTableName + "' Status: Dropping (run rule again to create)\n";
                } else {
                    resultString += "Table '" + ruleChangelogTableName + "' Status: Already Exists\n";
                }
                tables.close();
            } else {
                log.debug("The birthright changelog table '" + ruleChangelogTableName + "' does NOT exist and must be created");

                // Create statement for current table
                String createTableSql = "CREATE TABLE " + ruleChangelogTableName + " (" +
                        "timestamp DATETIME NOT NULL, " +
                        "modifiedBy VARCHAR(50) NOT NULL, " +
                        "tableModified VARCHAR(50) NOT NULL," +
                        "operation VARCHAR(8) NOT NULL, " +
                        "ruleId VARCHAR(10) NOT NULL, " +
                        "newRule VARCHAR(2000) NOT NULL, " +
                        "oldRule VARCHAR(2000)" +
                        ");";
                sqlStatements.add(createTableSql);

                resultString += "Table '" + ruleChangelogTableName + "' Status: Creating\n";
            }

            // Execute all sql commands if any were generated (Create, Delete, Insert)
            try {
                for (String sqlStatement : sqlStatements) {
                    log.debug("Executing DDL: [" + sqlStatement + "]");
                    Statement stmt = dbCxn.createStatement();
                    stmt.executeUpdate(sqlStatement);
                    stmt.close();
                }
                if (!dbCxn.getAutoCommit()) dbCxn.commit();
            } catch (Exception ex) {
                log.error(ex);
                resultString += "Table '" + ruleChangelogTableName + "' Status: Error Occured Executing Statement\n";
            }
        } catch (GeneralException ex) {
            log.error("Exception trying to connect to database");
            log.error(ex);
        } catch (SQLException ex) {
            log.error("Exception trying to use connection to database");
            log.error(ex);
        }
        log.trace("EXITING createBirthrightChangelogTables()");
        return resultString;
    }
}
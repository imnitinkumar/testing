package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.Identity;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

@Rule(name="THD-Rule-EligibleForJoiner-StoreODSEE", filename = "THD-Rule-EligibleForJoiner-StoreODSEE.xml")
public class THD_Rule_EligibleForJoiner_StoreODSEE {
    public boolean execute(SailPointContext context, String identityName) {
        Logger log = Logger.getLogger("thd.iam.rule.THD-Rule-EligibleForJoiner-StoreODSEE");
        log.trace("ENTERING THD-Rule-EligibleForJoiner-StoreODSEE");

        // The flag to be returned that represents if the identity meets the criteria for a Store LDAP account
        boolean meetsCriteria = false;

        try {
            Identity identity = context.getObjectByName(Identity.class, identityName);
            String locationType = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_TYPE));

            // If the identity has a location type of 'STR' they meet the requirements for a Store LDAP account
            if (THD_Constants_General.LOCATION_TYPE_STORE.equalsIgnoreCase(locationType))
                meetsCriteria = true;
        } catch (GeneralException e) {
            log.error("Exception Caught in THD-Rule-EligibleForJoiner-StoreODSEE" + e.toString());
        }

        log.trace("EXITING THD-Rule-EligibleForJoiner-StoreODSEE");
        return meetsCriteria;
    }
}
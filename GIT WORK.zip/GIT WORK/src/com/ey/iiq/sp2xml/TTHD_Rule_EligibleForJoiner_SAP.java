package com.ey.iiq.sp2xml;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.magnolia.iiq.build.RuleReference;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
//import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

import java.util.Map;
import com.magnolia.iiq.build.Rule;

//import sailpoint.object.ProvisioningPlan;
//import sailpoint.object.ProvisioningPlan.AccountRequest.Operation;

@Rule(name="THD-Rule-EligibleForJoiner-SAP", filename="THD-Rule-EligibleForJoiner-SAP.xml")
public class THD_Rule_EligibleForJoiner_SAP {
    public static boolean execute(SailPointContext context, String identityName) throws GeneralException {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-SAPEligibleForJoiner");
        log.setLevel(Level.TRACE);

        log.trace("ENTERING THD-Rule-SAPEligibleForJoiner ");
        Identity identityObject = context.getObjectByName(Identity.class, identityName);
        log.debug("THD-Rule-SAPEligibleForJoiner > identity " + identityObject);

        log.trace("ENTERING fro SAP THD-Rule-SAPEligibleForJoiner() ");

        String birthrightTableName = null;

        String applicationName = "SCORE-CAN";
        boolean isEligibleForJoinerVal = false;
        try {

            Custom birthrightMapping = context.getObjectByName(Custom.class, "THD-Custom-BirthrightTable-Mappings");
            if (birthrightMapping != null) {
                log.debug("THD-Rule-SAPEligibleForJoiner()Successfully retrieved Custom Object for SAP Table 'THD-Custom-BirthrightTable-Mappings'");
                log.debug("THD-Rule-SAPEligibleForJoiner() Birthright Table Name Directly From Custom Object: " + Util.otos(birthrightMapping.get(applicationName)));
                Map birthrightMap = birthrightMapping.getAttributes().getMap();
                if (birthrightMap != null) {
                    log.debug("Map from Custom Object: " + birthrightMap.toString());
                    birthrightTableName = Util.otos(birthrightMap.get(applicationName));
                    if (birthrightTableName != null) {
                        log.debug("THD-Rule-SAPEligibleForJoiner() SAP Birthright Table Name from Map: " + birthrightTableName);
                    }
                }
            }
            if (birthrightTableName != null) {
                String checkConnection;
                Connection dbCxn = context.getJdbcConnection();
                if (dbCxn == null) {
                    log.debug("THD-Rule-SAPEligibleForJoiner() Returning empty list as database connection was null for SAP");
                    log.trace("THD-Rule-SAPEligibleForJoiner() EXITING THD-Rule-SAPEligibleForJoiner() for SAP");
                    checkConnection = null;
                }

                DatabaseMetaData dbm = dbCxn.getMetaData();
                ResultSet tables = dbm.getTables(null, null, birthrightTableName, null);
                if (tables.next()) {

                    log.debug("The table '" + birthrightTableName + "' already exists for SAP");

                    int numRows = 0;
                    String sqlQuery;
                    String sapJobCode = null;
                    String hrJobCode;

                    String customQuery= null;
                    Custom getQuery = context.getObjectByName(Custom.class, "THD-Custom-Queries-Mapping");

                    if (getQuery != null) {
                        Map queryMap = getQuery.getAttributes().getMap();
                        if (queryMap != null) {

                            customQuery = Util.otos(queryMap.get("SAP_JOB_CODE_QUERY2"));
                            log.debug("customQuery from custom file for SAP SAP_JOB_CODE_QUERY2 " + customQuery);
                        }
                    }
                    if ( customQuery != null && customQuery.length() > 0){
                        //TODO Change to constants
                        String jobTitle = Util.otos(identityObject.getAttribute("jobTitle"));
                        String countryCode = Util.otos(identityObject.getAttribute("countryCode"));
                        String statusVal = Util.otos(identityObject.getAttribute("status"));
                        String locationTypeVal = Util.otos(identityObject.getAttribute("locationType"));
                        String personTypeVal = Util.otos(identityObject.getAttribute("personType"));

                        log.debug("statusVal value for identity " + statusVal + "jobTitle>" + jobTitle + "countryCode>" + countryCode);

                        if ( (jobTitle != null && jobTitle.length() > 0) && (statusVal.equals("A") || statusVal.equals("H") || statusVal.equals("R")) && countryCode.equalsIgnoreCase("CA")){
                            if (locationTypeVal != null  &&  (personTypeVal != null && personTypeVal.equalsIgnoreCase("ASSOCIATE"))){
                                hrJobCode = jobTitle;
                                log.debug("THD-Rule-SAPEligibleForJoiner() JobTitle not null > jobTitle>" + jobTitle);
                                sqlQuery = String.format(customQuery, hrJobCode);

                                PreparedStatement prStmt = dbCxn.prepareStatement(sqlQuery);
                                log.debug("sqlQuery not null > sqlQuery>" + sqlQuery);
                                ResultSet rs = prStmt.executeQuery();

                                if (rs.next() == false) {
                                    log.error("Result Set came back null for sap hr_job_code");
                                } else {
                                    log.debug("ResultSet NotNull");
                                    do {
                                        numRows++;
                                        sapJobCode = rs.getString(1);
                                        log.debug("sapJobCode value >" + sapJobCode);
                                    } while (rs.next());

                                }
                                log.debug("sapJobCode value after while>" + sapJobCode);

                                if ( sapJobCode != null && sapJobCode.length() > 0){

                                    isEligibleForJoinerVal = true;
                                    log.debug("isEligibleForJoinerVal value after isEligibleForJoinerVal>+" + isEligibleForJoinerVal);
                                    rs.close();
                                    prStmt.close();
                                }
                                log.debug("Result Set returned for sap" + numRows + "row(s)");
                            }
                        }
                        else{
                            log.error("JobTitle not found from identity...");
                        }
                    }
                    else{
                        log.error("No customQuery found in CustomFile for query2");
                    }
                }
                else {
                    log.error("The table '" + birthrightTableName + "' does NOT exist and must be created");
                }
                tables.close();
            }
            else {
                log.error("The table '" + birthrightTableName + "' does NOT exist custom mapping file");
            }
        } catch (SQLException ex) {
            log.error("Exception trying to use connection to database");
            log.error(ex);

        } catch (GeneralException ex) {
            log.error("Exception trying to connect to database");
            log.error(ex);

        } catch (Exception ex) {
            log.error("Exception trying to execute rule THD-Rule-SAPEligibleForJoiner before modifying");
            log.error(ex);

        }
        return isEligibleForJoinerVal;
    }
}

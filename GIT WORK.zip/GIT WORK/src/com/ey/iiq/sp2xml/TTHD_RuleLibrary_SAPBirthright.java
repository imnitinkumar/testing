package com.ey.iiq.sp2xml;

import com.magnolia.iiq.build.Rule;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.object.Entitlement;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.sql.ResultSetMetaData;
import java.util.Map;

@Rule(name="THD-RuleLibrary-SAPBirthright", filename="THD-RuleLibrary-SAPBirthright.xml",library = true)
public class THD_RuleLibrary_SAPBirthright {

    private  Logger log = Logger.getLogger("thd.iam.THD-RuleLibrary-SAPBirthright");

    public List getSAPBirthrightEntitlements(Identity identityObject, SailPointContext context,
                                             String birthrightTableName) {

        log.setLevel(Level.TRACE);
        log.trace("ENTERING fro SAP getSAPBirthrightEntitlements() ");
        List birthrightEntitlements = new ArrayList();

        try {

            String queryVal="SAP_JOB_CODE_QUERY1";
            ResultSet rs = getRolesFromDB(identityObject,context,birthrightTableName,queryVal);
            if (rs == null){
                log.error("Result Set came back null for sap hr_job_code");
                return birthrightEntitlements;
            }
            log.debug("getSAPBirthrightEntitlements()Result rs for is not null ");

            birthrightEntitlements=addNewSAPBirthrightEntitlements(identityObject,rs);
            log.debug("getSAPBirthrightEntitlements() birthrightEntitlements " +birthrightEntitlements);
            if (rs != null){
                rs.close();
            }

        }

        catch (SQLException ex) {
            log.error("Exception trying to get birthrightEntitlements");
            log.error(ex);
        }
        log.trace("EXITING getSAPBirthrightEntitlements()");
        return birthrightEntitlements;
    }

    //Getting Valid To--------------------------
    public String getSAPBirthrightValidTo(Identity identityObject, SailPointContext context,
                                          String birthrightTableName) {
        log.setLevel(Level.TRACE);
        log.trace("ENTERING fro SAP getSAPBirthrightValidTo() ");
        String sapJobCode = null;
        String userValidTo ;
        String statusVal = null;
        statusVal=Util.otos(identityObject.getAttribute("status"));
        log.debug("statusVal value for identity "+statusVal);
        int numRows = 0;



        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dateCurrent = new Date();
        String dateCurrentString = sdf.format(dateCurrent);
        log.error("getSAPBirthrightValidTo() dateCurrentString value "+dateCurrentString);
        userValidTo=dateCurrentString;
        try{
            String jobTitle = Util.otos(identityObject.getAttribute("jobTitle"));
            if(jobTitle !=null && jobTitle.length()>0){

                String queryVal="SAP_JOB_CODE_QUERY2";
                ResultSet rs = getRolesFromDB(identityObject,context,birthrightTableName,queryVal);
                if (rs == null){
                    log.error("Result Set came back null for sap hr_job_code userValidTo"+userValidTo);
                    return userValidTo;

                }

                while ((rs != null) && (rs.next())) {
                    numRows++;

                    sapJobCode=rs.getString(1);
                    log.debug("getSAPBirthrightValidTo() sapJobCode value >" +sapJobCode);
                }
                log.debug("getSAPBirthrightValidTo() sapJobCode value after while>" +sapJobCode);

                if(sapJobCode !=null && sapJobCode.length()>0){

                    if(statusVal !=null && statusVal.length()>0 && (statusVal.equalsIgnoreCase("A") || statusVal.equalsIgnoreCase("R") || statusVal.equalsIgnoreCase("H")))
                    {
                        userValidTo="99991231";
                    }
		else{
                        userValidTo=dateCurrentString;
                        log.debug("getSAPBirthrightValidTo()  userValidTo userValidTo>" +userValidTo);
                    }
                }
                log.debug("getSAPBirthrightValidTo()  Result Set returned for sap" + numRows + "row(s)");
                if (rs != null){
                    rs.close();

                }

            }
	  else {
                log.error("getSAPBirthrightValidTo()  JobTitle not found from identity...");

            }



        } catch (SQLException ex) {
            log.error("Exception getSAPBirthrightValidTo() "+ex);
            log.error(ex);
        }
        log.trace("EXITING getSAPBirthrightValidTo()");
        return userValidTo;
    }




    public List modifySAPBirthrightEntitlements(Identity identityObject, SailPointContext context,
                                                String birthrightTableName) {

        log.trace("ENTERING fro SAP modifySAPBirthrightEntitlements() ");
        List birthrightEntitlements = new ArrayList();
        List birthrightEntitlementsTMP = new ArrayList();

        try {


            log.debug("modifySAPBirthrightEntitlements() Before getting jobTitle");
            String jobTitle = Util.otos(identityObject.getAttribute("jobTitle"));
            String getStatus = Util.otos(identityObject.getAttribute("status"));
            String isEmergencyTerm = Util.otos(identityObject.getAttribute("isEmergencyTerm"));

            log.debug("modifySAPBirthrightEntitlements() After getting jobTitle "+jobTitle+"--"+getStatus+" ----- isEmergencyTerm "+isEmergencyTerm);

            String eventTriggered = Util.otos(identityObject.getAttribute("eventToBeTriggered"));
            log.debug("modifySAPBirthrightEntitlements() After getting eventTriggered "+eventTriggered);
		
			/*if(getStatus !=null && getStatus.equalsIgnoreCase("R")){
		eventTriggered="Rehire";
		}*/
            log.debug("modifySAPBirthrightEntitlements() After getting eventTriggered "+eventTriggered);


          //  if((eventTriggered == null && isEmergencyTerm != null) || (eventTriggered !=null && ((eventTriggered.equalsIgnoreCase("Joiner") && (getStatus.equalsIgnoreCase("R") || getStatus.equalsIgnoreCase("H")) )   || (eventTriggered.equalsIgnoreCase("MoverCorpToStore") || eventTriggered.equalsIgnoreCase("MoverStoreToStore") || eventTriggered.equalsIgnoreCase("Rehire"))))){
          //  if((eventTriggered == null && isEmergencyTerm != null) || (eventTriggered !=null && (getStatus.equalsIgnoreCase("A") || getStatus.equalsIgnoreCase("H")  || getStatus.equalsIgnoreCase("R") ) )){
            if ((eventTriggered == null && isEmergencyTerm != null)
          || (eventTriggered != null && (getStatus.equalsIgnoreCase("R") || getStatus.equalsIgnoreCase("A") || getStatus.equalsIgnoreCase("H")))) {

                String queryCheckJobCode="SAP_JOB_CODE_QUERY2";
                ResultSet getRSSAPCode = getRolesFromDB(identityObject,context,birthrightTableName,queryCheckJobCode);
                if (getRSSAPCode == null){
                    log.error("modifySAPBirthrightEntitlements()Result Set came back null getRSSAPCode for > "+jobTitle);
                    return birthrightEntitlements;

                }
                log.debug("modifySAPBirthrightEntitlements() Result rs for is not null ");
                if (getRSSAPCode != null){
                    getRSSAPCode.close();
                }


                String countryCode = Util.otos(identityObject.getAttribute("countryCode"));
                String locationTypeVal = Util.otos(identityObject.getAttribute("locationType"));
                String personTypeVal = Util.otos(identityObject.getAttribute("personType"));

                if((jobTitle !=null && jobTitle.length()>0) && (countryCode !=null && countryCode.equalsIgnoreCase("CA"))  && locationTypeVal !=null &&  (personTypeVal!=null &&  personTypeVal.equalsIgnoreCase("ASSOCIATE")) ){

                    String queryVal="SAP_JOB_CODE_QUERY1";
                    ResultSet rs = getRolesFromDB(identityObject,context,birthrightTableName,queryVal);
                    if (rs == null){
                        log.error("modifySAPBirthrightEntitlements()Result Set came back null for sap hr_job_cod");
                        return birthrightEntitlements;

                    }
                    log.debug("modifySAPBirthrightEntitlements() Result rs for is not null ");

                    birthrightEntitlementsTMP=addNewSAPBirthrightEntitlements(identityObject,rs);
                    log.debug("modifySAPBirthrightEntitlements() birthrightEntitlements " +birthrightEntitlementsTMP);
                    if (rs != null){
                        rs.close();
                    }
                    log.debug("modifySAPBirthrightEntitlements() sapJobCode value after while>" +jobTitle);


                    //--------------------remove existing roles if any in the identity----------------
                    String appName="SCORE-CAN";
                    for (Link appLink : identityObject.getLinks()) {

                        String getappNameFromLink = appLink.getApplicationName();
                        log.debug("THD-Rule-MoverSAP-RemoveEntitlements removeSAPNotDefaultRolesRequests getappNameFromLink >"+getappNameFromLink);
                        if(getappNameFromLink.equalsIgnoreCase(appName)){

                            List<Entitlement> currentEntitlements = appLink.getEntitlements(Locale.getDefault(), null);
                            log.debug("modifySAPBirthrightEntitlements removeSAPNotDefaultRolesRequests currentEntitlements are for SAP" + currentEntitlements);
                            if (currentEntitlements != null && currentEntitlements.size() > 0) {
                                for (Entitlement ent : currentEntitlements) {
                                    if (ent != null) {
                                        log.debug("modifySAPBirthrightEntitlements removeSAPNotDefaultRolesRequests SAPEntitlement Attribute Name: " + ent.getAttributeName());
                                        log.debug("modifySAPBirthrightEntitlements removeSAPNotDefaultRolesRequests SAPEntitlement Attribute Value: " + ent.getAttributeValue());
                                        String getExistingRole=(String)ent.getAttributeValue();


                                        if (!birthrightEntitlementsTMP.contains(getExistingRole)) {
                                            log.debug("modifySAPBirthrightEntitlements  getExistingRole,ent.getAttributeValue() Attribute Value: added " + ent.getAttributeValue());
                                            log.debug("modifySAPBirthrightEntitlements  getExistingRole Attribute Value: added " + getExistingRole);
                                            birthrightEntitlements.add(getExistingRole);
                                            log.debug("modifySAPBirthrightEntitlements  getExistingRole Attribute Value: added birthrightEntitlements " + birthrightEntitlements);
                                        }

                                    } else {
                                        log.warn("modifySAPBirthrightEntitlements removeSAPNotDefaultRolesRequests Found null Entitlement on '" + appName + "' Account");
                                    }

                                }

                            }

                        }
                    }

                    //-----------------------------------------------------------------------------------


                }
	  else {
                    log.error("modifySAPBirthrightEntitlements() JobTitle not found from identity...");
                }
            }

        }
        catch (SQLException ex) {
            log.error("THD-Rule-MoverSAP-RemoveEntitlements Exception ex "+ex);
            log.error(ex);
        }catch (GeneralException ex) {
            log.error("Exception modifySAPBirthrightEntitlements()");
            log.error(ex);
        }
        log.trace("EXITING modifySAPBirthrightEntitlements() METHOD");
        return birthrightEntitlements;
    }


    public List EnableSAPBirthrightEntitlements(Identity identityObject, SailPointContext context,
                                                String birthrightTableName) {

        log.trace("ENTERING fro SAP EnableSAPBirthrightEntitlements() ");
        List birthrightEntitlements = new ArrayList();
        List birthrightEntitlementsTMP = new ArrayList();

        try {


            log.debug("EnableSAPBirthrightEntitlements() Before getting jobTitle");
            String jobTitle = Util.otos(identityObject.getAttribute("jobTitle"));
            String getStatus = Util.otos(identityObject.getAttribute("status"));
            String isEmergencyTerm = Util.otos(identityObject.getAttribute("isEmergencyTerm"));

            log.debug("EnableSAPBirthrightEntitlements() After getting jobTitle "+jobTitle+"--"+getStatus+" ----- isEmergencyTerm "+isEmergencyTerm);

            String eventTriggered = Util.otos(identityObject.getAttribute("eventToBeTriggered"));
            log.debug("EnableSAPBirthrightEntitlements() After getting eventTriggered "+eventTriggered);


            log.debug("EnableSAPBirthrightEntitlements() After getting eventTriggered "+eventTriggered);


            if(getStatus.equals("A") || getStatus.equals("H") || getStatus.equals("R")){

                String queryCheckJobCode="SAP_JOB_CODE_QUERY2";
                ResultSet getRSSAPCode = getRolesFromDB(identityObject,context,birthrightTableName,queryCheckJobCode);
                if (getRSSAPCode == null){
                    log.error("EnableSAPBirthrightEntitlements()Result Set came back null getRSSAPCode for > "+jobTitle);
                    return birthrightEntitlements;

                }
                log.debug("EnableSAPBirthrightEntitlements() Result rs for is not null ");
                if (getRSSAPCode != null){
                    getRSSAPCode.close();
                }


                String countryCode = Util.otos(identityObject.getAttribute("countryCode"));
                String locationTypeVal = Util.otos(identityObject.getAttribute("locationType"));
                String personTypeVal = Util.otos(identityObject.getAttribute("personType"));

                if((jobTitle !=null && jobTitle.length()>0) && (countryCode !=null && countryCode.equalsIgnoreCase("CA"))  && locationTypeVal !=null &&  (personTypeVal!=null &&  personTypeVal.equalsIgnoreCase("ASSOCIATE")) ){

                    String queryVal="SAP_JOB_CODE_QUERY1";
                    ResultSet rs = getRolesFromDB(identityObject,context,birthrightTableName,queryVal);
                    if (rs == null){
                        log.error("EnableSAPBirthrightEntitlements()Result Set came back null for sap hr_job_cod");
                        return birthrightEntitlements;

                    }
                    log.debug("EnableSAPBirthrightEntitlements() Result rs for is not null ");

                    birthrightEntitlementsTMP=addNewSAPBirthrightEntitlements(identityObject,rs);
                    birthrightEntitlements=birthrightEntitlementsTMP;
                    log.debug("EnableSAPBirthrightEntitlements() birthrightEntitlements " +birthrightEntitlementsTMP);
                    if (rs != null){
                        rs.close();
                    }
                    log.debug("EnableSAPBirthrightEntitlements() sapJobCode value after while>" +jobTitle);


                }
                else {
                    log.error("EnableSAPBirthrightEntitlements() JobTitle not found from identity...");
                }
            }

        }
        catch (SQLException ex) {
            log.error("EnableSAPBirthrightEntitlements Exception ex "+ex);
            log.error(ex);
        }
        log.trace("EXITING EnableSAPBirthrightEntitlements() METHOD");
        return birthrightEntitlements;
    }



    //add new entitlements for sap
    public List addNewSAPBirthrightEntitlements(Identity identityObject, ResultSet rs) throws SQLException {

        log.setLevel(Level.TRACE);
        List getBirthrightEntitlements = new ArrayList();
        int numRows=0;

        if (rs == null){
            log.error("Result Set came back null for sap hr_job_code");
            return getBirthrightEntitlements;
        }
        boolean addEntitlement;
        while ((rs != null) && (rs.next())) {
            numRows++;
            log.debug("Result rs for entitlement sap sap_security_role ");

            String sapSecurityRole= rs.getString(1);
            String derivation= rs.getString(2);
            //String system_code= rs.getString(3);
            log.debug("Result entitlement sapSecurityRole for sap sap_security_role "+numRows+"- "+sapSecurityRole+"->"+derivation);

            if(sapSecurityRole !=null && sapSecurityRole.length()>0){
                addEntitlement = true;
                log.debug("Adding entitlement sap security role in final list " +sapSecurityRole);
                if (addEntitlement) {
                    log.debug("Adding entitlement sapSecurityRole to account request");
                    if(derivation !=null &&  derivation.length()>0){
                        if(derivation.equalsIgnoreCase("True")){
                            String locationNum = Util.otos(identityObject.getAttribute("locationNumber"));
                            log.debug("Adding locationNum sapSecurityRole locationNum"+locationNum);
                            if(locationNum !=null &&  locationNum.length()>0){
                                sapSecurityRole = sapSecurityRole.substring(0, sapSecurityRole.length()-1);
                                log.debug("Adding locationNum sapSecurityRole sapSecurityRole" + sapSecurityRole);
                                sapSecurityRole = sapSecurityRole +locationNum;
                                log.debug("Adding locationNum sapSecurityRole sapSecurityRole>" + sapSecurityRole);
                            }
                        }
                    }
                   // sapSecurityRole=system_code+"\\"+sapSecurityRole;
                    log.debug("sapSecurityRole before adding into list from provisioning policy>"+sapSecurityRole);
                    getBirthrightEntitlements.add(sapSecurityRole);
                }

            }
        }

        return getBirthrightEntitlements;

    }

    //get sap roles from DB
    public ResultSet getRolesFromDB(Identity identityObject, SailPointContext context,
                                    String birthrightTableName,String queryTypeVal){
        log.setLevel(Level.TRACE);
        ResultSet getRS = null;
        String customQueriesObject="THD-Custom-Queries-Mapping";
        try {
            Connection dbCxn = context.getJdbcConnection();
            if (dbCxn == null) {
                log.debug("Returning empty list as database connection was null for SAP");
                log.trace("EXITING getRolesFromDB() for SAP");
                return getRS;
            }
            DatabaseMetaData dbm = dbCxn.getMetaData();
            ResultSet tables = dbm.getTables(null, null, birthrightTableName, null);
            if (tables.next()) {
                log.debug("The table '" + birthrightTableName + "' already exists for SAP");
                boolean addEntitlement;
                int numRows = 0;
                String sqlQuery;

                String sapJobCode;
                String hrJobCode;

                String customQuery = null;
                Custom getQuery =context.getObjectByName(Custom.class,customQueriesObject);

                if (getQuery != null) {
                    Map queryMap = getQuery.getAttributes().getMap();
                    if (queryMap != null) {

                        customQuery = Util.otos(queryMap.get(queryTypeVal));
                        log.debug("getRolesFromDB() customQuery from custom file for SAP..."+customQuery);
                    }
                }

                if(customQuery !=null && customQuery.length()>0){

                    log.debug("Before getting jobTitle");
                    String jobTitle = Util.otos(identityObject.getAttribute("jobTitle"));
                    log.debug("After getting jobTitle "+jobTitle);
                    if(jobTitle !=null && jobTitle.length()>0){
                        hrJobCode=jobTitle;


                        sqlQuery =
                                String
                                        .format(customQuery,hrJobCode);

                        log.debug("getRolesFromDB After sqlQuery > "+sqlQuery);
                        PreparedStatement prStmt = dbCxn.prepareStatement(sqlQuery);

                        getRS = prStmt.executeQuery();
                        if (getRS == null){
                            log.error("getRolesFromDB Result Set came back null for sap hr_job_code");
                        }
                    }
                }
            }
        } catch (SQLException ex) {
            log.error("Exception trying to use connection to database getRolesFromDB");
            log.error(ex);
        } catch (GeneralException ex) {
            log.error("Exception trying to connect to database getRolesFromDB");
            log.error(ex);
        }
        log.trace("EXITING getRolesFromDB() METHOD");

        return getRS;

    }



}





package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_Birthright;
import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.constants.THD_Constants_LifecycleEvent;
import com.ey.iiq.util.THD_Util_Birthright;
import com.magnolia.iiq.build.Rule;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.Custom;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

@Rule(name = "THD-Rule-CreateBirthrightAssignmentTables", filename = "THD-Rule-CreateBirthrightAssignmentTables.xml")
public class THD_Rule_CreateBirthrightAssignmentTables {

    public String createBirthrightAssignmentTables(SailPointContext context) throws GeneralException, SQLException {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-CreateBirthrightAssignmentTables");
        log.setLevel(Level.TRACE);
        log.trace("ENTERING createBirthrightAssignmentTables()");

        // Flags that can be set in debug (Should never be true in Prod)
        boolean deleteOldTables = false;
        String resultString = "Birthright Tables\n";

        // Get all the tables that will be created
        List<String> birthrightApplications = THD_Util_Birthright.getBirthrightApplications(context);
        List<String> birthrightTableNames = null;
        if (birthrightApplications == null) resultString += "Failed to get list of birthright applications\n";
        else {
            for (String birthrightApplication : birthrightApplications) {
                String birthrightTableName = THD_Util_Birthright.getBirthrightTableName(context, birthrightApplication);

                if (Util.isNullOrEmpty(birthrightTableName) || birthrightTableName.equalsIgnoreCase(THD_Constants_LifecycleEvent.NONE_FLAG))
                    resultString += "Failed to get birthright table name using application '" + birthrightApplication + "'\n";
                else {
                    if (birthrightTableNames == null) birthrightTableNames = new ArrayList<>();
                    birthrightTableNames.add(birthrightTableName);
                }
            }
        }

        if (birthrightTableNames == null) resultString += "Unable to get list of birthright tables";
        else {
            // Connect to IdentityIQ database
            Connection dbCxn = context.getJdbcConnection();
            if (dbCxn == null) resultString += "Failed to get JDBC connection from context.getJdbcConnection()";
            else {
                // Iterate through the tables in the list and generate sql commands as appropriate
                for (String tableName : birthrightTableNames) {
                    List<String> sqlStatements = new ArrayList<>();

                    // Use the DB MetaData to check if the birthright assignment table exists
                    DatabaseMetaData dbm = dbCxn.getMetaData();
                    ResultSet tables = dbm.getTables(null, null, tableName, null);
                    if (tables.next()) {
                        log.debug("The birthright assignment table '" + tableName + "' already exists");

                        // Only delete tables during the testing phase then run again to create it
                        if (deleteOldTables) {
                            String deleteTableSql = "DROP TABLE " + tableName + ";";
                            sqlStatements.add(deleteTableSql);
                            resultString += "Table '" + tableName + "' Status: Dropping (run rule again to create)\n";
                        } else {
                            resultString += "Table '" + tableName + "' Status: Already Exists\n";
                        }
                    } else {
                        log.debug("The birthright assignment table '" + tableName + "' does NOT exist and must be created");

                        log.debug("Get the identity attributes that will be used as assignment criteria in the table");
                        List<String> identityAttributes = THD_Util_Birthright.getBirthrightIdentityAttributes(context);
                        if (identityAttributes == null)
                            log.error("Failed to retrieve Birthright Identity Attributes from Custom Object");
                        else {
                            log.debug("Birthright Identity Attributes from Custom Object: " + identityAttributes);

                            // Construct part of the CREATE statement using the identity attributes
                            StringBuilder identityAttributesBuilder = new StringBuilder();
                            for (String identityAttribute : identityAttributes) {
                                identityAttributesBuilder.append(identityAttribute);
                                identityAttributesBuilder.append(THD_Constants_General.SPACE);
                                identityAttributesBuilder.append(THD_Constants_Birthright.IDENTITY_ATTRIBUTE_VARCHAR_SIZE);
                                identityAttributesBuilder.append(THD_Constants_General.COMMA_WITH_TRAILING_SPACE);
                            }
                            String identityAttributesSQL = identityAttributesBuilder.toString();

                            // Populate the CREATE statement shell for the current table
                            String createTableQueryShell =
                                    THD_Constants_Birthright.CREATE_BIRTHRIGHT_ASSIGNMENT_TABLE_QUERY_SHELL;
                            String createTableSQL = String.format(createTableQueryShell, tableName, identityAttributesSQL);
                            sqlStatements.add(createTableSQL);

                            resultString += "Table '" + tableName + "' Status: Creating\n";
                        }
                    }
                    // Execute all sql commands if any were generated (Create, Delete, Insert)
                    try {
                        for (String sqlStatement : sqlStatements) {
                            log.debug("Executing DDL: [" + sqlStatement + "]");
                            Statement stmt = dbCxn.createStatement();
                            stmt.executeUpdate(sqlStatement);
                            stmt.close();
                        }
                        if (!dbCxn.getAutoCommit()) dbCxn.commit();
                    } catch (Exception ex) {
                        log.error(ex);
                        resultString += "Table '" + tableName + "' Status: Error Occured Executing Statement\n";
                    }
                    tables.close();
                }
            }
        }
        log.trace("EXITING createBirthrightAssignmentTables()");
        return resultString;
    }
}
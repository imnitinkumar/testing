package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.ey.iiq.constants.THD_Constants_LifecycleEvent;
import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.object.Identity;
import sailpoint.tools.Util;

@Rule(name = "THD-Rule-IdentityTrigger-Mover", filename = "THD-Rule-IdentityTrigger-Mover.xml", type = "IdentityTrigger")
public class THD_Rule_IdentityTrigger_Mover {

    public boolean isMoverIdentityTrigger(Identity newIdentity) {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-IdentityTrigger-Mover");
        log.setLevel(Level.TRACE);
        log.trace("ENTERING isMoverIdentityTrigger()");

        // The flag to be returned if this is a mover event
        boolean isMover = false;

        // The name of the identity being checked
        String identityName = newIdentity.getName();

        // Get the 'eventToBeTriggered' attribute off of the identity and check if it is a mover event
        String event = Util.otos(newIdentity.getAttribute(THD_Constants_IdentityAttributes.EVENT_TO_BE_TRIGGERED));
        if (Util.isNullOrEmpty(event))
            log.debug("Identity '" + identityName + "' has a null or empty 'eventToBeTriggered' attribute value");
        else if (!event.startsWith(THD_Constants_LifecycleEvent.MOVER_FLAG))
            log.debug("Identity '" + identityName + "' has a different 'eventToBeTriggered' attribute value");
        else {
            log.debug("Identity '" + identityName + "' has the required 'eventToBeTriggered' attribute value");
            isMover = true;
        }

        log.trace("EXITING isMoverIdentityTrigger(): " + isMover);
        return isMover;
    }
}
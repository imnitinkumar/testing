package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_ProvisioningPolicy;
import com.magnolia.iiq.build.Rule;
import sailpoint.api.SailPointContext;
import sailpoint.object.AttributeTarget;
import sailpoint.object.Identity;
import sailpoint.object.Link;
import sailpoint.object.ProvisioningProject;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

@Rule(name="THD-Rule-IdentityAttributeTarget-Manager", filename = "THD-Rule-IdentityAttributeTarget-Manager.xml", type="IdentityAttributeTarget")
public class THD_Rule_IdentityAttributeTarget_Manager {
    /**
     * Identity attribute target rules are used to tranform identity attribute values that are being pushed to targets.
     *
     * @param value                       The value of the identity attribute. Note that this could be single value or a list of values.
     * @param sourceIdentityAttribute     The sailpoint.object.ObjectAttribute for this target.
     * @param sourceIdentityAttributeName The name of the identity attribute for this target.
     * @param sourceAttributeRequest      The sailpoint.object.ProvisioningPlan.AttributeRequest that is setting the attribute on the identity.
     * @param target                      The sailpoint.object.AttributeTarget that is being processed.
     * @param identity                    The sailpoint.object.Identity that is being processed.
     * @param project                     The sailpoint.object.ProvisioningProject that has the changes that are being requested.
     * @return attributeValue The transformed value that will be pushed to the target.
     */
    public static Object identityAttributeTarget(Object value, SailPointContext context, Object sourceIdentityAttribute, Object sourceIdentityAttributeName, Object sourceAttributeRequest, AttributeTarget target, Identity identity, ProvisioningProject project, Link link) {
        String attrVal="";
        Logger log = Logger.getLogger("thd.iam.rule.THD-Rule-IdentityAttributeTarget-Manager");
        log.trace("Entering THD-Rule-IdentityAttributeTarget-Manager");
        String managerUid = Util.otos(value);
        try {
            Identity manager = context.getObjectByName(Identity.class, managerUid);
            if (manager != null) {
                for (Link l : manager.getLinks()) {
                    if (l != null) {
                        if (link.getApplication().equals(l.getApplication())) {
                            attrVal = l.getNativeIdentity();
                        }
                    }
                }
            }
        } catch (GeneralException e) {
            log.error("Unable to get find manager identity");
            log.trace("Exiting THD-Rule-IdentityAttributeTarget-Manager");
        }
        log.trace("Exiting THD-Rule-IdentityAttributeTarget-Manager");
        return attrVal;
    }
}

package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.ey.iiq.constants.THD_Constants_LifecycleEvent;
import com.magnolia.iiq.build.Rule;
import com.magnolia.iiq.build.RuleReference;
import sailpoint.api.SailPointContext;
import sailpoint.object.Identity;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

import java.text.ParseException;


@Rule(name="THD-Rule-IdentityTrigger-LOA", filename = "THD-Rule-IdentityTrigger-LOA.xml", type="IdentityTrigger")
public class THD_Rule_IdentityTrigger_LOA {
    @RuleReference(name="THD-RuleLibrary-LifecycleEventConfiguration")
    private THD_RuleLibrary_LifecycleEventConfiguration LCEConfig = new THD_RuleLibrary_LifecycleEventConfiguration();
    /**
     * This rule can be used for Certification Events that use rule triggers
     * The previousIdentity and newIdentity hold snapshots of the identity before the update has occurred and the state of the identity after the update, respectively.
     *
     * @param context          The current SailPoint context
     * @param previousIdentity The identity before the refresh/aggregation (this will be null when an identity is created).
     * @param newIdentity      The identity after the refresh/aggregation (this will be null when an identity is deleted).
     * @return result A boolean describing the result of the rule.
     */
    public boolean isLeaverIdentityTrigger(SailPointContext context, Identity previousIdentity, Identity newIdentity) throws ParseException, GeneralException {
        boolean isLoa=false;
        String event = Util.otos(newIdentity.getAttribute(THD_Constants_IdentityAttributes.EVENT_TO_BE_TRIGGERED));
        //String eventStatus = Util.otos(newIdentity.getAttribute(THD_Constants_IdentityAttributes.EVENT_PROCESSED_STATUS));
        String eventStatus = Util.otos(newIdentity.getAttribute("eventProcessedStatus"));
        String lastEvent = Util.otos(newIdentity.getAttribute("lastEventTriggered"));
        if(THD_Constants_LifecycleEvent.LOA_FLAG.equalsIgnoreCase(event) && (eventStatus == null || !"PROCESSING".equalsIgnoreCase(eventStatus) && !event.equalsIgnoreCase("None") && !THD_Constants_LifecycleEvent.LOA_FLAG.equalsIgnoreCase(lastEvent))){
            isLoa = THD_Constants_LifecycleEvent.LOA_FLAG.equalsIgnoreCase(event);
        }

        return isLoa;

    }
}

package com.ey.iiq.sp2xml.util;

import com.magnolia.iiq.build.Rule;
import com.magnolia.iiq.build.RuleMethod;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;

@Rule(name="THD-Rule-Util-LinkComparison", filename="THD-Rule-Util-LinkComparison.xml")
public class THD_Util_LinkComparison {
    @RuleMethod
    public String compareAllAttributes(Link comparedLink, Link matchedLink){
        StringBuilder sb = new StringBuilder();
        List<String> comparedAttributesList;
        List<String> matchedAttributesList;
        String matchedAttributeValue;
        String comparedAttributeValue;

        Map<String,Object> comparedAttributes = comparedLink.getAttributes();

        for (Map.Entry<String, Object> entry : comparedAttributes.entrySet()){
            comparedAttributeValue = Util.otos(entry.getValue());
            matchedAttributeValue = Util.otos(matchedLink.getAttribute(entry.getKey()));
            comparedAttributesList = Util.otol(entry.getValue());
            matchedAttributesList = Util.otol(matchedLink.getAttribute(entry.getKey()));

            if (!Util.nullSafeCaseInsensitiveEq(matchedAttributeValue,comparedAttributeValue)){
                sb.append(entry.getKey()+"\n");

                sb.append("\tTEMPLATE "+ matchedLink.getIdentity().getName() + " ATTRIBUTE VALUE\n");
                if (matchedAttributesList != null) {
                    for (String s : matchedAttributesList) {
                        sb.append("\t\t" + s + "\n");
                    }
                }
                else{
                    sb.append("\t\tnull\n");
                }
                sb.append("\tCOMPARED "+ comparedLink.getIdentity().getName() + " ATTRIBUTE VALUE\n");
                for (String s : comparedAttributesList){
                    sb.append("\t\t" + s +"\n");
                }
                sb.append("\n");
            }
        }
        return sb.toString();
    }

    @RuleMethod
    public String compareEntitlements(Link comparedLink, Link matchedLink) throws GeneralException {
        StringBuilder sb = new StringBuilder();
        List<Entitlement> matchedEntitlements = matchedLink.getEntitlements(Locale.getDefault(), null);
        List<Entitlement> comparedEntitlements = comparedLink.getEntitlements(Locale.getDefault(), null);
        sb.append("TEMPLATE "+ matchedLink.getIdentity().getName() + " ATTRIBUTE VALUE\n");
        if (matchedEntitlements != null){
            if (comparedEntitlements != null){
                for (Entitlement e : matchedEntitlements){
                    if (!comparedEntitlements.contains(e)){
                        sb.append(Util.otos("\t\t"+e.getAttributeValue())+"\n");
                    }
                }
            }
        }
        else{
            sb.append("\t\tnull\n");
        }

        sb.append("COMPARED "+ comparedLink.getIdentity().getName() + " ATTRIBUTE VALUE\n");
        if (comparedEntitlements != null){
            if (matchedEntitlements != null){
                for (Entitlement e : comparedEntitlements){
                    if (!matchedEntitlements.contains(e)){
                        sb.append(Util.otos("\t\t"+e.getAttributeValue())+"\n");
                    }
                }
            }
        }
        else{
            sb.append("\t\tnull\n");
        }
        sb.append("\n");
        return sb.toString();
    }


    public String execute (SailPointContext context) throws GeneralException {
        String templateIdentityName="";
        String comparedIdentityName="";
        boolean compareEntitlementOnly=false;
        StringBuilder sb = new StringBuilder();

        try {
            Identity templateIdentity = context.getObjectByName(Identity.class, templateIdentityName);
            Identity comparedIdentity = context.getObjectByName(Identity.class, comparedIdentityName);

            List <Link> comparedLinks = comparedIdentity.getLinks();
            Link matchedLink;

            for (Link l : comparedLinks){
                matchedLink = templateIdentity.getLink(l.getApplication());
                if (matchedLink != null){
                    sb.append(matchedLink.getApplicationName()+"\n");
                    if (compareEntitlementOnly){
                        sb.append(compareEntitlements(l, matchedLink));
                    }
                    else {
                        sb.append(compareAllAttributes(l, matchedLink));
                    }
                }
            }
        }
        catch(GeneralException e){
            return "EXCEPTION" + e.toString();

        }
        return sb.toString();
    }
}

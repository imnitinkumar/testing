package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.ey.iiq.constants.THD_Constants_LifecycleEvent;
import com.ey.iiq.constants.THD_Constants_ProvisioningPolicy;
import com.ey.iiq.util.THD_Util_Birthright;
import com.magnolia.iiq.build.Rule;
import sailpoint.object.Custom;
import sailpoint.object.Identity;
import sailpoint.object.ResourceObject;
import sailpoint.api.*;
import sailpoint.tools.Util;
import sailpoint.tools.*;

import java.text.SimpleDateFormat;
import java.text.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

@Rule(name = "THD-RuleLibrary-LifecycleEventConfiguration", filename = "THD-RuleLibrary-LifecycleEventConfigurations.xml", library = true)
public class THD_RuleLibrary_LifecycleEventConfiguration {

    private static Custom configurations;
    private static Logger log;
    private static SimpleDateFormat sdf;
    private String PERSONA_TYPE_CONTRACTOR = "CONTRACTOR";
    private String PERSONA_TYPE_ASSOCIATE = "ASSOCIATE";
    /**
     * This Method will be called from Customization Rule to update the ResourceObject
     */
    private void init(SailPointContext context) throws GeneralException {
        log = Logger.getLogger("thd.iam.THD-RuleLibrary-LifecycleEventConfiguration");
        log.setLevel(Level.TRACE);
        log.trace("ENTERING INIT");

        configurations = context.getObjectByName(Custom.class, THD_Constants_LifecycleEvent.CUSTOM_LIFECYCLE_CONFIGURATIONS);
        log = Logger.getLogger("thd.iam.THD-RuleLibrary-LifecycleEventConfiguration");
        sdf = new SimpleDateFormat("yyyy-MM-dd");

        log.trace("EXITING INIT");
    }

    public ResourceObject updateIDWResourceObject(ResourceObject object, SailPointContext context) throws Exception {
        init(context);
        log.trace("ENTERING updateIDWResourceObject");

        // Check if the object is null and throw an exception if it is
        if (object == null) throw new GeneralException("ResourceObject is null");


        // Attempt to get the identity using the objects name
        String objectName = object.getIdentity();
        Identity identity = context.getObjectByName(Identity.class, objectName);
        Custom custom = context.getObjectByName(Custom.class, "THD-Custom-LifecycleEventConfiguration");
        boolean whitelistEnabled = Util.otob(custom.get("whitelistEnabled"));

        log.debug("Check if the current account is disabled and update the object");
        boolean accountDisabled = isAccountDisabled(object, context);
        object.setAttribute(THD_Constants_LifecycleEvent.IIQ_DISABLED_KEY, accountDisabled);

        log.debug("Check if the current account requires a lifecycle event");
        String newLifecycleEvent = checkLifecycleEvents(object, context);
        String currentLifecycleEvent = (identity != null)
                ? Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.EVENT_TO_BE_TRIGGERED))
                : null;
        String lifecycleEventFlag = reconcileLifecycleEvents(newLifecycleEvent, currentLifecycleEvent);

        // Set the final lifecycle event flag on the object to be used later in an identity refresh
        if (lifecycleEventFlag == null) {
            log.debug("No lifecycle event criteria were met");
        }

        else {
            if (!whitelistEnabled || isWhitelisted(object, context))
                object.setAttribute(THD_Constants_LifecycleEvent.EVENT_TO_BE_TRIGGERED_KEY, lifecycleEventFlag);
            else
                object.setAttribute(THD_Constants_LifecycleEvent.EVENT_TO_BE_TRIGGERED_KEY, THD_Constants_LifecycleEvent.NONE_FLAG);
        }

        log.trace("EXITING updateIDWResourceObject");
        return object;
    }

    private boolean isWhitelisted(ResourceObject object, SailPointContext context){
        boolean whiteListed = false;
        log.trace("Entering isWhiteListed");
        try {
            Custom custom = context.getObjectByName(Custom.class, "THD-Custom-LifecycleEventConfiguration");
            Map<String,List<String>> criteria = (Map)(custom.get("whitelistedPersonas"));
            List<String> attributes = new ArrayList<String>();
            for (Map.Entry<String,List<String>> entrySet : criteria.entrySet()){
                log.debug("Key: " + entrySet.getKey());
                    String key = entrySet.getKey();
                    for (String attr : key.split("\\|")){
                    log.debug("Adding Attribute " + attr + ": "+ object.getAttribute(attr));
                    attributes.add(Util.otos(object.get(attr)));
                }
                if (validPersona((List<String>)entrySet.getValue(),attributes)){
                    whiteListed=true;
                }
                attributes.clear();
            }
        }
        catch(GeneralException e){
            log.error("Unable to find custom object: THD-Custom-LifecycleEventConfiguration");
        }
        //FOR TESTING
        log.trace("Exiting isWhiteListed with value " + whiteListed);
        return whiteListed;
    }
    private boolean validPersona(List<String> personas, List<String> attributes){
        log.trace("Entering validPersona");
        String [] persona = null;
        boolean validPersona=true;
        boolean returnValue = false;
        for (String p : personas){
            persona = p.split("\\|");
            if (persona!=null && attributes!=null){
                for (int i = 0; i < persona.length; i++) {
                    log.debug("Comparing attributes: " + attributes.get(i) + "\t" + persona[i]);
                    if (persona.length > i && attributes.size() > i && !(attributes.get(i).equalsIgnoreCase(persona[i]))) {
                        log.debug("Values not equal");
                        validPersona = false;
                    }
                }
            }
            if (validPersona){
                returnValue=true;
            }
            else{
                validPersona=true;
            }
        }
        log.trace("Entering validPersona with value: " + returnValue);
        return returnValue;
    }

    /**
     * TODO:// Below method is taken directly from THD-DEV we may have to update this details later on when we enhancing Termination/Emergency Termination.
     * <p>
     * This Method sets the user's Application link to enable or disabled
     * based on status codes
     */
    private boolean isAccountDisabled(ResourceObject object, SailPointContext context) throws GeneralException {
        log.trace("ENTERING isAccountDisabled()");

        // The boolean value that determines if the account is enabled or not
        boolean accountDisabled = false;

        // Get the required identity attribute values and ensure they were retrieved
        String status = Util.otos(object.getAttribute("STATUS"));
        String uid = Util.otos(object.getAttribute("UID"));
        if (Util.isAnyNullOrEmpty(status, uid)) {
            if (Util.isNullOrEmpty(status)) throw new GeneralException("Status is null or empty");
            if (Util.isNullOrEmpty(uid)) throw new GeneralException("UID is null or empty");
        } else {
            log.debug("Successfully fetched identity attribute values 'Status' and 'UID'");

            // The emergency termination flag that may be on the identity
            String emergencyTermFlag = null;

            // Attempt to fetch the identity based on the uid retrieved from ResourceObject
            Identity identity = context.getObjectByName(Identity.class, uid);
            if (identity == null) log.debug("Identity is null");
            else {
                emergencyTermFlag = Util.otos(identity.getAttribute("isEmergencyTerm"));
            }

            log.debug("Begin checking the possible values that determine if the account is disabled");

            // Check if status is 'T'
            if (status.equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_TERMINATED)) {
                log.debug("Status is 'Terminated', account is disabled");
                accountDisabled = true;
            }

            // Check if status is 'I'
            else if (status.equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_INACTIVE)) {
                log.debug("Status is 'Inactive', account is disabled");
                accountDisabled = true;
            }

            // Check if the emergency termination flag is not null
            else if (emergencyTermFlag != null) {
                log.debug("Emergency Termination Flag is not null, account is disabled");
                accountDisabled = true;
            }

            // None of the previous conditions were true so the account is enabled
            else log.debug("Account is enabled");
        }

        log.trace("EXITING isAccountDisabled()");
        return accountDisabled;
    }

    /**
     * This Method is used to calculate the value of the Trigger Flag based on
     * Attributes of Resource Object
     */
    private String checkLifecycleEvents(ResourceObject newIdentity, SailPointContext context) throws Exception {
        log.trace("ENTERING checkLifecycleEvents()");

        // The lifecycle event string to be returned if any of the lifecycle event criteria are met
        String lifecycleEvent = null;

        // Get the Identity Object for previous state reference
        String identityName = newIdentity.getIdentity();
        Identity oldIdentity = context.getObjectByName(Identity.class, identityName);

        log.debug("Beginning to check if the account meets any of the possible lifecycle event criteria");
        if (isPrehire(newIdentity, oldIdentity, context))     lifecycleEvent = THD_Constants_LifecycleEvent.PREHIRE_FLAG;
        else if (isRehire(newIdentity, oldIdentity, context)) lifecycleEvent = THD_Constants_LifecycleEvent.REHIRE_FLAG;
        else if (isJoiner(newIdentity, oldIdentity, context)) lifecycleEvent = THD_Constants_LifecycleEvent.JOINER_FLAG;
        else if (isLeaver(newIdentity, oldIdentity, context)) lifecycleEvent = THD_Constants_LifecycleEvent.LEAVER_FLAG;
        else if (isConSuspension(newIdentity, oldIdentity))   lifecycleEvent = THD_Constants_LifecycleEvent.CONTRACTOR_SUSPENSION_FLAG;
        else if (isLOA(newIdentity, oldIdentity))             lifecycleEvent = THD_Constants_LifecycleEvent.LOA_FLAG;
	else if (isConReinstate(newIdentity, oldIdentity, context))    lifecycleEvent = THD_Constants_LifecycleEvent.CONTRACTOR_REINSTATE_FLAG;
        
		
        else if (isMover(oldIdentity, newIdentity, context)) {
            if (isCorpMover(oldIdentity, newIdentity)) {
                if (isCorpTransferMover(oldIdentity, newIdentity, context))
                    lifecycleEvent = THD_Constants_LifecycleEvent.MOVER_CORP_TRANSFER_FLAG;
                else
                    lifecycleEvent = THD_Constants_LifecycleEvent.MOVER_CORP_FLAG;
            } else if (isCorpToStoreMover(oldIdentity, newIdentity))
                lifecycleEvent = THD_Constants_LifecycleEvent.MOVER_CORP_TO_STORE_FLAG;
            else if (isStoreInternalMover(oldIdentity, newIdentity))
                lifecycleEvent = THD_Constants_LifecycleEvent.MOVER_STORE_INTERNAL_FLAG;
            else if (isStoreToCorpMover(oldIdentity, newIdentity))
                lifecycleEvent = THD_Constants_LifecycleEvent.MOVER_STORE_TO_CORP_FLAG;
            else if (isStoreToStoreMover(oldIdentity, newIdentity))
                lifecycleEvent = THD_Constants_LifecycleEvent.MOVER_STORE_TO_STORE_FLAG;
            else log.debug("isMover was deemed true, but no specific lifecycle event has been true");
        }
        //RLOA will be triggered in the end , do not try to move it up.
        else if(isRLOA(newIdentity, oldIdentity, context)) {
            lifecycleEvent = THD_Constants_LifecycleEvent.RLOA_FLAG;
        }
	

        // Log if the any event criteria were met
        if (lifecycleEvent == null) log.debug("Account did not meet the criteria for any lifecycle events");
        else log.debug("Lifecycle event to be added to account: " + lifecycleEvent);

        // Decache the identity if it is not null
        if (oldIdentity != null) context.decache(oldIdentity);

        log.trace("EXITING checkLifecycleEvents()");
        return lifecycleEvent;
    }

    /**
     *
     *
     * is ROA - This method returns boolean value (true)-
     *      * if the resource object matches with Return of Leave of Absence criteria
     */
    public boolean isRLOA(ResourceObject object, Identity identityObject, SailPointContext context) throws GeneralException, ParseException {
        log.trace("ENTERING isRLOA()");
        if (object == null) {
            log.error("Resource Object is null");
            throw new GeneralException("Resource Object is null");
        }
        String personType = Util.otos(object.getAttribute("PERSON_TYPE"));
        String newStatus = Util.otos(object.getAttribute("STATUS"));
        boolean isRLOA = false;
        if (identityObject != null) {
            if (Util.isNotNullOrEmpty(newStatus) && Util.isNotNullOrEmpty(personType)) {

                // Get the Identity Object for previous state reference
                String identityName = object.getIdentity();
                Identity oldIdentity = context.getObjectByName(Identity.class, identityName);

                 // Associate Condition
                // Current Status - I and New Status is A
                if(personType.equalsIgnoreCase(PERSONA_TYPE_ASSOCIATE))
                {
                    if(Util.isNotNullOrEmpty(oldIdentity.getStringAttribute("status"))
                            && ( oldIdentity.getStringAttribute("status").equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_INACTIVE))
                            && ( newStatus.equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_ACTIVE))
                    ){
                        isRLOA = true;
                    }else {
                        log.debug(" RLOA - does not meet Associate RLOA Criteria");
                    }

                }else {
                    log.debug(" RLOA - Not an Associate");
                }


            } else {
                log.error("Status or personType is null");
                isRLOA = false;
            }
        }
        log.trace("EXITING isRLOA() with value: " + isRLOA);
        return isRLOA;
    }
	
	  public boolean isConReinstate(ResourceObject object, Identity identityObject, SailPointContext context) throws GeneralException, ParseException {
        log.trace("ENTERING isConReinstate()");
        if (object == null) {
            log.error("Resource Object is null");
            throw new GeneralException("Resource Object is null");
        }
        String personType = Util.otos(object.getAttribute("PERSON_TYPE"));
        String newStatus = Util.otos(object.getAttribute("STATUS"));
        boolean isConReinstate = false;
        if (identityObject != null) {
            if (Util.isNotNullOrEmpty(newStatus) && Util.isNotNullOrEmpty(personType)) {

                // Get the Identity Object for previous state reference
                String identityName = object.getIdentity();
                Identity oldIdentity = context.getObjectByName(Identity.class, identityName);

                 // Contractor Condition
                // Current Status - I and New Status is A
                if(personType.equalsIgnoreCase(PERSONA_TYPE_CONTRACTOR))
                {
                    if(Util.isNotNullOrEmpty(oldIdentity.getStringAttribute("status"))
                            && ( oldIdentity.getStringAttribute("status").equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_INACTIVE))
                            && ( newStatus.equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_ACTIVE))
                    ){
                        isConReinstate = true;
                    }else {
                        log.debug(" isConReinstate - does not meet Contractor Reinstate Criteria");
                    }

                }else {
                    log.debug(" isConReinstate - Not an Contractor");
                }


            } else {
                log.error("Status or personType is null");
                isConReinstate = false;
            }
        }
        log.trace("EXITING isConReinstate() with value: " + isConReinstate);
        return isConReinstate;
    }

    private boolean haveIdentityAttributesChanged(Identity oldIdentity, List<String> identityAttributes,
                                                  SailPointContext context, ResourceObject newIdentity)
            throws GeneralException {
        log.trace("ENTERING hasIdentityAttributeChanged()");

        // Flag to be returned if any attributes have changed values
        boolean hasIdentityAttributeChanged = false;

        // Look for any difference in birthright identity attributes between the new and old identity
        for (String identityAttribute : identityAttributes) {

            // Get the corresponding resource object name based on the current identity attribute
            // ex. jobTitle --> JOB_TITLE
            String resourceAttribute = THD_Util_Birthright.getBirthrightResourceAttribute(context, identityAttribute);
            if (Util.isNullOrEmpty(resourceAttribute))
                throw new GeneralException("Failed to retrieved corresponding resource attribute name using " +
                        "the identity attribute '" + identityAttribute + "'");

            // Fetch and show the old and new attribute values
            String oldIdentityAttributeValue = Util.otos(oldIdentity.getAttribute(identityAttribute));
            String newIdentityAttributeValue = Util.otos(newIdentity.getAttribute(resourceAttribute));
            log.debug("Old Identity '" + identityAttribute + "' value --> " + oldIdentityAttributeValue);
            log.debug("New Identity '" + identityAttribute + "' value --> " + newIdentityAttributeValue);

            // Check if the identity has a new attribute it did not used to have
            if (oldIdentityAttributeValue == null && newIdentityAttributeValue != null) {
                log.debug("Identity has had a value added to attribute '" + identityAttribute + "'");
                hasIdentityAttributeChanged = true;
                break;
            }

            // Check if the identity had an attribute removed
            else if (oldIdentityAttributeValue != null && newIdentityAttributeValue == null) {
                log.debug("Identity has had a value removed from attribute '" + identityAttribute + "'");
                hasIdentityAttributeChanged = true;
                break;
            }

            // Check if the attribute value itself has changed
            else if (oldIdentityAttributeValue != null &&
                    !oldIdentityAttributeValue.equals(newIdentityAttributeValue)) {
                log.debug("Identity has had a value changed to attribute '" + identityAttribute + "'");
                hasIdentityAttributeChanged = true;
                break;
            }

            // Otherwise this attribute does not determine if the identity requires mover processing
            else log.debug("The attribute '" + identityAttribute + "' has not changed value");
        }

        if (!hasIdentityAttributeChanged) log.debug("No identity attribute values changed");

        log.trace("EXITING hasIdentityAttributeChanged()");
        return hasIdentityAttributeChanged;
    }

    public boolean startDateWithinRange(Date startDate, long range, SailPointContext context) throws GeneralException {
        if (sdf == null) init(context);

        log.trace("Entering startDateWithinRange");
        boolean dateWithinRange = false;
        Date currentDate = new Date();

        if (startDate == null) {
            log.debug("Start Date is null");
        } else {
            long diffInMillies;
            long sdatems = Long.sum(startDate.getTime(),(long)14400000);
            long cdatems = currentDate.getTime();
            diffInMillies = sdatems - cdatems;
            long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
            log.debug("Current Date: " + sdf.format(currentDate));
            log.debug("Start Date: " + sdf.format(startDate));
            log.debug("Difference: " + diff);
            if (diff <= range) {
                dateWithinRange = true;
            }
        }
        log.trace("Exiting startDateWithinRange with value: " + dateWithinRange);
        return dateWithinRange;
    }

    public boolean isPrehire(ResourceObject object, Identity identityObject, SailPointContext context) throws GeneralException, ParseException {
        log.trace("ENTERING isPrehire()");
        boolean isPrehire = false;

        if (object == null) {
            log.error("Resource Object is null");
            throw new GeneralException("Resource Object is null");
        }
        if (identityObject != null) {
            log.debug("IdentityObject " + identityObject.getName() + " is not null");
            for (Map.Entry<String, Object> e : identityObject.getAttributes().entrySet()) {
                log.debug("Key: " + e.getKey() + "\tValue: " + e.getValue());
            }
        } else {
            log.debug("IdentityObject is null");
        }
        String newStatus = Util.otos(object.getAttribute("STATUS"));
        String newStartDateString = Util.otos(object.getAttribute("CURRENT_HIRE_DATE"));

        Date newStartDate = sdf.parse(newStartDateString);
        long startDateLeadTime = 4;

        if (identityObject == null) {
            //Status is A/H/R and start date > current date - 4
            if (Util.isNotNullOrEmpty(newStatus)) {
                if (newStatus.equals(THD_Constants_General.IDENTITY_STATUS_ACTIVE) || newStatus.equals(THD_Constants_General.IDENTITY_STATUS_PREHIRE) || newStatus.equals(THD_Constants_General.IDENTITY_STATUS_REHIRE)) {
                    if (startDateWithinRange(newStartDate, startDateLeadTime, context)) {
                        log.debug("Start Date within Range");
                        isPrehire = false;
                    } else {
                        log.debug("Start Date not within Range");
                        isPrehire = true;
                    }
                } else {
                    log.debug("Status: " + newStatus + " is not A/H/R");
                    isPrehire = false;
                }
            } else {
                log.error("Status is null");
                isPrehire = false;
            }
        } else {
            //PRE-REHIRE USE CASE
            log.debug("identityObject is not null");
            isPrehire = false;
        }

        log.trace("EXITING isPrehire() with value: " + isPrehire);
        return isPrehire;
    }

    public boolean isJoiner(ResourceObject object, Identity identityObject, SailPointContext context) throws GeneralException, ParseException {
        log.trace("ENTERING isJoiner()");
        //String joinerFlag = THD_Constants_LifecycleEvent.JOINER_FLAG;
        if (object == null) {
            log.error("Resource Object is null");
            throw new GeneralException("Resource Object is null");
        }
        String newStatus = Util.otos(object.getAttribute("STATUS"));
        String newStartDateString = Util.otos(object.getAttribute("CURRENT_HIRE_DATE"));
        Date newStartDate = sdf.parse(newStartDateString);
        long startDateLeadTime = 4;

        boolean isJoiner = false;
        if (identityObject == null) {
            //Status is A/H/R and start date > current date - 5
            if (Util.isNotNullOrEmpty(newStatus)) {
                if (newStatus.equals(THD_Constants_General.IDENTITY_STATUS_ACTIVE) || newStatus.equals(THD_Constants_General.IDENTITY_STATUS_PREHIRE) || newStatus.equals(THD_Constants_General.IDENTITY_STATUS_REHIRE)) {
                    if (startDateWithinRange(newStartDate, startDateLeadTime, context)) {
                        log.debug("Start Date within Range");
                        isJoiner = true;
                    } else {
                        log.debug("Start Date not within Range");
                        isJoiner = false;
                    }
                } else {
                    log.debug("Status: " + newStatus + " is not A/H/R");
                    isJoiner = false;
                }
            } else {
                log.error("Status is null");
                isJoiner = false;
            }
        }
        log.trace("EXITING isJoiner() with value: " + isJoiner);
        return isJoiner;
    }

    /**
     * This method calculates rehire status if meets the predifined conditions
     **/

    public boolean isRehire(ResourceObject object, Identity identityObject,SailPointContext context)throws GeneralException, ParseException  {

        log.trace("ENTERING isRehire()");
        boolean isRehire = false;

        // Check if there is a current identity
        if (identityObject == null)
            log.debug("Identity Object is null in isRehire()");
        else {
            String newStatus = Util.otos(object.getAttribute("STATUS"));
            String oldStatus = Util.otos(identityObject.getAttribute("status"));

            String newStartDateString = Util.otos(object.getAttribute("CURRENT_HIRE_DATE"));
            log.debug("newStatus - oldStatus" + newStatus + "-----" + oldStatus);
            Date newStartDate = sdf.parse(newStartDateString);
            long startDateLeadTime = 5;

            //Status is A/R and start date > current date - 5
            if (Util.isNotNullOrEmpty(newStatus)) {
                if ((newStatus.equals(THD_Constants_General.IDENTITY_STATUS_ACTIVE) || newStatus.equals(THD_Constants_General.IDENTITY_STATUS_REHIRE)) && oldStatus.equals(THD_Constants_General.IDENTITY_STATUS_TERMINATED)) {
                    if (startDateWithinRange(newStartDate, startDateLeadTime, context)) {
                        log.debug("Start Date within Range");
                        isRehire = true;
                    } else {
                        log.debug("Start Date not within Range");
                    }
                } else {
                    log.debug("Status: " + newStatus + " is not A/R");
                }
            } else {
                log.error("Status is null");
            }
        }
        log.trace("Exit isRehire" + isRehire);
        return isRehire;
    }

    public boolean isLOA(ResourceObject object, Identity identityObject)throws GeneralException, ParseException {

        boolean isLOA = false;

        log.trace("Enter isLOARule");
        if (object == null) {
            log.error("Resource Object is null in isLOA()");
            throw new GeneralException("Resource Object is null in isLOA()");
        }
        if (identityObject == null) {
            log.error("Resource Object is null in isLOA()");
            return isLOA;
        }
        String oldStatus = Util.otos(identityObject.getAttribute("status"));
        String newStatus = Util.otos(object.getAttribute("STATUS"));
        String userType = Util.otos(object.getAttribute("PERSON_TYPE"));
        String locationType = Util.otos(object.getAttribute("LOCATION_TYPE"));
        String country = Util.otos(object.getAttribute("COUNTRY_CODE"));
        String isErmFlag = Util.otos(identityObject.getAttribute("isEmergencyTerm"));
        log.debug("oldStatus -->"+ oldStatus);
        log.debug("newStatus -->"+newStatus);
        log.debug("userType  -->"+userType);
       // log.debug("Emergency Termination Flag -->"+isErmFlag);

        if(Util.isNotNullOrEmpty(oldStatus) && Util.isNotNullOrEmpty(newStatus) && Util.isNotNullOrEmpty(userType) && Util.isNullOrEmpty(isErmFlag)){
            if((oldStatus.equals("A") || oldStatus.equals("H") || oldStatus.equals("R")) && newStatus.equals("I") && userType.equals("ASSOCIATE")  &&  ( locationType.equals("CORP") ||  locationType.equals("STR") || locationType.equals("MET") ||  locationType.equals("DC") )  &&( country.equals("US") || country.equals("CA"))){
                log.debug("Exiting isTriggerLOA(): true");
                isLOA= true;
            }
        else{
                log.debug("Exiting isTriggerLOA()1: false");
                isLOA= false;
            }
        }
      else
        {
            log.debug("Exiting isTriggerLOA()2: false");
            isLOA= false;
        }

    return isLOA;
    }



    public boolean isLeaver(ResourceObject object, Identity identityObject,SailPointContext context) throws GeneralException, ParseException  {
        boolean isLeaverTriggering = false;
        if (object == null) {
            log.error("Resource Object is null in isLeaver()");
            throw new GeneralException("Resource Object is null in isLeaver()");
        }
        if (identityObject == null) {
            log.debug("previousIdentity is null\nExiting isTriggerCorpTerm(): false");
            return isLeaverTriggering;
        }

        String oldStatus = Util.otos(identityObject.getAttribute("status"));
        String newStatus = Util.otos(object.getAttribute("STATUS"));
        String userType = Util.otos(object.getAttribute("PERSON_TYPE"));
        String locationType = Util.otos(object.getAttribute("LOCATION_TYPE"));
        String country = Util.otos(object.getAttribute("COUNTRY_CODE"));
        log.debug("oldStatus -->"+ oldStatus);
        log.debug("newStatus -->"+newStatus);
        log.debug("userType  -->"+userType);
        log.debug("locationType  -->"+locationType);
        log.debug("country  -->"+country);

        if(Util.isNotNullOrEmpty(oldStatus) && Util.isNotNullOrEmpty(newStatus) && Util.isNotNullOrEmpty(userType) && Util.isNotNullOrEmpty(locationType) && Util.isNotNullOrEmpty(country)){
            if((oldStatus.equalsIgnoreCase("A") || oldStatus.equalsIgnoreCase("H") || oldStatus.equalsIgnoreCase("R") || oldStatus.equalsIgnoreCase("I")) && newStatus.equalsIgnoreCase("T") && userType.equalsIgnoreCase("ASSOCIATE") && (locationType.equalsIgnoreCase("CORP") || locationType.equalsIgnoreCase("STR") || locationType.equalsIgnoreCase("DC") || locationType.equalsIgnoreCase("MET"))  && (country.equalsIgnoreCase("US") || country.equalsIgnoreCase("CA"))){
                log.debug("Exiting isLeaver(): true");
                isLeaverTriggering= true;
            }
        else if(oldStatus.equalsIgnoreCase("I") && newStatus.equalsIgnoreCase("T") && userType.equalsIgnoreCase("CONTRACTOR") && (locationType.equalsIgnoreCase("CORP") || locationType.equalsIgnoreCase("STR") || locationType.equalsIgnoreCase("DC") || locationType.equalsIgnoreCase("MET"))   && (country.equalsIgnoreCase("US") || country.equalsIgnoreCase("CA"))){
                log.debug("Exiting isLeaver(): true");
                isLeaverTriggering= true;
            }
        else{
                log.debug("Exiting isLeaver(): false");
                isLeaverTriggering= false;
            }
        }
      else
        {
            log.debug("Exiting isLeaver(): false");
            isLeaverTriggering= false;
        }


        return isLeaverTriggering;
    }

    public boolean isConSuspension(ResourceObject object, Identity identityObject) throws GeneralException, ParseException  {
        boolean isConSusTriggering = false;
        if (object == null) {
            log.error("Resource Object is null in isConSuspension()");
            throw new GeneralException("Resource Object is null in isConSuspension()");
        }
        if (identityObject == null) {
            log.debug("previousIdentity is null\nExiting isConSuspension(): false");
            return isConSusTriggering;
        }

        String oldStatus = Util.otos(identityObject.getAttribute("status"));
        String newStatus = Util.otos(object.getAttribute("STATUS"));
        String userType = Util.otos(object.getAttribute("PERSON_TYPE"));
        String locationType = Util.otos(object.getAttribute("LOCATION_TYPE"));
        String country = Util.otos(object.getAttribute("COUNTRY_CODE"));
        String isErmFlag = Util.otos(identityObject.getAttribute("isEmergencyTerm"));

        log.debug("oldStatus -->"+ oldStatus);
        log.debug("newStatus -->"+newStatus);
        log.debug("userType  -->"+userType);
        log.debug("locationType  -->"+locationType);
        log.debug("country  -->"+country);
        log.debug("isErmFlag  -->"+isErmFlag);

        if(Util.isNotNullOrEmpty(oldStatus) && Util.isNotNullOrEmpty(newStatus) && Util.isNotNullOrEmpty(userType) && Util.isNotNullOrEmpty(locationType) && Util.isNotNullOrEmpty(country) && Util.isNullOrEmpty(isErmFlag)){
            if(oldStatus.equalsIgnoreCase("A") && newStatus.equalsIgnoreCase("I") && userType.equalsIgnoreCase("CONTRACTOR") && (locationType.equalsIgnoreCase("CORP") || locationType.equalsIgnoreCase("STR") || locationType.equalsIgnoreCase("DC") || locationType.equalsIgnoreCase("MET"))  && (country.equals("US") || country.equals("CA"))){
                log.debug("Exiting isTriggerContractorSuspension(): true");
                isConSusTriggering= true;
            }
            else {
                    log.debug("Exiting isTriggerContractorSuspension(): false");
                    isConSusTriggering= false;
            }
        }
        else {
            log.debug("Exiting isTriggerContractorSuspension(): false");
            isConSusTriggering= false;
        }

        log.debug("Exiting isTriggerContractorSuspension()");
        return isConSusTriggering;
    }

    private boolean isCorpMover(Identity oldIdentity, ResourceObject newIdentity) {
        log.trace("ENTERING isCorpMover()");

        // Flag to be returned
        boolean isCorpMover = false;

        // Get the new and old identity attribute 'locationType' values
        String newLocationType = Util.otos(newIdentity.getAttribute("LOCATION_TYPE"));
        String oldLocationType = Util.otos(oldIdentity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_TYPE));
        log.debug("New Location Type: " + newLocationType);
        log.debug("Old Location Type: " + oldLocationType);

        log.debug("Checking if the new and old locationType values are equal to 'CORP'");
        if (newLocationType != null && oldLocationType != null &&
                (newLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_CORP) || newLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_MET) || newLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_DC)) &&
                (oldLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_CORP) || oldLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_MET) || oldLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_DC))) {
            log.debug("Identity meets the criteria for a corporate mover");

            // Set the isCorpMover flag to true
            isCorpMover = true;
        }

        // If the previous condition was not true the identity is not a corporate mover
        else log.debug("Identity does not meet the criteria for a corporate mover");

        log.trace("EXITING isCorpMover()");
        return isCorpMover;
    }

    private boolean isCorpToStoreMover(Identity oldIdentity, ResourceObject newIdentity) {
        log.trace("ENTERING isCorpToStoreMover()");

        // Flag to be returned
        boolean isCorpToStoreMover = false;

        // Get the new and old identity attribute 'locationType' values
        String newLocationType = Util.otos(newIdentity.getAttribute("LOCATION_TYPE"));
        String oldLocationType = Util.otos(oldIdentity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_TYPE));
        log.debug("New Location Type: " + newLocationType);
        log.debug("Old Location Type: " + oldLocationType);

        log.debug("Checking if the new locationType value is 'STR' and old 'CORP'");
        if (newLocationType != null && oldLocationType != null &&
                newLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_STORE) &&
                (oldLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_CORP) || oldLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_MET) || oldLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_DC))){
            log.debug("Identity meets the criteria for a corp to store mover");

            // Set the isCorpToStoreMover flag to true
            isCorpToStoreMover = true;
        } else log.debug("The new and old location Type values does not satisfy corp to store mover");

        log.trace("EXITING isCorpToStoreMover()");
        return isCorpToStoreMover;
    }

    private boolean isCorpTransferMover(Identity oldIdentity, ResourceObject newIdentity, SailPointContext context) throws Exception {
        log.trace("ENTERING isCorpTransferMover()");

        // Flag to be returned
        boolean isCorpTransferMover = false;

        // Get the new and old identity attribute 'Manager' values
        String newManager = Util.otos(newIdentity.getAttribute("MANAGER_UID"));
        String oldManager = Util.otos(oldIdentity.getManager() != null ? oldIdentity.getManager().getName() : null);
        log.debug("Old Identity Manager value --> " + oldManager);
        log.debug("New Identity Manager value --> " + newManager);

        // Check if the identity has a new manager
        if (newManager != null && !newManager.equalsIgnoreCase(oldManager)) {
            log.debug("Identity's manager has changed, check if either the associate type, job title, or job " +
                    "designation code has also changed");

            // The list of the three attributes that must be checked
            List<String> attributesToCheck = Arrays.asList(
                    THD_Constants_IdentityAttributes.ASSOCIATE_TYPE,
                    THD_Constants_IdentityAttributes.JOB_DESIGNATION_CODE,
                    THD_Constants_IdentityAttributes.JOB_TITLE);

            // Set the isCorpTransferMover flag by calling method to check attributes for a change in value
            isCorpTransferMover = haveIdentityAttributesChanged(oldIdentity, attributesToCheck, context, newIdentity);
            if (isCorpTransferMover) log.debug("None of the required attributes changed values, not a corp transfer mover");
            else log.debug("At least one of the required attributes has changed values, is a corp transfer mover");
        }
        // If the previous condition was not true the identity is not a corporate transfer mover
        else log.debug("Manager has not changed, not a corp transfer mover");

        log.trace("EXITING isCorpTransferMover()");
        return isCorpTransferMover;
    }

    private boolean isMover(Identity oldIdentity, ResourceObject newIdentity, SailPointContext context) throws GeneralException {
        log.trace("ENTERING isMover()");

        // Flag to be returned
        boolean isMover = false;

        // If the identity does not exist it is not a mover event
        if (oldIdentity == null) log.debug("Old Identity Object is null, not a Mover");
        else {
            log.debug("Old Identity exists in SailPoint, checking if both the new and old identities have a valid status");

            // Get and check that the new and old status values are not null or empty
            String newStatus = Util.otos(newIdentity.getAttribute("STATUS"));
            String oldStatus = Util.otos(oldIdentity.getAttribute(THD_Constants_IdentityAttributes.STATUS));
            if (Util.isAnyNullOrEmpty(newStatus, oldStatus)) {
                if (Util.isNullOrEmpty(newStatus))
                    throw new GeneralException("New status is null or empty");
                throw new GeneralException("Old status is null or empty");
            }

            // Check if the new status values are not equal to 'A', 'H', or 'R' meaning this is not a mover
            else if (!newStatus.equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_ACTIVE) &&
                    !newStatus.equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_PREHIRE) &&
                    !newStatus.equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_REHIRE)) {
                log.debug("The new status is not equal to 'A', 'H', or 'R', not a Mover");
            }

            // Check if the old status values are not equal to 'A', 'H', or 'R' meaning this is not a mover
            else if (!oldStatus.equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_ACTIVE) &&
                    !oldStatus.equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_PREHIRE) &&
                    !oldStatus.equalsIgnoreCase(THD_Constants_General.IDENTITY_STATUS_REHIRE) &&
                    !oldStatus.equalsIgnoreCase("I")) {
                log.debug("The old status is not equal to 'A', 'H', or 'R', not a Mover");
            }

            // If neither of the previous conditions are true then both statuses are valid
            else {
                log.debug("Both new and old identity have a valid status, checking if identity attributes have changed");

                // Get and check that the list of identity attributes was retrieved
                List<String> identityAttributes = THD_Util_Birthright.getBirthrightIdentityAttributes(context);
                if (identityAttributes == null || identityAttributes.isEmpty())
                    throw new GeneralException("Failed to retrieve list of birthright identity attributes");

                // Check if any attribute values have changed, which determines if this is a mover
                isMover = haveIdentityAttributesChanged(oldIdentity, identityAttributes, context, newIdentity);
                if (isMover) log.debug("At least one identity attribute value has changed, is a mover");
                else log.debug("No identity attribute values changed, not a mover");
            }
        }

        log.trace("EXITING isMover()");
        return isMover;
    }

    private boolean isStoreInternalMover(Identity oldIdentity, ResourceObject newIdentity) {
        log.trace("ENTERING isStoreInternalMover()");

        // Flag to be returned
        boolean isStoreInternalMover = false;

        // Get the new and old identity attribute 'locationType' values
        String newLocationType = Util.otos(newIdentity.getAttribute("LOCATION_TYPE"));
        String oldLocationType = Util.otos(oldIdentity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_TYPE));

        log.debug("New Location Type: " + newLocationType);
        log.debug("Old Location Type: " + oldLocationType);

        log.debug("Checking if the new and old locationType values are equal to 'STR'");
        if (newLocationType != null && oldLocationType != null &&
                newLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_STORE) &&
                oldLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_STORE)) {
            log.debug("Identity meets the criteria for a store mover, checking if it is internal");

            // Get the new and old identity attribute 'locationNumber' values
            String newLocationNumber = Util.otos(newIdentity.getAttribute("LOCATION_NUMBER"));
            String oldLocationNumber = Util.otos(oldIdentity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_NUMBER));

            log.debug("Checking if the new and old locationNumber values are not null and equal");
            if (newLocationNumber != null && newLocationNumber.equalsIgnoreCase(oldLocationNumber)) {
                log.debug("Identity meets the criteria for an internal store mover");

                // Set the isInternalStoreMover flag to true
                isStoreInternalMover = true;
            } else log.debug("The new and old locationNumber values are not equal, not an internal store mover");
        } else log.debug("One or both of the locationType values was not equal to 'STR', not an internal store mover");

        log.trace("EXITING isStoreInternalMover()");
        return isStoreInternalMover;
    }

    private boolean isStoreToCorpMover(Identity oldIdentity, ResourceObject newIdentity) {
        log.trace("ENTERING isStoreToCorpMover()");

        // Flag to be returned
        boolean isStoreToCorpMover = false;

        // Get the new and old identity attribute 'locationType' values
        String newLocationType = Util.otos(newIdentity.getAttribute("LOCATION_TYPE"));
        String oldLocationType = Util.otos(oldIdentity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_TYPE));
        log.debug("New Location Type: " + newLocationType);
        log.debug("Old Location Type: " + oldLocationType);

        log.debug("Checking if the new locationType value is equal to 'CORP' and old equal to 'STR'");
        if (newLocationType != null && oldLocationType != null &&
                (newLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_CORP) || newLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_DC) || newLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_MET)) &&
                oldLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_STORE)) {
            log.debug("Identity meets the criteria for a corp to store mover");

            // Set the isCorpToStoreMover flag to true
            isStoreToCorpMover = true;
        } else log.debug("The locationType values do not satisfy required conditions, not a store to corp mover");

        log.trace("EXITING isStoreToCorpMover()");
        return isStoreToCorpMover;
    }

    private boolean isStoreToStoreMover(Identity oldIdentity, ResourceObject newIdentity) {
        log.trace("ENTERING isStoreToStoreMover()");

        // Flag to be returned
        boolean isStoreToStoreMover = false;

        // Get the new and old identity attribute 'locationType' values
        String newLocationType = Util.otos(newIdentity.getAttribute("LOCATION_TYPE"));
        String oldLocationType = Util.otos(oldIdentity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_TYPE));
        log.debug("New Location Type: " + newLocationType);
        log.debug("Old Location Type: " + oldLocationType);

        log.debug("Checking if the new and old locationType values are equal to 'STR'");
        if (newLocationType != null && oldLocationType != null &&
                newLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_STORE) &&
                oldLocationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_STORE)) {
            log.debug("Identity meets the criteria for a store mover, checking if it is store to store");

            // Get the new and old identity attribute 'locationNumber' values
            String newLocationNumber = Util.otos(newIdentity.getAttribute("LOCATION_NUMBER"));
            String oldLocationNumber = Util.otos(oldIdentity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_NUMBER));

            log.debug("Checking if the new and old locationNumber values are not null and not equal");
            if (newLocationNumber != null && !newLocationNumber.equalsIgnoreCase(oldLocationNumber)) {
                log.debug("Identity meets the criteria for a store to store mover");

                // Set the isStoreToStoreMover flag to true
                isStoreToStoreMover = true;
            } else log.debug("The new and old locationNumber values are equal, not a store to store mover");
        } else log.debug("One or both of the locationType values was not equal to 'STR', not a store to store mover");

        log.trace("EXITING isStoreToStoreMover()");
        return isStoreToStoreMover;
    }

    private String reconcileLifecycleEvents(String newLifecycleEvent, String currentLifecycleEvent){
        log.trace("ENTERING reconcileLifecycleEvents()");
        log.debug("currentLifecycleEvent: " + currentLifecycleEvent);
        log.debug("newLifecycleEvent: " + newLifecycleEvent);

        // The final lifecycle event to be returned after comparing the old and the new
        String lifecycleEvent=THD_Constants_LifecycleEvent.NONE_FLAG;

        //If new is null/empty or "None" return current
        if (Util.isNullOrEmpty(newLifecycleEvent) || newLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.NONE_FLAG)) {
            lifecycleEvent = currentLifecycleEvent;
            log.debug("1: Lifecycle Event: " + lifecycleEvent);
        }
        //if current is null/empty or "None" return new
        else if (Util.isNullOrEmpty(currentLifecycleEvent) || currentLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.NONE_FLAG)){
            lifecycleEvent = newLifecycleEvent;
            log.debug("2: Lifecycle Event: " + lifecycleEvent);
        }
        //if current = new
        else if (newLifecycleEvent.equalsIgnoreCase(currentLifecycleEvent)){
            lifecycleEvent = newLifecycleEvent;
            log.debug("3: Lifecycle Event: " + lifecycleEvent);
        }
        //If new event is leaver then overwrite existing with leaver
        else if (newLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.LEAVER_FLAG)){
            lifecycleEvent = newLifecycleEvent;
            log.debug("4: Lifecycle Event: " + lifecycleEvent);
        }
		 else if (newLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.CONTRACTOR_REINSTATE_FLAG)){
            lifecycleEvent = newLifecycleEvent;
            log.debug("5: Lifecycle Event: " + lifecycleEvent);
        }
		else if (newLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.RLOA_FLAG)){
            lifecycleEvent = newLifecycleEvent;
            log.debug("6: Lifecycle Event: " + lifecycleEvent);
        }
        //If new event is LOA then overwrite existing with LOA
        else if (newLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.LOA_FLAG) || newLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.CONTRACTOR_SUSPENSION_FLAG)){
            lifecycleEvent = newLifecycleEvent;
            log.debug("5: Lifecycle Event: " + lifecycleEvent);
        }
		
        //If current event is Joiner and new is not leaver or loa then return joiner
        else if (currentLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.JOINER_FLAG)){
            lifecycleEvent = currentLifecycleEvent;
            log.debug("6: Lifecycle Event: " + lifecycleEvent);
        }
        //If current is Prehire and new is Joiner then return Joiner
        //If current is Prehire and new is Mover_ then return Prehire
        else if (currentLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.PREHIRE_FLAG)){
            if (newLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.JOINER_FLAG))
                lifecycleEvent = newLifecycleEvent;
            else if (newLifecycleEvent.contains(THD_Constants_LifecycleEvent.MOVER_FLAG))
                lifecycleEvent = currentLifecycleEvent;
            log.debug("7: Lifecycle Event: " + lifecycleEvent);
        }
        //If current is mover_
        else if (currentLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.MOVER_CORP_TO_STORE_FLAG)) {
            if (newLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.MOVER_STORE_TO_CORP_FLAG))
                lifecycleEvent = THD_Constants_LifecycleEvent.MOVER_CORP_FLAG;
            else
                lifecycleEvent = currentLifecycleEvent;
            log.debug("8: Lifecycle Event: " + lifecycleEvent);
        }
        else if (currentLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.MOVER_STORE_TO_CORP_FLAG)){
            if (newLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.MOVER_CORP_TO_STORE_FLAG))
                lifecycleEvent = THD_Constants_LifecycleEvent.MOVER_STORE_INTERNAL_FLAG;
            else
                lifecycleEvent = currentLifecycleEvent;
            log.debug("9: Lifecycle Event: " + lifecycleEvent);
        }
        else if (currentLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.MOVER_STORE_TO_STORE_FLAG)){
            if (newLifecycleEvent.equalsIgnoreCase(THD_Constants_LifecycleEvent.MOVER_STORE_TO_CORP_FLAG))
                lifecycleEvent = newLifecycleEvent;
            else
                lifecycleEvent = currentLifecycleEvent;
            log.debug("10: Lifecycle Event: " + lifecycleEvent);
        }
        else {
            lifecycleEvent = newLifecycleEvent;
            log.debug("11: Lifecycle Event: " + lifecycleEvent);
        }
        log.trace("EXITING reconcileLifecycleEvents()");
        return lifecycleEvent;
    }
}
package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_LifecycleEvent;
import com.ey.iiq.util.THD_Util_Birthright;
import com.magnolia.iiq.build.Rule;
import java.util.*;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

@Rule(name="THD-RuleLibrary-LCE-Mover", filename="THD-RuleLibrary-LCE-Mover.xml", library=true)
public class THD_RuleLibrary_LCE_Mover {

    private static Logger log;

    /**
     * Setting initial log features
     */
    public void setLogLevel() {
        log = Logger.getLogger("thd.iam.THD-RuleLibrary-LCE-Mover");
        log.setLevel(Level.TRACE);
    }

    /**
     * Starting point for Mover; We will call this Rule from workflow and create Prov plan here that will be passed on in the next step
      * @param context - SailPoint Context
     * @param identityName - Identity Name
     * @return - Prov plan with all account requests that will be processed in next step of the workflow
     * @throws Exception - General Exception
     */
    public ProvisioningPlan processMoverLCE(SailPointContext context, String identityName) throws Exception {
        setLogLevel();
        log.trace("ENTERING processMoverLCE()");

        // Check if the required identityName is present
        if (Util.isNullOrEmpty(identityName))
            throw new GeneralException("Identity name is null or empty when attempting to process mover");

        // Fetch the Identity object and ensure it was retrieved
        Identity identity = context.getObjectByName(Identity.class, identityName);
        if (identity == null)
            throw new GeneralException("Failed to find identity named '" + identityName + "' in SailPoint");

        // Get the list of all birthright applications
        List<String> birthrightApplications = THD_Util_Birthright.getBirthrightApplications(context);
        if (birthrightApplications == null)
            throw new GeneralException("Failed to get list of all birthright applications");
        log.debug("The list of all birthright applications:\n" + birthrightApplications);

        // Get the mover type from the identity's 'eventToBeTriggered' attribute
        String moverType = Util.otos(identity.getAttribute(THD_Constants_LifecycleEvent.EVENT_TO_BE_TRIGGERED_KEY));
        if (Util.isNullOrEmpty(moverType))
            throw new GeneralException("Failed to get mover type off of identity '" + identityName + "'");
        log.debug("Identity '" + identityName + "' has a Mover Type '" + moverType + "'");

        // Set initial plan variables
        ProvisioningPlan plan = new ProvisioningPlan();
        plan.setIdentity(identity);
        List<ProvisioningPlan.AccountRequest> acctReqs = new ArrayList<>();

        // Iterate through all the birthright applications and process each one as necessary
        for (String birthrightApplication : birthrightApplications) {
            log.debug("Processing birthright application '" + birthrightApplication + "' for identity '" + identityName + "'");

            // Variables required to add the account request
            boolean currentAccountDisabled = false;
            Link currentAccount = null;
            Link oldAccount = null;
            ProvisioningPlan.AccountRequest acctReq;
            String currentNativeIdentity;
            String oldNativeIdentity = null;

            log.debug("Get the native identity value that will match on a current account, or be used to create one");
            currentNativeIdentity = getNativeIdentity(context, birthrightApplication, identity, null);
            if (Util.isNullOrEmpty(currentNativeIdentity)) {
                log.error("Failed to create current native identity value for '" + identityName + "' on '" +
                        birthrightApplication + "'");

                // Use the identity name as the default native identity in case of failure
                currentNativeIdentity = identityName;
            }

            log.debug("Check if the identity already has an account on the current birthright application");
            for (Link link : identity.getLinks()) {
                if (link == null) log.error("Null Link found on identity '" + identityName + "'");

                // Check if the current birthright application name matches the one on the link
                else if (birthrightApplication.equalsIgnoreCase(link.getApplicationName())) {

                    // Check if the current native identity matches the one on the link (is this the current account)
                    if (currentNativeIdentity.equalsIgnoreCase(link.getNativeIdentity())) {
                        currentAccount = link;
                        currentAccountDisabled = link.isDisabled();

                        // Check if the current account is disabled or not
                        if (currentAccountDisabled) log.debug("Found current account link that is disabled");
                        else log.debug("Found current account link that is enabled");
                    }

                    // If the current native identity does not match the one on the link, check if the link is enabled
                    // (is this the link that needs to be disabled/deleted in the case of a non-internal mover)
                    else if (!link.isDisabled()) {
                        log.debug("Found enabled account link that does not match current native identity");

                        oldAccount = link;
                        oldNativeIdentity = link.getNativeIdentity();

                        // TODO Nothing in this file should be application specific
                        if (birthrightApplication.equalsIgnoreCase("%%AD_APPLICATION_NAME%%")) {
                            log.debug("Unmatched Link is for AD, will handle in Modify");

                            currentAccount = link;
                        }
                    }
                }
            }

            log.debug("Check if the current birthright application requires disable on delete");
            boolean disableOnDelete = THD_Util_Birthright.getRequiresDisableOnDelete(context, birthrightApplication);

            log.debug("Check if the identity meets the criteria for an account on the current birthright application");
            boolean getsByBirthright = THD_Util_Birthright.identityMeetsBirthrightAccountCriteria(
                    context, birthrightApplication, identityName);

            /* ----------------------------------------- CREATE -----------------------------------------
                Identity gets an account by birthright
                Identity does not have a current account
            */
            if (getsByBirthright && currentAccount == null) {
                log.debug("Operation is 'Create', will use current native identity '" + currentNativeIdentity +
                        "' in account request");

                acctReq = new ProvisioningPlan.AccountRequest(ProvisioningPlan.AccountRequest.Operation.Create,
                        birthrightApplication, null, currentNativeIdentity);
                acctReqs.add(acctReq);
            }

            /* ----------------------------------------- ENABLE -----------------------------------------
                Identity gets an account by birthright
                Identity has a current account (implied by next)
                The current account is disabled
            */
            else if (getsByBirthright && currentAccountDisabled) {
                log.debug("Operation is 'Enable', will use current native identity '" + currentNativeIdentity +
                        "' in account request");

                if(birthrightApplication.equalsIgnoreCase("SCORE-CAN")){


                    log.debug("currentAccountDisabled FOR SAP");

                    // Fetch the rule object using the rule name
                    String ruleName = "THD-Rule-Mover-RemoveEntitlements";
                    sailpoint.object.Rule rule = context.getObjectByName(sailpoint.object.Rule.class, ruleName);
                    if (rule == null) log.warn("Unable to retrieve Rule object using rule name '" + ruleName + "'");
                    else {
                        log.debug("currentAccountDisabled is disabled Successfully retrieved Rule object using rule name '" + ruleName + "'");

                        // Create the rule parameters that will be passed in to the rule
                        Map ruleParams = new HashMap();
                        ruleParams.put("context", context);
                        ruleParams.put("identityName", identityName);
                        ruleParams.put("nativeId", currentNativeIdentity);
                        ruleParams.put("appName", birthrightApplication);

                        log.debug("currentAccountDisabled Calling rule specific for SAP event");
                        List acctReqsSAP=(List)context.runRule(rule,ruleParams);
                        if (acctReqsSAP == null) {
                            log.debug("currentAccountDisabled Null account requests returned from SAP Mover Rule");
                        }
                        else {
                            log.debug("currentAccountDisabled Adding SAP specific account requests to current overall one for SAP");
                            acctReqs.addAll(acctReqsSAP);
                        }
                    }


                }
                else{
                    acctReq=new ProvisioningPlan.AccountRequest(ProvisioningPlan.AccountRequest.Operation.Enable,birthrightApplication,null,currentNativeIdentity);
                    acctReqs.add(acctReq);
                }
            }

            /* ----------------------------------------- DELETE -----------------------------------------
                EITHER
                    Identity does not get an account by birthright
                    Identity has a current account
                    The current account is not disabled
                    The current application does not require disable on delete
                OR
                    There is an old account (one that does not match on nativeIdentity, but is enabled)
                    The current application does not require disable on delete
            */
            // TODO Nothing in this file should be application specific
            if ((!getsByBirthright && currentAccount != null && !currentAccountDisabled && !disableOnDelete) ||
                    (oldAccount != null && !disableOnDelete &&
                    !birthrightApplication.equalsIgnoreCase("%%AD_APPLICATION_NAME%%"))) {
                log.debug("Operation is 'Delete'");

                // Use the oldAccount value to determine how to create the account request
                if (oldAccount != null) {
                    log.debug("Will use old native identity '" + oldNativeIdentity + "' in account request");

                    acctReq = new ProvisioningPlan.AccountRequest(ProvisioningPlan.AccountRequest.Operation.Delete,
                            birthrightApplication, null, oldNativeIdentity);
                }

                // Use the currentAccount value if the old one is null (the nativeIdentity not based on location number)
                else {
                    log.debug("Will use current native identity '" + currentNativeIdentity + "' in account request");

                    acctReq = new ProvisioningPlan.AccountRequest(ProvisioningPlan.AccountRequest.Operation.Delete,
                            birthrightApplication, null, currentNativeIdentity);
                }

                // Add the current 'Delete' account request to the list of requests
                acctReqs.add(acctReq);
            }

            /* ----------------------------------------- DISABLE -----------------------------------------
                EITHER
                    Identity does not get an account by birthright
                    Identity has a current account
                    The current account is not disabled
                    The current application requires disable on delete (implied by not going into DELETE)
                OR
                    There is an old account (one that does not match on nativeIdentity, but is enabled)
                    The current application requires disable on delete (implied by not going into DELETE)
            */
            // TODO Nothing in this file should be application specific
            else if ((!getsByBirthright && currentAccount != null && !currentAccountDisabled) ||
                    (oldAccount != null && !birthrightApplication.equalsIgnoreCase("%%AD_APPLICATION_NAME%%"))) {
                log.debug("Operation is 'Disable'");

                // Variables used to remove the old entitlements
                Application application;
                List<Entitlement> entitlements;
                List<String> entitlementsToRemove = new ArrayList<>();

                // Use the oldAccount value to determine how to create the account request and get the correct entitlements
                if (oldAccount != null) {
                    log.debug("Will use old native identity '" + oldNativeIdentity + "' in account request");
                    acctReq = new ProvisioningPlan.AccountRequest(ProvisioningPlan.AccountRequest.Operation.Disable,
                            birthrightApplication, null, oldNativeIdentity);

                    // Set the required values to remove entitlements
                    application = oldAccount.getApplication();
                    entitlements = oldAccount.getEntitlements(Locale.getDefault(), null);
                }

                // Use the currentAccount value if the old one is null (the nativeIdentity not based on location number)
                else {
                    log.debug("Will use current native identity '" + currentNativeIdentity + "' in account request");
                    acctReq = new ProvisioningPlan.AccountRequest(ProvisioningPlan.AccountRequest.Operation.Disable,
                            birthrightApplication, null, currentNativeIdentity);

                    // Set the required values to remove entitlements
                    application = currentAccount.getApplication();
                    entitlements = currentAccount.getEntitlements(Locale.getDefault(), null);
                }

                // TODO Nothing in this file should be application specific
                // If this is an SAP Disable event we need to remove entitlements using a different method
                if (birthrightApplication.equalsIgnoreCase("%%SAP_APPLICATION_NAME%%")) {
                    log.debug("This is an SAP Disable event");

                    // Fetch the rule object using the rule name
                    String ruleName = "THD-Rule-Mover-RemoveEntitlements";
                    sailpoint.object.Rule rule = context.getObjectByName(sailpoint.object.Rule.class, ruleName);
                    if (rule == null) log.warn("Unable to retrieve Rule object using rule name '" + ruleName + "'");
                    else {
                        log.debug("Successfully retrieved Rule object using rule name '" + ruleName + "'");

                        // Create the rule parameters that will be passed in to the rule
                        Map<String, Object> ruleParams = new HashMap<>();
                        ruleParams.put("context", context);
                        ruleParams.put("identityName", identityName);
                        ruleParams.put("nativeId", currentNativeIdentity);
                        ruleParams.put("appName", birthrightApplication);

                        log.debug("Calling rule specific for SAP event");
                        List<ProvisioningPlan.AccountRequest> acctReqsSAP =
                                (List<ProvisioningPlan.AccountRequest>) context.runRule(rule, ruleParams);
                        if (acctReqsSAP == null) log.debug("Null account requests returned from SAP Mover Rule");
                        else {
                            log.debug("Adding SAP specific account requests to current overall one for SAP");
                            acctReqs.addAll(acctReqsSAP);
                        }
                    }
                }

                // Check if there are entitlements that need to be removed in the 'Disable' attribute request
                else if (entitlements == null || entitlements.isEmpty())
                    log.debug("No entitlements were found on the account so none need to be removed");
                else {
                    log.debug("Beginning process of setting the list of entitlements to remove");

                    // Add all entitlement names to the list of entitlement strings if they aren't null
                    for (Entitlement entitlement : entitlements) {
                        if (entitlement == null) log.warn("Encountered null Entitlement");
                        else entitlementsToRemove.add(entitlement.getAttributeValue());
                    }

                    // Recheck if there are still entitlements to be removed in the list of strings
                    if (!entitlementsToRemove.isEmpty()) {

                        // Get the group attribute off of the application (assume only one)
                        if (application.getGroupAttributes() == null || application.getGroupAttributes().isEmpty())
                            throw new GeneralException("Failed to find a group attribute on application '" +
                                    birthrightApplication + "'");

                        String groupAttributeName = application.getGroupAttributes().get(0).getName();
                        log.debug("Successfully found group attribute name '" + groupAttributeName + "' on application");

                        log.debug("Removing the following entitlements from the identity's '" +
                                birthrightApplication + "' account:\n" + entitlementsToRemove);
                        acctReq.add(new ProvisioningPlan.AttributeRequest(groupAttributeName,
                                ProvisioningPlan.Operation.Remove, entitlementsToRemove));
                    }
                }

                // Add the current 'Disable' account request to the list of requests
                acctReqs.add(acctReq);
            }

            /* ----------------------------------------- MODIFY -----------------------------------------
                Identity gets an account by birthright
                Identity has a current account
                The current account is not disabled
            */
            if (getsByBirthright && currentAccount != null && !currentAccountDisabled) {

                // TODO Nothing in this file should be application specific
                // If this is an AD Mover event where an oldAccount exists, update the OU and use oldNativeIdentity
                if (birthrightApplication.equalsIgnoreCase("%%AD_APPLICATION_NAME%%") && oldAccount != null) {
                    log.debug("Operation is 'Modify', this is an AD Mover event that requires an update to the Account's " +
                            "OU, will use old native identity'" + oldNativeIdentity + "' in account request");

                    // Initialize the current account request for the application
                    acctReq = new ProvisioningPlan.AccountRequest(ProvisioningPlan.AccountRequest.Operation.Modify,
                            birthrightApplication, null, oldNativeIdentity);

                    // Get the new OU to be used from the currentNativeIdentity
                    String updatedOU = currentNativeIdentity.substring(currentNativeIdentity.toUpperCase().indexOf("OU="));
                    log.debug("Updated OU: " + updatedOU);

                    acctReq.add(new ProvisioningPlan.AttributeRequest("AC_NewParent",
                            ProvisioningPlan.Operation.Set, updatedOU));
                }

                else {
                    log.debug("Operation is 'Modify', will use current native identity '" + currentNativeIdentity +
                            "' in account request");

                    // Initialize the current account request for the application
                    acctReq = new ProvisioningPlan.AccountRequest(ProvisioningPlan.AccountRequest.Operation.Modify,
                            birthrightApplication, null, currentNativeIdentity);

                    // Add a dummy value in order to trigger the update policy when no entitlements are added
                    acctReq.add(new ProvisioningPlan.AttributeRequest());
                }

                // TODO Nothing in this file should be application specific
                // If this is an SAP Mover we need to remove entitlements using a different method
                if (birthrightApplication.equalsIgnoreCase("%%SAP_APPLICATION_NAME%%")) {
                    log.debug("This is an SAP Mover event");

                    // Fetch the rule object using the rule name
                    String ruleName = "THD-Rule-Mover-RemoveEntitlements";
                    sailpoint.object.Rule rule = context.getObjectByName(sailpoint.object.Rule.class, ruleName);
                    if (rule == null) log.warn("Unable to retrieve Rule object using rule name '" + ruleName + "'");
                    else {
                        log.debug("Successfully retrieved Rule object using rule name '" + ruleName + "'");

                        // Create the rule parameters that will be passed in to the rule
                        Map<String, Object> ruleParams = new HashMap<>();
                        ruleParams.put("context", context);
                        ruleParams.put("identityName", identityName);
                        ruleParams.put("nativeId", currentNativeIdentity);
                        ruleParams.put("appName", birthrightApplication);

                        log.debug("Calling rule specific for SAP event");
                        List<ProvisioningPlan.AccountRequest> acctReqsSAP =
                                (List<ProvisioningPlan.AccountRequest>) context.runRule(rule, ruleParams);
                        if (acctReqsSAP == null) log.debug("Null account requests returned from SAP Mover Rule");
                        else {
                            log.debug("Adding SAP specific account requests to current overall one for SAP");
                            acctReqs.addAll(acctReqsSAP);
                        }
                    }
                }

                // Only attempt to manipulate entitlements if the application has a corresponding birthright table
                else if (THD_Util_Birthright.hasBirthrightTable(context, birthrightApplication)) {
                    log.debug("Begin process of getting the identity's birthright entitlements");

                    // Get the group attribute off of the application (assume only one)
                    Application application = currentAccount.getApplication();
                    if (application.getGroupAttributes() == null || application.getGroupAttributes().isEmpty())
                        throw new GeneralException("Failed to find a group attribute on application '" +
                                birthrightApplication + "'");

                    String groupAttributeName = application.getGroupAttributes().get(0).getName();
                    log.debug("Successfully found group attribute name '" + groupAttributeName + "' on application");

                    // Get the required values from SailPoint Custom Objects
                    List<String> identityAttributes = THD_Util_Birthright.getBirthrightIdentityAttributes(context);
                    String birthrightTableName = THD_Util_Birthright.getBirthrightTableName(context, birthrightApplication);

                    // Check if the required values were retrieved from Custom Objects
                    if (Util.isNullOrEmpty(birthrightTableName) ||
                            identityAttributes == null || identityAttributes.isEmpty()) {
                        if (Util.isNullOrEmpty(birthrightTableName))
                            throw new GeneralException("Failed to retrieve birthright table name");
                        throw new GeneralException("Failed to retrieve birthright identity attributes");
                    }
                    log.debug("Successfully retrieved required values from Custom Objects");

                    log.debug("Get the birthright entitlements using the birthright utility");
                    List<String> birthrightEntitlements = THD_Util_Birthright.getBirthrightEntitlements(
                            true, identity, identityAttributes, context,
                            birthrightApplication, birthrightTableName, groupAttributeName);

                    // Check if the birthright entitlements were retrieved successfully
                    if (birthrightEntitlements == null)
                        throw new GeneralException("Failed to get birthright entitlements");
                    else if (birthrightEntitlements.isEmpty())
                        log.debug("No birthright entitlements were found for the account");
                    else
                        log.debug("List of birthright entitlements for account:\n" + birthrightEntitlements);

                    log.debug("Begin process of getting the identity's current entitlements");
                    List<String> currentEntitlements = new ArrayList<>();
                    List<Entitlement> entitlements = currentAccount.getEntitlements(Locale.getDefault(), null);

                    // Add the entitlement names from the objects to the list of current entitlements
                    if (entitlements == null || entitlements.isEmpty())
                        log.debug("No current entitlements found");
                    else {
                        for (Entitlement entitlement : entitlements) {
                            if (entitlement == null) log.warn("Encountered null Entitlement");
                            else currentEntitlements.add(entitlement.getAttributeValue());
                        }

                        log.debug("List of current entitlements on account:\n"+ currentEntitlements);
                    }

                    log.debug("Transform the birthright entitlements and current entitlements to uppercase");
                    // TODO when/if this is turned into a java class the following should be used instead
                    //birthrightEntitlements.replaceAll(String::toUpperCase);
                    //currentEntitlements.replaceAll(String::toUpperCase);
                    for (int i=0; i < birthrightEntitlements.size(); i++) {
                        birthrightEntitlements.set(i, birthrightEntitlements.get(i).toUpperCase());
                    }
                    for (int i=0; i < currentEntitlements.size(); i++) {
                        currentEntitlements.set(i, currentEntitlements.get(i).toUpperCase());
                    }

                    log.debug("Calculate the entitlements to add to the account");
                    List<String> entitlementsToAdd = new ArrayList<>(birthrightEntitlements);
                    entitlementsToAdd.removeAll(currentEntitlements);

                    // Check if any entitlements are required to be added to the account
                    if (entitlementsToAdd.isEmpty())
                        log.debug("No entitlements are required to be added to the identity's '" +
                                birthrightApplication + "' account ");
                    else {
                        log.debug("Adding the following entitlements to the identity's '" + birthrightApplication +
                                "' account:\n" + entitlementsToAdd);

                        acctReq.add(new ProvisioningPlan.AttributeRequest(groupAttributeName,
                                ProvisioningPlan.Operation.Add, entitlementsToAdd));
                    }

                    // Check if the current mover type requires non-birthright entitlements be removed
                    if (Util.isNullOrEmpty(moverType))
                        log.warn("The 'eventToBeTriggered' attribute should never be null during an update");
                    else if (!moverType.equalsIgnoreCase(THD_Constants_LifecycleEvent.MOVER_CORP_TO_STORE_FLAG) &&
                            !moverType.equalsIgnoreCase(THD_Constants_LifecycleEvent.MOVER_STORE_TO_CORP_FLAG) &&
                            !moverType.equalsIgnoreCase(THD_Constants_LifecycleEvent.MOVER_STORE_TO_STORE_FLAG))
                        log.debug("The 'eventToBeTriggered' attribute does not require any entitlements be removed here");
                    else {
                        log.debug("The 'eventToBeTriggered' attribute is '" + moverType +
                                "' so all non-birthright entitlements must be removed from the account");

                        log.debug("Calculate the entitlements to remove from the account");
                        List<String> entitlementsToRemove = new ArrayList<>(currentEntitlements);
                        entitlementsToRemove.removeAll(birthrightEntitlements);

                        // Check if any entitlements are required to be removed from the account
                        if (entitlementsToRemove.isEmpty())
                            log.debug("No entitlements are required to be removed from the identity's '" +
                                    birthrightApplication + "' +account ");
                        else {
                            log.debug("Removing the following entitlements from the identity's '" +
                                    birthrightApplication + "' account:\n" + entitlementsToRemove);

                            acctReq.add(new ProvisioningPlan.AttributeRequest(groupAttributeName,
                                    ProvisioningPlan.Operation.Remove, entitlementsToRemove));
                        }
                    }
                }
                acctReqs.add(acctReq);
            }
        }

        // Add the list of account requests to the plan to be returned
        plan.setAccountRequests(acctReqs);

        log.trace("EXITING processMoverLCE()");
        return plan;
    }

    public static String getNativeIdentity(SailPointContext context, String appName, Identity identity, Link link)
            throws Exception
    {
        log.trace("Enter getNativeIdentity");
        String nativeId = "";
        String current = null;
        if (link != null)
        {
            current = link.getNativeIdentity();
            log.debug("Passed in Link: " + current);
        }
        if ((appName != null) && (appName.length() > 0) && (identity != null))
        {
            Application app = context.getObjectByName(Application.class, appName);
            if (app != null)
            {
                Schema schema = app.getAccountSchema();
                String identityAttributeField = schema.getIdentityAttribute();
                List<Template> templates = app.getTemplates();
                Template updateTemp = null;
                Template temp;
                if ((templates != null) && (templates.size() > 0))
                {
                    for (Template template : templates) {
                        temp = template;
                        Template.Usage usage = temp.getUsage();
                        if ((temp.getSchemaObjectType().equalsIgnoreCase("account")) &&
                                (usage.equals(Template.Usage.Create))) {
                            updateTemp = temp;
                            break;
                        }
                    }
                    if (updateTemp != null)
                    {
                        List <sailpoint.object.Field> fields = updateTemp.getFields(context);
                        if ((fields != null) && (fields.size() > 0)) {
                            for ( Field field : fields)
                            {
                                String fieldName = field.getName();
                                String displayName = field.getDisplayName();
                                if ((identityAttributeField != null) &&
                                        (identityAttributeField.compareTo(fieldName) == 0))
                                {
                                    HashMap params = new HashMap();
                                    params.put("context", context);
                                    params.put("identity", identity);
                                    params.put("field", field);
                                    params.put("accountRequest", null);
                                    params.put("application", app);
                                    params.put("current", current);
                                    params.put("link", link);
                                    params.put("group", null);
                                    params.put("objectRequest", null);
                                    params.put("operation", null);
                                    params.put("project", null);
                                    params.put("role", null);
                                    params.put("template", updateTemp);
                                    sailpoint.object.Rule rule = field.getFieldRule();
                                    if (rule != null) {
                                        try
                                        {
                                            nativeId = (String)context.runRule(rule, params);
                                        }
                                        catch (Exception re)
                                        {
                                            log.trace( "*** EXCEPTION RUNNING RULE/SCRIPT: " + re
                                                    .toString());
                                        }
                                    } else if (field.getScript() != null) {
                                        try
                                        {
                                            nativeId = (String)context.runScript(field.getScript(), params);
                                        }
                                        catch (Exception re)
                                        {
                                            log.trace("*** EXCEPTION RUNNING SCRIPT: " + re
                                                    .toString());
                                        }
                                    } else {
                                        nativeId = (String)field.getValue();
                                    }
                                }
                            }
                        }
                    }
                }
                context.decache(app);
            }
        }
        log.trace("Exit getNativeIdentity = " + nativeId);
        return nativeId;
    }
}
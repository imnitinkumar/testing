package com.ey.iiq.sp2xml;

import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.integration.RequestResult;
import sailpoint.object.Application;
import sailpoint.object.Attributes;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningResult;
import workday.com.Provsioning_Group_Assignment_Request_ReferencesType;

@Rule(name="THD-Rule-AfterProvisioning-BadgingIntegration", filename="THD-Rule-AfterProvisioning-BadgingIntegration.xml", type = "AfterProvisioning")
public class THD_Rule_AfterProvisioning_BadgingIntegration {

    /**
     * An IdentityIQ server-side rule that is executed after the connector's provisioning method is called
     * This gives the customer the ability to customize or react to anything in the ProvisioningPlan AFTER it has been sent out to the specific applications
     * This rule will be called for any application found in a plan that also has a configured 'afterProvisioningRule' configured.
     *
     * @param plan        The ProvisioningPlan object on its way to the Connector.
     * @param application The application object that references this before/after script.
     * @param result      The ProvisioningResult object returned by the connectors provision method. This can be null and in many cases the connector will not return a result and instead will annotate the plan's ProvisioningResult either at the plan or account level.
     */
    public static void afterProvisioning(ProvisioningPlan plan, Application application, ProvisioningResult result) {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-AfterProvisioning-BadgingIntegration");
        log.setLevel(Level.TRACE);
        log.trace("ENTERING THD-Rule-AfterProvisioning-BadgingIntegration");
        log.debug("Plan Arguments");
        log.debug(plan.getArguments().getOriginalXml());

        if (ProvisioningResult.STATUS_COMMITTED.equals(result.getStatus())){
            log.debug("provisioning result status = committed");
        }
        log.trace("EXITING THD-Rule-AfterProvisioning-BadgingIntegration");
    }
}

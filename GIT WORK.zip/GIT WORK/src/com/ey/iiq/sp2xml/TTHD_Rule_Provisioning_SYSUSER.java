package com.ey.iiq.sp2xml;

import com.magnolia.iiq.build.Rule;
import sailpoint.object.Application;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningResult;
import sailpoint.object.Schema;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.ParseException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import sailpoint.api.SailPointContext;
import sailpoint.connector.JDBCConnector;
import sailpoint.object.Application;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.ProvisioningPlan.AttributeRequest;
import sailpoint.object.ProvisioningPlan.PermissionRequest;
import sailpoint.object.ProvisioningResult;
import sailpoint.object.Schema;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;
import sailpoint.tools.xml.XMLObjectFactory;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.apache.log4j.Level;
import sailpoint.object.Identity;
import java.text.SimpleDateFormat;

@Rule(name="THD-Rule-SysUser-Provisioning-Rule", filename="THD-Rule-Provisioning-SYSUSER.xml",type="JDBCProvision")
public class THD_Rule_Provisioning_SYSUSER {
    /**
     * This rule is used by the JDBC connector to do provisioning of the data .
     *
     * @param application The application whose data file is being processed.
     * @param schema      The Schema currently in use.
     * @param connection  A connection object to connect to database.
     * @param plan        The ProvisioningPlan created against the JDBC application.
     * @return result A Provisioning Result object is desirable to return the status.IT can be a new object or part of Provisioning Plan
     */

    public static ProvisioningResult jDBCProvision(Application application, Schema schema, Connection connection, ProvisioningPlan plan) throws GeneralException {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-SysUser-Provisioning-Rule");

        log.debug("Entering THD-Rule-SysUser-Provisioning-Rule");
        Identity id = plan.getIdentity();
        String timestamp = null;
        String lastUpdatePgmId = null;
        String lastUpdateSysusrId = null;
        String activeFlag = null;
        String user_id = null;
        ProvisioningResult result = new ProvisioningResult();

        if ( plan != null ) {
            log.debug( "plan: " + plan.toXml());
            List<AccountRequest> accounts = plan.getAccountRequests();
            try{
                if ( ( accounts != null ) && ( accounts.size() > 0 ) ) {
                    for ( AccountRequest account : accounts ) {
                        if ("%%SYSUSR_APP_NAME%%".equals(account.getApplication())){
                            user_id = account.getNativeIdentity();
                            log.debug("user_id: " + user_id);
                        }
                        if (AccountRequest.Operation.Disable.equals(account.getOperation()) || AccountRequest.Operation.Create.equals(account.getOperation()) || AccountRequest.Operation.Enable.equals(account.getOperation())) {
                            log.debug( "Operation [" + account.getOperation() + "] detected." );

                            //get timestamp from attribute request
                            List<AttributeRequest> attributeRequests = account.getAttributeRequests();
                            for ( AttributeRequest attribute : attributeRequests) {
                                if ( attribute.getName().equals("LAST_UPD_TS") ) {
                                    timestamp = Util.otos(attribute.getValue());
                                    log.debug("Timestamp Value from policy: " + timestamp);
                                }
                                else if (attribute.getName().equalsIgnoreCase("ACTV_FLG")){
                                    activeFlag=Util.otos(attribute.getValue());
                                    log.debug("activeFlag: " + activeFlag);
                                }
                                else if (attribute.getName().equalsIgnoreCase("LAST_UPD_PGM_ID")){
                                    lastUpdatePgmId = Util.otos(attribute.getValue());
                                    log.debug("last_upd_pgm_id: " + lastUpdatePgmId);

                                }
                                else if (attribute.getName().equalsIgnoreCase("LAST_UPD_SYSUSR_ID")){
                                    lastUpdateSysusrId = Util.otos(attribute.getValue());
                                    log.debug("last_upd_sysusr_id: " + lastUpdateSysusrId);

                                }
                            }

                            //convert string into timestamp
                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
                            Date date = null;
                            Timestamp timestampValue = null;
                            try {
                                date = simpleDateFormat.parse(timestamp);
                                timestampValue = new Timestamp(date.getTime());
                            } catch (ParseException e) {
                                log.error("Error in timestamp conversion: " + e);
                            }

                            PreparedStatement statement = connection.prepareStatement( "update SYSUSR set ACTV_FLG = ?, LAST_UPD_PGM_ID =?, LAST_UPD_SYSUSR_ID = ?, LAST_UPD_TS = ?  where USER_ID = ?" );

                            if(activeFlag==null){
                                if(AccountRequest.Operation.Disable.equals(account.getOperation())){
                                    activeFlag="N";
                                }
                                if(AccountRequest.Operation.Create.equals(account.getOperation()) || AccountRequest.Operation.Enable.equals(account.getOperation())){
                                    activeFlag="Y";
                                }
                            }
                            if(lastUpdatePgmId==null)
                            {
                                lastUpdatePgmId="SAILPOINTIIQ";

                            }
                            if(lastUpdateSysusrId==null)
                            {
                                lastUpdatePgmId="SAILPOINTIIQ";

                            }

                            statement.setString ( 1, activeFlag );
                            statement.setString( 2, "SAILPOINTIIQ" );
                            statement.setString( 3, "SAILPOINTIIQ" );
                            statement.setTimestamp( 4, timestampValue);
                            statement.setString( 5, user_id);


                            log.debug( "Preparing to execute:"+statement.toString() );
                            statement.executeUpdate();
                            result.setStatus(ProvisioningResult.STATUS_COMMITTED );
                        }
                    }
                }
            }
            catch (Exception e) {
                log.error(" Error in THD-Rule-SysUser-Provisioning-Rule" + e.getMessage());
                result.setStatus(ProvisioningResult.STATUS_FAILED);
                result.addError(e);
            }
        }
        log.debug("Exiting THD-Rule-SysUser-Provisioning-Rule: ");
        return result;
    }
}

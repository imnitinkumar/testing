package com.ey.iiq.sp2xml.fieldvalue.birthright;

import com.ey.iiq.util.THD_Util_Birthright;
import com.magnolia.iiq.build.Rule;
import java.sql.SQLException;
import java.util.List;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

@Rule(name = "THD-Rule-FieldValue-Birthright", filename = "THD-Rule-FieldValue-Birthright.xml", type = "FieldValue")
public class THD_Rule_FieldValue_Birthright {

    public List<String> fieldValueBirthright(Application application, Field field, Identity identity, Link link,
                                             Object operation, SailPointContext context)
            throws GeneralException, SQLException {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-FieldValue-Birthright");
        log.setLevel(Level.TRACE);
        log.trace("ENTERING fieldValueBirthright()");

        // Check current state
        if (log.isTraceEnabled()) {
            if (application == null) log.trace("Application is null");
            else                     log.trace("Application:   " + application.getName());
            if (field == null)       log.trace("Field is null");
            else                     log.trace("Field Name:    " + field.getUnqualifiedName());
            if (identity == null)    log.trace("Identity is null");
            else                     log.trace("Identity Name: " + identity.getFullName());
            if (link == null)        log.trace("Link is null");
            else                     log.trace("Link:          " + link.getDisplayableName());
            if (operation == null)   log.trace("Operation is null");
            else                     log.trace("Operation:     " + operation.toString());
        }

        // List of birthright entitlements to be returned that need to be added
        List<String> birthrightEntitlements;

        // Ensure required values are present
        if (application == null || identity == null) {
            if (application == null)
                throw new GeneralException("Application can not be null when modifying Birthright entitlements");
            throw new GeneralException("Identity can not be null when modifying Birthright entitlements");
        }
        log.debug("Begin process of getting the identity's new birthright entitlements");

        // Variables required to create the birthrightEntitlements list
        String applicationName = application.getName();
        int ind = applicationName.indexOf("-");
        String parsedApplicationName = "";
        if (ind >= 0 && ind+1<applicationName.length()){
            parsedApplicationName = applicationName.substring(ind+1);
        }
        String groupAttributeName;

        // Get the group attribute off of the application (assume only one)
        if (application.getGroupAttributes() == null || application.getGroupAttributes().isEmpty())
            throw new GeneralException("Failed to find a group attribute on application '" + applicationName + "'");

        groupAttributeName = application.getGroupAttributes().get(0).getName();
        log.debug("Successfully found group attribute name '" + groupAttributeName + "' on application");

        // Get the required values from SailPoint Custom Objects
        List<String> identityAttributes = THD_Util_Birthright.getBirthrightIdentityAttributes(context);
        String birthrightTableName      = THD_Util_Birthright.getBirthrightTableName(context, applicationName);
        birthrightTableName = Util.isNullOrEmpty(birthrightTableName) ?  birthrightTableName : THD_Util_Birthright.getBirthrightTableName(context, parsedApplicationName);

        // Check if the required values were retrieved from Custom Objects
        if (Util.isNullOrEmpty(birthrightTableName) || identityAttributes == null || identityAttributes.isEmpty()) {
            if (Util.isNullOrEmpty(birthrightTableName)){

            }
            throw new GeneralException("Failed to retrieve birthright identity attributes");
        }
        log.debug("Successfully retrieved required values from Custom Objects");

        log.debug("Get the birthright entitlements using the birthright utility");
        birthrightEntitlements = THD_Util_Birthright.getBirthrightEntitlements(true, identity,
                identityAttributes, context, applicationName, birthrightTableName, groupAttributeName);

        // Check if the birthright entitlements were retrieved successfully
        if (birthrightEntitlements == null)
            throw new GeneralException("Failed to get birthright entitlements");
        else if (birthrightEntitlements.size() == 0)
            log.debug("No birthright entitlements were found for the account");
        else
            log.debug("List of birthright entitlements for account:\n" + birthrightEntitlements);

        log.trace("EXITING fieldValueBirthright()");
        return birthrightEntitlements;
    }
}
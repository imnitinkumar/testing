package com.ey.iiq.sp2xml.fieldvalue.LDAP;

import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.ey.iiq.constants.THD_Constants_ProvisioningPolicy;
import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Logger;
import sailpoint.object.*;
import sailpoint.tools.Util;

@Rule(type="FieldValue", name="THD-Rule-FieldValue-LDAP-DistinguishedName", filename="THD-Rule-FieldValue-LDAP-DistinguishedName.xml")
public class THD_Rule_FieldValue_LDAP_DistinguishedName {
    /**
     * This rule can be used to generate a field value (eg - an account name) using data from the given Identity
     * If this rule is run in the context of a workflow step then the arguments passed into the step will also be available
     * Also, any field values that have been processed so far from the policy related to the Application/Role will be available.
     *
     * @param identity       The Identity object that represents the user needing the field value.
     * @param link           The sailpoint.object.Link that is being acted upon. If the link is not applicable, this value will be null.
     * @param group          The sailpoint.object.ManagedAttribute that is being acted upon. If the managed attribute is not applicable, the value will be null.
     * @param project        The provisioning project being acted upon. If a provisioning project is not applicable, the value will be null.
     * @param accountRequest The account request. If an account request is not applicable, the value will be null.
     * @param objectRequest  The object request. If an object request is not applicable, the value will be null.
     * @param role           The role with the template we are compiling. If the role is not applicable, the value will be null.
     * @param application    The sailpont.object.Application with the template we are compiling. If the application is not applicable, the value will be null.
     * @param template       The Template that contains this field.
     * @param field          The current field being computed.
     * @param current        The current value corresponding to the identity or account attribute that the field represents. If no current value is set, this value will be null.
     * @param operation      The operation being performed.
     * @return value The string value created.
     */
    //
    //        cn=<FULL NAME>+uid=<UID>
    //        contractor: ou=THD CONTRACTORS,o=homedepot.com,c=us
    //        associate: ou=<locationnumber>,o=homedepot.com,c=us
    public static String fieldValue(Identity identity, Link link, GroupDefinition group, ProvisioningProject project, ProvisioningPlan.AccountRequest accountRequest, Object objectRequest, Bundle role, Application application, Object template, Field field, Object current, Object operation) {
        Logger log = Logger.getLogger("thd.iam.rule.THD-Rule-FieldValue-LDAP-DistinguishedName");
        log.trace("Entering THD-Rule-FieldValue-LDAP-DistinguishedName");

        // Identity attributes required to calculate dn
        String fullName       = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.FULL_NAME));
        String locationNumber = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_NUMBER));
        String locationType   = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_TYPE));
        String personType     = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.PERSON_TYPE));
        String uid            = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.UID));

        // Variables used to create the dn
        String cn = String.format(THD_Constants_ProvisioningPolicy.LDAP_CN, fullName, uid);
        String dn = null;
        String ou = null;

        // Check if the identity has a valid person type
        if (THD_Constants_General.PERSON_TYPE_ASSOCIATE.equalsIgnoreCase(personType)) {
            log.debug("Identity has a valid person type '" + personType + "'");

            // Check if the identity has a valid location type
            if ((THD_Constants_General.LOCATION_TYPE_CORP.equalsIgnoreCase(locationType)) ||
                    (THD_Constants_General.LOCATION_TYPE_DC.equalsIgnoreCase(locationType)) ||
                    (THD_Constants_General.LOCATION_TYPE_MET.equalsIgnoreCase(locationType))) {
                log.debug("Identity has a valid corp location type '" + locationType + "'");

                ou = THD_Constants_ProvisioningPolicy.LDAP_CORP_ASSOCIATE_OU;
            }
            else if (THD_Constants_General.LOCATION_TYPE_STORE.equalsIgnoreCase(locationType)) {
                log.debug("Identity has a valid store location type '" + locationType + "'");

                ou = String.format(THD_Constants_ProvisioningPolicy.LDAP_STORE_ASSOCIATE_OU, locationNumber);
            }
            else {
                log.error("Unknown Location Type: " + locationType);
            }
        }
        else if (THD_Constants_General.PERSON_TYPE_CONTRACTOR.equalsIgnoreCase(personType)) {
            ou = THD_Constants_ProvisioningPolicy.LDAP_CONTRACTOR_OU;
        }
        else {
            log.error("Unknown Person Type" + personType);
        }

        // Calculate the dn if the OU was successfully determined and attempt to add it to the account request
        if (!Util.isNullOrEmpty(ou)) {
            dn = cn + ou;
            log.debug("Calculated dn: " + dn);

            if (accountRequest != null) accountRequest.setNativeIdentity(dn);
        }

        log.trace("Exiting THD-Rule-FieldValue-LDAP-DistinguishedName");
        return dn;
    }
}
package com.ey.iiq.sp2xml.fieldvalue.SAP;

import com.magnolia.iiq.build.Rule;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.Link;
import sailpoint.object.Field;
import sailpoint.object.Identity;
import sailpoint.object.Application;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.ProvisioningPlan.AttributeRequest;
import sailpoint.object.ProvisioningResult;
import sailpoint.object.ProvisioningPlan.AccountRequest.Operation;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.PasswordGenerator;
import sailpoint.object.PasswordPolicy;
import sailpoint.tools.Util;

import java.util.ArrayList;
import java.util.List;

@Rule(type="FieldValue", name="THD-Rule-FieldValue-SAP-Policy-Enable", filename="THD-Rule-FieldValue-SAP-Policy-Enable.xml")
public class THD_Rule_FieldValue_SAP_Policy_Enable {

    /**
     * This rule can be used to generate a field value (eg - an account name) using data from the given Identity
     * If this rule is run in the context of a workflow step then the arguments passed into the step will also be available
     * Also, any field values that have been processed so far from the policy related to the Application/Role will be available.
     *
     * @param identity       The Identity object that represents the user needing the field value.
     * @param link           The sailpoint.object.Link that is being acted upon. If the link is not applicable, this value will be null.
     * @param group          The sailpoint.object.ManagedAttribute that is being acted upon. If the managed attribute is not applicable, the value will be null.
     * @param project        The provisioning project being acted upon. If a provisioning project is not applicable, the value will be null.
     * @param accountRequest The account request. If an account request is not applicable, the value will be null.
     * @param objectRequest  The object request. If an object request is not applicable, the value will be null.
     * @param role           The role with the template we are compiling. If the role is not applicable, the value will be null.
     * @param application    The sailpont.object.Application with the template we are compiling. If the application is not applicable, the value will be null.
     * @param template       The Template that contains this field.
     * @param field          The current field being computed.
     * @param current        The current value corresponding to the identity or account attribute that the field represents. If no current value is set, this value will be null.
     * @param operation      The operation being performed.
     */
    public String fieldValue(Identity identity, Link link, GroupDefinition group, ProvisioningProject project, AccountRequest accountRequest, Object objectRequest, Bundle role, Application application, Object template, Field field, Object current, Object operation, SailPointContext context) {



          Logger log = Logger.getLogger("com.thd.THD-Rule-FieldValue-SAP-Policy-Enable");
        log.setLevel(Level.TRACE);

        String currentField = field.getName();
        String USERGROUPS = "User Groups";
        String val = null;

        if (USERGROUPS.equals(currentField)) {
            String eventTriggered = Util.otos(identity.getAttribute("eventToBeTriggered"));
            if (eventTriggered != null) {

                log.debug("THD-Rule-FieldValue-SAP-Policy-Modify After getting eventTriggered " + eventTriggered);
                String statusVal = Util.otos(identity.getAttribute("status"));
                String jobTitleVal = Util.otos(identity.getAttribute("jobTitle"));
                if (statusVal != null && statusVal.length() > 0) {

                    if (statusVal.equals("T")) {
                        val = "HDDELETE";
                    } else {

                        if (jobTitleVal != null && jobTitleVal.length() > 0) {

                            val = jobTitleVal;

                        } else {
                            val = "ENDUSER";
                        }
                    }
                }

                log.debug("THD-Rule-FieldValue-SAP-Policy-Modify After getting eventTriggered  dataList>" + val);
            }
        }
        return val;

    }
 }



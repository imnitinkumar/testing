package com.ey.iiq.sp2xml.fieldvalue.general;

import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.magnolia.iiq.build.Rule;
import sailpoint.object.*;
import sailpoint.tools.Util;

@Rule(type="FieldValue", name="THD-Rule-FieldValue-General-DepartmentNumber", filename="THD-Rule-FieldValue-General-DepartmentNumber.xml")
public class THD_Rule_FieldValue_General_DepartmentNumber {
    /**
     * This rule can be used to generate a field value (eg - an account name) using data from the given Identity
     * If this rule is run in the context of a workflow step then the arguments passed into the step will also be available
     * Also, any field values that have been processed so far from the policy related to the Application/Role will be available.
     *
     * @param identity       The Identity object that represents the user needing the field value.
     * @param link           The sailpoint.object.Link that is being acted upon. If the link is not applicable, this value will be null.
     * @param group          The sailpoint.object.ManagedAttribute that is being acted upon. If the managed attribute is not applicable, the value will be null.
     * @param project        The provisioning project being acted upon. If a provisioning project is not applicable, the value will be null.
     * @param accountRequest The account request. If an account request is not applicable, the value will be null.
     * @param objectRequest  The object request. If an object request is not applicable, the value will be null.
     * @param role           The role with the template we are compiling. If the role is not applicable, the value will be null.
     * @param application    The sailpont.object.Application with the template we are compiling. If the application is not applicable, the value will be null.
     * @param template       The Template that contains this field.
     * @param field          The current field being computed.
     * @param current        The current value corresponding to the identity or account attribute that the field represents. If no current value is set, this value will be null.
     * @param operation      The operation being performed.
     * @return value The string value created.
     */
    public static String fieldValue(Identity identity, Link link, GroupDefinition group, ProvisioningProject project, ProvisioningPlan.AccountRequest accountRequest, Object objectRequest, Bundle role, Application application, Object template, Field field, Object current, Object operation) {
        String attributeValue = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.DEPARTMENT_NUMBER));
        return (Util.isNotNullOrEmpty(attributeValue))? attributeValue : THD_Constants_General.EMPTY_STRING;
    }
}

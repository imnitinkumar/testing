package com.ey.iiq.sp2xml.fieldvalue.AD;

import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.ey.iiq.constants.THD_Constants_ProvisioningPolicy;
import org.apache.log4j.Logger;
import sailpoint.object.*;
import sailpoint.tools.Util;
import com.magnolia.iiq.build.Rule;


@Rule(name="THD-Rule-FieldValue-AD-ExtensionAttribute2", filename="THD-Rule-FieldValue-AD-ExtensionAttribute2.xml",type="FieldValue")
public class THD_Rule_FieldValue_AD_ExtensionAttribute2 {
    /**
     * This rule can be used to generate a field value (eg - an account name) using data from the given Identity
     * If this rule is run in the context of a workflow step then the arguments passed into the step will also be available
     * Also, any field values that have been processed so far from the policy related to the Application/Role will be available.
     *
     * @param identity       The Identity object that represents the user needing the field value.
     * @param link           The sailpoint.object.Link that is being acted upon. If the link is not applicable, this value will be null.
     * @param group          The sailpoint.object.ManagedAttribute that is being acted upon. If the managed attribute is not applicable, the value will be null.
     * @param project        The provisioning project being acted upon. If a provisioning project is not applicable, the value will be null.
     * @param accountRequest The account request. If an account request is not applicable, the value will be null.
     * @param objectRequest  The object request. If an object request is not applicable, the value will be null.
     * @param role           The role with the template we are compiling. If the role is not applicable, the value will be null.
     * @param application    The sailpont.object.Application with the template we are compiling. If the application is not applicable, the value will be null.
     * @param template       The Template that contains this field.
     * @param field          The current field being computed.
     * @param current        The current value corresponding to the identity or account attribute that the field represents. If no current value is set, this value will be null.
     * @param operation      The operation being performed.
     * @return value The string value created.
     */
    public static String fieldValue(Identity identity, Link link, GroupDefinition group, ProvisioningProject project, ProvisioningPlan.AccountRequest accountRequest, Object objectRequest, Bundle role, Application application, Object template, Field field, Object current, Object operation) {
        String attributeVal=null;
        Logger log = Logger.getLogger("thd.iam.rule.THD-Rule-FieldValue-AD-Extension2");
        log.trace("Entering THD-Rule-FieldValue-AD-ExtensionAttribute2");

        String personType = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.PERSON_TYPE));
        String buid = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.BUSINESS_UNIT_ID));
        boolean mailEnabled = Util.otob(identity.getAttribute(THD_Constants_IdentityAttributes.MAIL_ENABLED));

        if (personType.equals(THD_Constants_General.PERSON_TYPE_ASSOCIATE)){
            if (mailEnabled){
                if (THD_Constants_ProvisioningPolicy.AD_YOWMAIL_BUID_SET.contains(buid)){
                    attributeVal=THD_Constants_General.YOWMAIL_EMAIL_DOMAIN;
                }
                else{
                    attributeVal=THD_Constants_General.EMAIL_DOMAIN;
                }
            }
            else{
                attributeVal = null;
            }
        }
        else if (identity.getAttribute(THD_Constants_IdentityAttributes.PERSON_TYPE).equals(THD_Constants_General.PERSON_TYPE_CONTRACTOR)){
            attributeVal = THD_Constants_General.EMAIL_DOMAIN;
        }
        else{
            log.error("Unknown PERSON TYPE:" + identity.getAttribute(THD_Constants_IdentityAttributes.PERSON_TYPE));
        }
        log.trace("Exiting THD-Rule-FieldValue-AD-ExtensionAttribute2");
        return attributeVal;
    }
}

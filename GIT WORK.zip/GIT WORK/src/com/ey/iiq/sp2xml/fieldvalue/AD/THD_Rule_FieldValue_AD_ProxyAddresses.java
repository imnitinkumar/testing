package com.ey.iiq.sp2xml.fieldvalue.AD;

import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.ey.iiq.constants.THD_Constants_ProvisioningPolicy;
import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Logger;
import sailpoint.object.*;
import sailpoint.tools.Util;

import java.util.ArrayList;
import java.util.List;

@Rule(name="THD-Rule-FieldValue-AD-ProxyAddresses", filename="THD-Rule-FieldValue-AD-ProxyAddresses.xml", type="FieldValue")
public class THD_Rule_FieldValue_AD_ProxyAddresses {
    /**
     * This rule can be used to generate a field value (eg - an account name) using data from the given Identity
     * If this rule is run in the context of a workflow step then the arguments passed into the step will also be available
     * Also, any field values that have been processed so far from the policy related to the Application/Role will be available.
     *
     * @param identity       The Identity object that represents the user needing the field value.
     * @param link           The sailpoint.object.Link that is being acted upon. If the link is not applicable, this value will be null.
     * @param group          The sailpoint.object.ManagedAttribute that is being acted upon. If the managed attribute is not applicable, the value will be null.
     * @param project        The provisioning project being acted upon. If a provisioning project is not applicable, the value will be null.
     * @param accountRequest The account request. If an account request is not applicable, the value will be null.
     * @param objectRequest  The object request. If an object request is not applicable, the value will be null.
     * @param role           The role with the template we are compiling. If the role is not applicable, the value will be null.
     * @param application    The sailpont.object.Application with the template we are compiling. If the application is not applicable, the value will be null.
     * @param template       The Template that contains this field.
     * @param field          The current field being computed.
     * @param current        The current value corresponding to the identity or account attribute that the field represents. If no current value is set, this value will be null.
     * @param operation      The operation being performed.
     * @return value The string value created.
     */
    public static List<String> fieldValue(Identity identity, Link link, GroupDefinition group, ProvisioningProject project, ProvisioningPlan.AccountRequest accountRequest, Object objectRequest, Bundle role, Application application, Object template, Field field, Object current, Object operation) {
        List<String> proxyAddresses = new ArrayList<String>();
        boolean mailEnabled = Util.otob(identity.getAttribute(THD_Constants_IdentityAttributes.MAIL_ENABLED));
        String email = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.EMAIL));
        String uid = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.UID));
        Logger log = Logger.getLogger("thd.iam.rule.THD-Rule-FieldValue-AD-ProxyAddresses");
        log.trace("Entering THD-Rule-FieldValue-AD-ProxyAddresses");

        if (mailEnabled){
            if (email != null){
                proxyAddresses.add(String.format(THD_Constants_ProvisioningPolicy.AD_PROXY_ADDRESS,email));
            }
            if (uid != null){
                proxyAddresses.add(String.format(THD_Constants_ProvisioningPolicy.AD_PROXY_ADDRESS2,uid,"%%AD_SMTP_PROXY_DOMAIN%%"));
            }
        }

        log.trace("Exiting THD-Rule-FieldValue-AD-ProxyAddresses");
        return proxyAddresses;
    }
}

package com.ey.iiq.sp2xml.fieldvalue.Informix;


import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.magnolia.iiq.build.Rule;
import sailpoint.object.*;
import sailpoint.tools.Util;

@Rule(type="FieldValue", name="THD-Rule-FieldValue-Informix-DistinguishedName", filename="THD-Rule-FieldValue-Informix-DistinguishedName.xml")
public class THD_Rule_FieldValue_Informix_DistinguishedName {
    public static String fieldValue(Identity identity, Link link, GroupDefinition group, ProvisioningProject project, ProvisioningPlan.AccountRequest accountRequest, Object objectRequest, Bundle role, Application application, Object template, Field field, Object current, Object operation) {
        String dn=null;
        String INFORMIX_DN="sysusrid=%s,ou=sysusr,ou=user,ou=st%s,ou=stores,o=thdidmifx";
        String sysusrId= Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.SYSUSER_ID));
        String locationNumber=Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_NUMBER));
        if (Util.isNotNullOrEmpty(sysusrId) && Util.isNotNullOrEmpty(locationNumber)){
            dn = String.format(INFORMIX_DN,sysusrId,locationNumber);
        }
        if (accountRequest!=null)
            accountRequest.setNativeIdentity(dn);

        return dn;

    }
}
package com.ey.iiq.sp2xml.fieldvalue.Informix;

import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.magnolia.iiq.build.Rule;
import sailpoint.object.*;
import sailpoint.tools.Util;

@Rule(type="FieldValue", name="THD-Rule-FieldValue-Informix-PGMID", filename="THD-Rule-FieldValue-Informix-PGMID.xml")
public class THD_Rule_FieldValue_Informix_PGMID {
    public static String fieldValue(Identity identity, Link link, GroupDefinition group, ProvisioningProject project, ProvisioningPlan.AccountRequest accountRequest, Object objectRequest, Bundle role, Application application, Object template, Field field, Object current, Object operation) {
        return "IIQ";
    }
}

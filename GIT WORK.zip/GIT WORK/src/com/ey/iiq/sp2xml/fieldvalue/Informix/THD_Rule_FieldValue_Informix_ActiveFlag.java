package com.ey.iiq.sp2xml.fieldvalue.Informix;


import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.magnolia.iiq.build.Rule;
import sailpoint.object.*;
import sailpoint.tools.Util;

@Rule(type="FieldValue", name="THD-Rule-FieldValue-Informix-ActiveFlag", filename="THD-Rule-FieldValue-Informix-ActiveFlag.xml")
public class THD_Rule_FieldValue_Informix_ActiveFlag {
    public static String fieldValue(Identity identity, Link link, GroupDefinition group, ProvisioningProject project, ProvisioningPlan.AccountRequest accountRequest, Object objectRequest, Bundle role, Application application, Object template, Field field, Object current, Object operation) {
        String activeFlag ="";
        String status = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.STATUS));
	String emerStatus = identity.getStringAttribute("isEmergencyTerm");

        if(emerStatus!=null ){
            activeFlag = "N";
        }

       else if (THD_Constants_General.IDENTITY_STATUS_REHIRE.equalsIgnoreCase(status))  {
            activeFlag="Y";
        }
        else{
            activeFlag="N";
        }
        return activeFlag;
    }
}

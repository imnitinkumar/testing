package com.ey.iiq.sp2xml.fieldvalue.LDAP;


import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.object.*;
import sailpoint.tools.Util;

import java.util.ArrayList;
import java.util.List;

@Rule(type="FieldValue", name="THD-Rule-FieldValue-LDAP-OrgUnit", filename="THD-Rule-FieldValue-LDAP-OrgUnit.xml")
public class THD_Rule_FieldValue_LDAP_OrgUnit {
    /**
     * This rule can be used to generate a field value (eg - an account name) using data from the given Identity
     * If this rule is run in the context of a workflow step then the arguments passed into the step will also be available
     * Also, any field values that have been processed so far from the policy related to the Application/Role will be available.
     *
     * @param identity       The Identity object that represents the user needing the field value.
     * @param link           The sailpoint.object.Link that is being acted upon. If the link is not applicable, this value will be null.
     * @param group          The sailpoint.object.ManagedAttribute that is being acted upon. If the managed attribute is not applicable, the value will be null.
     * @param project        The provisioning project being acted upon. If a provisioning project is not applicable, the value will be null.
     * @param accountRequest The account request. If an account request is not applicable, the value will be null.
     * @param objectRequest  The object request. If an object request is not applicable, the value will be null.
     * @param role           The role with the template we are compiling. If the role is not applicable, the value will be null.
     * @param application    The sailpont.object.Application with the template we are compiling. If the application is not applicable, the value will be null.
     * @param template       The Template that contains this field.
     * @param field          The current field being computed.
     * @param current        The current value corresponding to the identity or account attribute that the field represents. If no current value is set, this value will be null.
     * @param operation      The operation being performed.
     * @return value The string value created.
     */
    public static Object fieldValue(Identity identity, Link link, GroupDefinition group, ProvisioningProject project, ProvisioningPlan.AccountRequest accountRequest, Object objectRequest, Bundle role, Application application, Object template, Field field, Object current, Object operation) {
        String personType = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.PERSON_TYPE));
        String locationType = Util.otos(identity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_TYPE));
        List<String> attributeValues =new ArrayList<String>();
        Logger log = Logger.getLogger("thd.iam.rule.THD-Rule-FieldValue-LDAP-OrgUnit");
        log.trace("Entering THD-Rule-FieldValue-LDAP-OrgUnit");

        if (personType.equalsIgnoreCase(THD_Constants_General.PERSON_TYPE_ASSOCIATE)){
            attributeValues.add(THD_Constants_General.PERSON_TYPE_ASSOCIATE);
        }
        else if (personType.equalsIgnoreCase(THD_Constants_General.PERSON_TYPE_CONTRACTOR)){
            attributeValues.add(THD_Constants_General.PERSON_TYPE_CONTRACTOR);
        }
        else{
            log.debug("Unknown PERSON TYPE " + identity.getAttribute(THD_Constants_IdentityAttributes.PERSON_TYPE));
        }

        if (locationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_STORE)){
            attributeValues.add(THD_Constants_General.LOCATION_TYPE_STORE);
        }
        else if (locationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_CORP) || locationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_DC) || locationType.equalsIgnoreCase(THD_Constants_General.LOCATION_TYPE_MET)){
            attributeValues.add(THD_Constants_General.LOCATION_TYPE_CORP);
        }
        else{
            log.debug("Unknown LOCATION TYPE " + identity.getAttribute(THD_Constants_IdentityAttributes.LOCATION_TYPE));
        }

        log.trace("Exiting THD-Rule-FieldValue-LDAP-OrgUnit");
        return (Util.isEmpty(attributeValues)?THD_Constants_General.EMPTY_STRING:attributeValues);
    }
}

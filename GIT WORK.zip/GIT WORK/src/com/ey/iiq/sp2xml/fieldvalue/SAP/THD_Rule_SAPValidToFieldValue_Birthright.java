package com.ey.iiq.sp2xml.fieldvalue.SAP;

import com.ey.iiq.sp2xml.THD_RuleLibrary_SAPBirthright;
import com.magnolia.iiq.build.Rule;
import com.magnolia.iiq.build.RuleReference;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

import java.util.List;
import java.util.Map;

@Rule(type="FieldValue", name="THD-Rule-SAPValidToFieldValue-Birthright", filename="THD-Rule-SAPValidToFieldValue-Birthright.xml")
public class THD_Rule_SAPValidToFieldValue_Birthright {

    @RuleReference(name="THD-RuleLibrary-SAPBirthright")
     THD_RuleLibrary_SAPBirthright sapRuleLib = new THD_RuleLibrary_SAPBirthright();

    /**
     * This rule can be used to generate a field value (eg - an account name) using data from the given Identity
     * If this rule is run in the context of a workflow step then the arguments passed into the step will also be available
     * Also, any field values that have been processed so far from the policy related to the Application/Role will be available.
     *
     * @param identity       The Identity object that represents the user needing the field value.
     * @param link           The sailpoint.object.Link that is being acted upon. If the link is not applicable, this value will be null.
     * @param group          The sailpoint.object.ManagedAttribute that is being acted upon. If the managed attribute is not applicable, the value will be null.
     * @param project        The provisioning project being acted upon. If a provisioning project is not applicable, the value will be null.
     * @param accountRequest The account request. If an account request is not applicable, the value will be null.
     * @param objectRequest  The object request. If an object request is not applicable, the value will be null.
     * @param role           The role with the template we are compiling. If the role is not applicable, the value will be null.
     * @param application    The sailpont.object.Application with the template we are compiling. If the application is not applicable, the value will be null.
     * @param template       The Template that contains this field.
     * @param field          The current field being computed.
     * @param current        The current value corresponding to the identity or account attribute that the field represents. If no current value is set, this value will be null.
     * @param operation      The operation being performed.
     * @return value The string value created.
     */
    public String fieldValue(Identity identity, Link link, GroupDefinition group, ProvisioningProject project, ProvisioningPlan.AccountRequest accountRequest, Object objectRequest, Bundle role, Application application, Object template, Field field, Object current, Object operation, SailPointContext context) {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-SAPRolesFieldValue-Birthright");
        log.setLevel(Level.TRACE);
        log.trace("ENTERING getSAPBirthrightEntitlementsFieldValue()");
        if (log.isTraceEnabled()) {
            if (identity == null)
                log.trace("Identity is null");
            else
                log.trace("Identity Name: " + identity.getFullName());
            if (application == null)
                log.trace("Application is null");
            else
                log.trace("Application:   " + application.getName());
            if (field == null)
                log.trace("Field is null");
            else
                log.trace("Field Name:    " + field.getUnqualifiedName());
            if (operation == null)
                log.trace("Operation is null");
            else
                log.trace("Operation:     " + operation.toString());
        }
        String getValidTo = null;
        if (application != null && identity != null) {
            try {
                Custom birthrightMapping =
                        context.getObjectByName(Custom.class, "THD-Custom-BirthrightTable-Mappings");
                if (birthrightMapping != null) {
                    log.debug("Successfully retrieved Custom Object for SAP Table 'THD-Custom-BirthrightTable-Mappings'");
                    log.debug("Birthright Table Name Directly From Custom Object: " + Util.otos(birthrightMapping.get(application.getName())));
                    Map birthrightMap = birthrightMapping.getAttributes().getMap();
                    if (birthrightMap != null) {
                        log.debug("Map from Custom Object: " + birthrightMap.toString());
                        String birthrightTableName = Util.otos(birthrightMap.get(application.getName()));
                        if (birthrightTableName != null) {
                            log.debug("SAP Birthright Table Name from Map: " + birthrightTableName);
                            log.debug("SAP Calling the birthright rule library passing in the birthright table name based on the application");
                            getValidTo =sapRuleLib.getSAPBirthrightValidTo(identity, context, birthrightTableName);
                            if (getValidTo == null || getValidTo.length() == 0) {
                                log.debug("No birthright entitlements were added for the account");
                            } else {
                                log.debug("List of birthright entitlements for account: " + getValidTo);
                            }
                        } else {
                            log.error("Could not retrieve birthright table name from map based on application name");
                        }
                    } else {
                        log.error("Could not retrieve birthright map from Custom Object");
                    }
                } else {
                    log.error("Could not retrieve THD-Custom-BirthrightTable-Mappings");
                }
            } catch (GeneralException e) {
                log.error("Error attempting to fetch custom object from context");
                log.error(e);
            }
        }
        log.trace("EXITING getBirthrightEntitlementsFieldValue()");
        return getValidTo;
    }
}





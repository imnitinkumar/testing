package com.ey.iiq.sp2xml;

import com.ey.iiq.util.THD_Util_Birthright;
import com.ey.iiq.util.THD_Util_SearchUtil;
import com.magnolia.iiq.build.Rule;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.object.*;
import sailpoint.tools.Util;
import sailpoint.api.SailPointContext;
import sailpoint.tools.GeneralException;
import sailpoint.api.certification.DataOwnerCertificationBuilder.DataOwnerCertifiable;

@Rule(name = "THD-Rule-CertificationExclusion-Birthright", filename = "THD-Rule-CertificationExclusion-Birthright.xml", type = "CertificationExclusion")
public class THD_Rule_CertificationExclusion_Birthright {

    public String excludeBirthrightEntitlements(AbstractCertifiableEntity entity, List<Certifiable> items,
                                                List<Certifiable> itemsToExclude, SailPointContext context)
            throws GeneralException, SQLException {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-CertificationExclusion-Birthright");
        log.setLevel(Level.TRACE);
        log.trace("ENTERING THD-Rule-CertificationExclusion-Birthright");

        // The string to return containing what was excluded if anything
        String explanation = "";

        // Ensure that the current entity is an identity
        if (entity instanceof Identity) {
            Identity identity = (Identity) entity;
            String identityName = identity.getName();
            log.debug("Checking if identity '" + identityName + "' requires entitlements be excluded from the certification");

            // The list of current birthright entitlements the identity gets
            List<String> birthrightEntitlements = new ArrayList<>();

            // Getting required values to create list of current birthright entitlements
            List<String> birthrightAccounts = THD_Util_Birthright.getBirthrightAccounts(context, identityName);
            List<String> identityAttributes = THD_Util_Birthright.getBirthrightIdentityAttributes(context);

            // Iterate through the birthright accounts to create a list of all birthright entitlements
            for (String currentApplicationName : birthrightAccounts) {
                log.debug("Fetching additional required values for application '" + currentApplicationName + "'");

                // Fetch the birthright table name for the current application
                String birthrightTableName = THD_Util_Birthright.getBirthrightTableName(context, currentApplicationName);

                // Fetch the group attribute for the current application
                Application currentApplication = THD_Util_SearchUtil.getApplication(context, currentApplicationName);
                if (currentApplication == null)
                    log.error("Failed to find application '" + currentApplicationName + "'");
                else if (currentApplication.getGroupAttributes() == null || currentApplication.getGroupAttributes().isEmpty())
                    log.error("Failed to find a group attribute on application '" + currentApplicationName + "'");
                else {
                    String groupAttributeName = currentApplication.getGroupAttributes().get(0).getName();
                    log.debug("Successfully found group attribute name '" + groupAttributeName + "' on application");

                    log.debug("Using retrieved values to fetch list of current birthright entitlements");
                    List<String> currentBirthrightEntitlements = THD_Util_Birthright.getBirthrightEntitlements(
                            true, identity, identityAttributes, context, currentApplicationName,
                            birthrightTableName, groupAttributeName);

                    // Determine if the current list needs to be added to the over list of birthright entitlements
                    if (currentBirthrightEntitlements == null)
                        log.error("Failed to get the birthright entitlements for application '" +
                                currentApplicationName + "'");
                    else if (currentBirthrightEntitlements.isEmpty())
                        log.debug("Identity does not receive any birthright entitlements for application '" +
                                currentApplicationName + "'");
                    else {
                        log.debug("Identity receives the following birthright entitlements for application '" +
                                currentApplicationName + "':\n" + currentBirthrightEntitlements);

                        // Add the current list to the overall list of birthright entitlements
                        birthrightEntitlements.addAll(currentBirthrightEntitlements);
                    }
                }
            }

            // Checking if any birthright entitlements were added from any applications
            if (birthrightEntitlements.isEmpty())
                log.debug("Identity receives no birthright entitlements, so there will be no certification exclusions");
            else {
                log.debug("Identity receives at least one birthright entitlement, checking for certification exclusions");

                // Transform the birthright list to uppercase for comparisons
                for (int i=0; i < birthrightEntitlements.size(); i++) {
                    birthrightEntitlements.set(i, birthrightEntitlements.get(i).toUpperCase());
                }

                // Iterate through the certifiable items and check each one to see if it needs to be excluded
                Iterator<Certifiable> it = items.iterator();
                while (it.hasNext()) {
                    Certifiable certifiableObject = it.next();

                    // The entitlement associated with the current Certifiable Object
                    Entitlements ents = null;

                    // Check if the current Certifiable Object is an instance of Entitlements
                    if (certifiableObject instanceof Entitlements) {
                        log.debug("Current certifiable object is instance of Entitlements");
                        ents = (Entitlements) certifiableObject;
                    }

                    // Otherwise check if the current Certifiable Object is an instance of DataOwnerCertifiable
                    else if (certifiableObject instanceof DataOwnerCertifiable) {
                        log.debug("Current certifiable object is instance of DataOwnerCertifiable");
                        DataOwnerCertifiable certifiableItem = (DataOwnerCertifiable) certifiableObject;
                        ents = certifiableItem.getEntitlements();
                    }

                    // Now check if ents was set to a value (Certifiable Object was valid type)
                    if (ents == null)
                        log.debug("Current Certifiable Object was not an entitlement type");
                    else if (ents.isAccountOnly() )
                        log.debug("Current Certifiable Object is Account Only");
                    else if (ents.getAttributes() == null)
                        log.debug("Cannot have a null value for getAttributes()");
                    else {
                        String entitlementName = ents.getAttributeNames().get(0);
                        String entitlementValue = Util.otos(ents.getAttributes().get(entitlementName));
                        log.debug("entitlementName: " + entitlementName);
                        log.debug("entitlementValue: " + entitlementValue);

                        // Check if this entitlement is in the list of birthright entitlements (needs to be excluded)
                        if (birthrightEntitlements.contains(entitlementValue.toUpperCase())) {
                            log.debug("This entitlement is a current birthright entitlement, excluding");
                            itemsToExclude.add(certifiableObject);
                            it.remove();

                            explanation = "Entitlements match the exclusion criteria";
                        } else log.debug("This entitlement is not a current birthright entitlement, will not exclude");
                    }
                }
            }
        } else log.debug("Entity is not an instance of Identity");

        log.trace("EXITING THD_Rule_CertificationExclusion_Birthright");
        return explanation;
    }
}
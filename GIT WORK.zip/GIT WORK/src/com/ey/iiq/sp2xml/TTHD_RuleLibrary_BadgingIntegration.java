package com.ey.iiq.sp2xml;

import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.Identity;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

import java.util.ArrayList;
import java.util.List;
import com.ey.iiq.constants.THD_Constants_IdentityAttributes;

@Rule(library=true, name="THD-RuleLibrary-BadgingIntegration", filename = "THD-RuleLibrary-BadgingIntegration.xml")
public class THD_RuleLibrary_BadgingIntegration {

    private static Logger log = Logger.getLogger("thd.iam.THD-RuleLibrary-BadgingIntegration");

    //returns true if badging account request is added
    public static boolean addBadgingAccountRequestJoiner(SailPointContext context, ProvisioningPlan plan, String idName) {
        log.setLevel(Level.TRACE);
        log.trace("ENTERING getBadgingAccountRequestJoiner");
        AccountRequest badgeAccountRequest = new AccountRequest();
        List<AccountRequest> accReqs;
        Identity id = null;
        boolean badgeAccountRequestAdded;

        if (plan == null) {
            log.debug("Provisioning Plan is NULL. No account request added");
            badgeAccountRequestAdded = false;
        }
        if (Util.isNullOrEmpty(idName)) {
            log.debug("Identity Name is NULL or Empty. No account request added");
            badgeAccountRequestAdded = false;
        }
        else{
            try {
                id = context.getObjectByName(Identity.class, idName);
                log.debug("Identity object retrieved with name " + idName);
                log.debug("Identity badge Enabled value = "+Util.otos(id.getAttribute(THD_Constants_IdentityAttributes.BADGE_ENABLED)));
            }
            catch(GeneralException e){
                log.debug("Unable to retrieve identity object with name " + idName);
            }
        }

        if (id != null && Util.otob(id.getAttribute(THD_Constants_IdentityAttributes.BADGE_ENABLED))) {
            accReqs = plan.getAccountRequests();
            if (accReqs == null) {
                log.trace("Account Requests = NULL");
                accReqs = new ArrayList<AccountRequest>();
            }
            badgeAccountRequest.setOperation(AccountRequest.Operation.Create);
            badgeAccountRequest.setNativeIdentity(id.getName());
            badgeAccountRequest.setApplication("CorpSecHRBadgeInterface");
            accReqs.add(badgeAccountRequest);
            plan.setAccountRequests(accReqs);
            log.trace("Badge Account Request added to plan");
            badgeAccountRequestAdded = true;
        }
        else {
            badgeAccountRequestAdded = false;
        }
        log.trace("Returning badgeAccountRequestAdded: " + String.valueOf(badgeAccountRequestAdded));
        log.trace("EXITING getBadgingAccountRequestJoiner");
        return badgeAccountRequestAdded;
    }
}

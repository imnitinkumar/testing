package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_Birthright;
import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.util.THD_Util_Birthright;
import com.ey.iiq.util.THD_Util_SearchUtil;
import com.magnolia.iiq.build.Rule;
import java.sql.SQLException;
import java.util.List;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Message;
import sailpoint.tools.Util;

@Rule(name = "THD-Rule-GetIdentityBirthrightInfo", filename = "THD-Rule-GetIdentityBirthrightInfo.xml")
public class THD_Rule_GetIdentityBirthrightInfo {

    public String getIdentityBirthrightInfo(SailPointContext context, TaskResult taskResult)
            throws GeneralException, SQLException {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-GetIdentityBirthrightInfo");
        log.setLevel(Level.TRACE);
        log.trace("ENTERING getIdentityBirthrightInfo()");

        // The identity that must be fetched from the task definition that will also act as a flag
        Identity identity = null;
        String identityName = null;

        // String that can be used when error is to be written multiple times
        String errorMessage;

        log.debug("Get the required values from SailPoint Custom Objects");
        List<String> birthrightApplications = THD_Util_Birthright.getBirthrightApplications(context);
        List<String> identityAttributes     = THD_Util_Birthright.getBirthrightIdentityAttributes(context);

        // Check if the required values were retrieved from Custom Objects
        if (birthrightApplications == null || birthrightApplications.isEmpty() ||
                identityAttributes == null || identityAttributes.isEmpty()) {
            if (birthrightApplications == null || birthrightApplications.isEmpty())
                log.debug("Failed to retrieve birthright applications");
            if (identityAttributes == null || identityAttributes.isEmpty())
                log.error("Failed to retrieve birthright identity attributes");

            errorMessage = "Unable to retrieve required values from Custom Objects from SailPoint, " +
                    "view log for more details";
            taskResult.addMessage(new Message(Message.Type.Error, errorMessage, (Object) null));
        } else {
            log.debug("Successfully retrieved required values from Custom Objects");

            // Get the task definition and check to ensure it was retrieved
            TaskDefinition taskDef = context.getObjectByName(
                    TaskDefinition.class, THD_Constants_Birthright.TASK_GET_IDENTITY_BIRTHRIGHT_INFO);
            if (taskDef == null) {
                errorMessage = "Failed to Obtain Required Task Definition";
                log.error(errorMessage);
                taskResult.addMessage(new Message(Message.Type.Error, errorMessage, (Object) null));
            } else {
                log.debug("Successfully retrieved Task Definition required");

                // Get the identity name from the task definition and check to ensure it was retrieved
                identityName = taskDef.getString("selectedIdentity");
                if (Util.isNullOrEmpty(identityName)) {
                    errorMessage = "Must Specify Desired Identity";
                    log.error(errorMessage);
                    taskResult.addMessage(new Message(Message.Type.Error, errorMessage, (Object) null));
                } else {
                    log.debug("An identity was specified, checking to see if it exists");

                    identity = context.getObjectByName(Identity.class, identityName);
                    if (identity == null) {
                        errorMessage = "Failed to Find Desired Identity: " + identityName;
                        log.error(errorMessage);
                        taskResult.addMessage(new Message(Message.Type.Error, errorMessage, (Object) null));
                    } else {
                        log.debug("Successfully found identity '" + identityName + "'");
                    }
                }
            }
        }

        // If the identity is not null then all required values have been fetched
        if (identity != null) {
            log.debug("Get the list of birthright accounts the identity should receive:");
            List<String> birthrightAccounts = THD_Util_Birthright.getBirthrightAccounts(context, identityName);

            // Loop through all existing birthright applications checking if the identity gets an account on it
            for (String birthrightApplication : birthrightApplications) {

                // Set the application dependant values that will be shown in the taskResult
                String entitlementsAttribute;
                String getsAccountAttribute;
                String numEntitlementsAttribute;
                if (birthrightApplication.equalsIgnoreCase("AMER Active Directory")) {
                    entitlementsAttribute    = "AD_ENTITLEMENTS";
                    getsAccountAttribute     = "GETS_AD_ACCOUNT";
                    numEntitlementsAttribute = "NUM_AD_ENTITLEMENTS";
                } else if (birthrightApplication.equalsIgnoreCase("CORP ODSEE")) {
                    entitlementsAttribute    = "CORP_LDAP_ENTITLEMENTS";
                    getsAccountAttribute     = "GETS_CORP_LDAP_ACCOUNT";
                    numEntitlementsAttribute = "NUM_CORP_LDAP_ENTITLEMENTS";
                } else if (birthrightApplication.equalsIgnoreCase("CorpSecHRBadgeInterface")) {
                    entitlementsAttribute    = THD_Constants_General.EMPTY_STRING;
                    getsAccountAttribute     = "GETS_BADGING_ACCOUNT";
                    numEntitlementsAttribute = THD_Constants_General.EMPTY_STRING;
                }else if (birthrightApplication.equalsIgnoreCase("SCORE-CAN")) {
                    entitlementsAttribute    = "SAP_ENTITLEMENTS";
                    getsAccountAttribute     = "GETS_SAP_ACCOUNT";
                    numEntitlementsAttribute = "NUM_SAP_ENTITLEMENTS";
                } else if (birthrightApplication.equalsIgnoreCase("STORE INFORMIX")) {
                    entitlementsAttribute    = "STORE_INFORMIX_ENTITLEMENTS";
                    getsAccountAttribute     = "GETS_STORE_INFORMIX_ACCOUNT";
                    numEntitlementsAttribute = "NUM_STORE_INFORMIX_ENTITLEMENTS";
                } else if (birthrightApplication.equalsIgnoreCase("STORE ODSEE")) {
                    entitlementsAttribute    = "STORE_LDAP_ENTITLEMENTS";
                    getsAccountAttribute     = "GETS_STORE_LDAP_ACCOUNT";
                    numEntitlementsAttribute = "NUM_STORE_LDAP_ENTITLEMENTS";
                } else {
                    entitlementsAttribute    = THD_Constants_General.EMPTY_STRING;
                    getsAccountAttribute     = THD_Constants_General.EMPTY_STRING;
                    numEntitlementsAttribute = THD_Constants_General.EMPTY_STRING;

                    errorMessage = "Application '" + birthrightApplication +
                            "' may not be defined in taskDefinition or above this log statement in the rule";
                    log.warn(errorMessage);
                    taskResult.addMessage(new Message(Message.Type.Warn, errorMessage, (Object) null));
                }

                // Check if the identity gets an account on the current birthright application
                if (!birthrightAccounts.contains(birthrightApplication)) {
                    log.debug("Identity does not get a birthright account on application '" + birthrightApplication + "'");
                    taskResult.setAttribute(getsAccountAttribute, false);
                } else {
                    log.debug("Identity does get a birthright account on application '" + birthrightApplication + "'");
                    taskResult.setAttribute(getsAccountAttribute, true);

                    if (THD_Util_Birthright.hasBirthrightTable(context, birthrightApplication)) {

                        // Get the application object from SailPoint and ensure it was retrieved
                        Application application = THD_Util_SearchUtil.getApplication(context, birthrightApplication);
                        if (application == null) {
                            errorMessage = "Failed to find application '" + birthrightApplication + "' in SailPoint";
                            log.error(errorMessage);
                            taskResult.addMessage(new Message(Message.Type.Error, errorMessage, (Object) null));
                        } else {
                            log.debug("Successfully found application '" + birthrightApplication + "' in SailPoint");

                            // Get the group attribute off of the application (assume only one)
                            if (application.getGroupAttributes() == null || application.getGroupAttributes().isEmpty()) {
                                errorMessage = "Failed to find a group attribute on application '" + birthrightApplication + "'";
                                log.error(errorMessage);
                                taskResult.addMessage(new Message(Message.Type.Error, errorMessage, (Object) null));
                            } else {
                                String groupAttributeName = application.getGroupAttributes().get(0).getName();
                                log.debug("Successfully found group attribute name '" + groupAttributeName + "' on application");

                                // Get the birthright table name using the application name and check to ensure it was retrieved
                                String birthrightTableName =
                                        THD_Util_Birthright.getBirthrightTableName(context, birthrightApplication);
                                if (Util.isNullOrEmpty(birthrightTableName)) {
                                    errorMessage = "Failed to retrieve birthright table name using application '" +
                                            birthrightApplication + "' from Custom Object";
                                    log.error(errorMessage);
                                    taskResult.addMessage(new Message(Message.Type.Error, errorMessage, (Object) null));
                                } else {
                                    log.debug("Birthright table name from Custom Object: " + birthrightTableName);

                                    log.debug("Get the birthright entitlements (without checking if they exist in SailPoint)");
                                    List<String> birthrightEntitlements =
                                            THD_Util_Birthright.getBirthrightEntitlements(false,
                                                    identity, identityAttributes, context, birthrightApplication,
                                                    birthrightTableName, groupAttributeName);

                                    // The list can be empty but if it is null then there was a failure
                                    if (birthrightEntitlements == null) {
                                        errorMessage = "Failed to get entitlements for application '" + birthrightApplication + "'";
                                        log.error(errorMessage);
                                        taskResult.addMessage(new Message(Message.Type.Error, errorMessage, (Object) null));
                                    } else {
                                        log.debug("Successfully retrieved birthright entitlements");

                                        // Add the number of entitlements to the taskResult
                                        int numBirthrightEntitlements = birthrightEntitlements.size();
                                        taskResult.setAttribute(numEntitlementsAttribute, numBirthrightEntitlements);

                                        // If the number of entitlements was greater than 0 then display the entitlements themselves
                                        if (numBirthrightEntitlements > 0) {

                                            // Translate the list into a string with entitlements on new lines
                                            StringBuilder birthrightEntitlementsBuilder = new StringBuilder();
                                            for (String birthrightEntitlement : birthrightEntitlements) {

                                                // Check for first value to avoid appending new line on first entry
                                                if (birthrightEntitlementsBuilder.length() > 0) {
                                                    birthrightEntitlementsBuilder.append(THD_Constants_General.NEW_LINE);
                                                }
                                                birthrightEntitlementsBuilder.append(birthrightEntitlement);
                                            }

                                            // Translate the StringBuilder and add it to the taskResult
                                            String birthrightEntitlementsString = birthrightEntitlementsBuilder.toString();
                                            taskResult.setAttribute(entitlementsAttribute, birthrightEntitlementsString);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Finalize the taskResult by adding the Success message
            taskResult.addMessage(new Message(Message.Type.Info,
                    "Successfully Fetched Birthright Info for Identity: " + identityName, (Object) null));
            taskResult.setCompletionStatus(TaskResult.CompletionStatus.Success);
        }

        // Save and commit the changes to the taskResult
        context.saveObject(taskResult);
        context.commitTransaction();

        log.trace("EXITING getIdentityBirthrightInfo()");
        return "Complete";
    }
}
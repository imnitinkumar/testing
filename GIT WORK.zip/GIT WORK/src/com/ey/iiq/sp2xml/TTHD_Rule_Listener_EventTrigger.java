package com.ey.iiq.sp2xml;

import com.magnolia.iiq.build.Rule;
import sailpoint.api.SailPointContext;
import sailpoint.object.AuditEvent;
import sailpoint.object.Identity;
import sailpoint.server.Auditor;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

@Rule(name="THD-Rule-Listener-EventTrigger",filename="THD-Rule-Listener-EventTrigger.xml", type="Listener")
public class THD_Rule_Listener_EventTrigger {
    /**
     * This rule can be used when the ObjectAttribute being listened to has changed.
     *
     * @param environment         Optional arguments passed from the task executor, if the rule is running within a task.
     * @param identity            The identity which owns the attribute.
     * @param attributeDefinition The definition of the ObjectAttribute.
     * @param attributeName       The name of the ObjectAttribute.
     * @param oldValue            The original value of the ObjectAttribute.
     * @param newValue            The new value of the ObjectAttribute.
     */
    public static void listener(Object environment, Identity identity, SailPointContext context, Object attributeDefinition, Object attributeName, Object oldValue, Object newValue) throws GeneralException {
        if ( oldValue != null && newValue != null )
        {
            String action = "EventTrigger";
            String nValStr = Util.otos(newValue);
            String oValStr = Util.otos(oldValue);
            String aNameStr = Util.otos(attributeName);

            if(!nValStr.equalsIgnoreCase("No Event to be Triggered"))
            {
                AuditEvent event = new AuditEvent();
                event.setTarget(identity.getName());
                event.setAction(action);
                String applicationName = "IIQ";
                event.setAccountName(identity.getName());
                event.setApplication(applicationName);
                event.setAttributeName(aNameStr);
                event.setString1(nValStr);
                Auditor.log(event);
                context.commitTransaction();
            }
        }
    }
}

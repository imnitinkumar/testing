package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_ProvisioningPolicy;
import com.magnolia.iiq.build.Rule;
import sailpoint.object.AttributeTarget;
import sailpoint.object.Identity;
import sailpoint.object.Link;
import sailpoint.object.ProvisioningProject;
import sailpoint.tools.Util;

import java.util.ArrayList;
import java.util.List;

@Rule(name="THD-Rule-IdentityAttributeTarget-ProxyAddress", filename = "THD-Rule-IdentityAttributeTarget-ProxyAddress.xml", type="IdentityAttributeTarget")
public class THD_Rule_IdentityAttributeTarget_ProxyAddress {
    /**
     * Identity attribute target rules are used to tranform identity attribute values that are being pushed to targets.
     *
     * @param value                       The value of the identity attribute. Note that this could be single value or a list of values.
     * @param sourceIdentityAttribute     The sailpoint.object.ObjectAttribute for this target.
     * @param sourceIdentityAttributeName The name of the identity attribute for this target.
     * @param sourceAttributeRequest      The sailpoint.object.ProvisioningPlan.AttributeRequest that is setting the attribute on the identity.
     * @param target                      The sailpoint.object.AttributeTarget that is being processed.
     * @param identity                    The sailpoint.object.Identity that is being processed.
     * @param project                     The sailpoint.object.ProvisioningProject that has the changes that are being requested.
     * @return attributeValue The transformed value that will be pushed to the target.
     */
    public static Object identityAttributeTarget(Object value, Object sourceIdentityAttribute, Object sourceIdentityAttributeName, Object sourceAttributeRequest, AttributeTarget target, Identity identity, ProvisioningProject project, Link link) {
        List<String> attrVals = new ArrayList<String>();
        List<String> proxyAddresses = Util.otol(link.getAttribute("proxyAddresses"));
        String email = Util.otos(value);
        String uid = Util.otos(identity.getName());
        String newSmtp = "";
        String newSmtp2 = "";
        if (email!=null ){
            newSmtp = String.format(THD_Constants_ProvisioningPolicy.AD_PROXY_ADDRESS,email);
        }
        if (Util.isNotNullOrEmpty(uid)){
            newSmtp2 = String.format(THD_Constants_ProvisioningPolicy.AD_PROXY_ADDRESS2,uid,"%%AD_SMTP_PROXY_DOMAIN%%");
        }

        if (proxyAddresses == null){
            proxyAddresses=new ArrayList<>();
        }

        for (String proxyAddress : proxyAddresses) {
            if (!proxyAddress.equalsIgnoreCase(newSmtp) && !proxyAddress.equalsIgnoreCase(newSmtp2)){
                if (proxyAddress.contains("SMTP")){
                    attrVals.add(proxyAddress.replace("SMTP","smtp"));
                }
            }
        }
        if (Util.isNotNullOrEmpty(newSmtp)) attrVals.add(newSmtp);
        if (Util.isNotNullOrEmpty(newSmtp2)) attrVals.add(newSmtp2);

        return attrVals;
    }
}

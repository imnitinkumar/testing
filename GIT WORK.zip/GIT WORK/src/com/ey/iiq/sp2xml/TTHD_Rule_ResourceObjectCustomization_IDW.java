package com.ey.iiq.sp2xml;

import com.magnolia.iiq.build.Rule;
import com.magnolia.iiq.build.RuleReference;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.Application;
import sailpoint.object.ResourceObject;

import java.util.Map;

@Rule(name="THD-Rule-ResourceObjectCustomization-IDW",filename="THD-Rule-ResourceObjectCustomization-IDW.xml",type="ResourceObjectCustomization")
public class THD_Rule_ResourceObjectCustomization_IDW {
    @RuleReference(name="THD-RuleLibrary-LifecycleEventConfiguration")
    private THD_RuleLibrary_LifecycleEventConfiguration LCE_RuleLibrary = new THD_RuleLibrary_LifecycleEventConfiguration();
    /**
     * This rule is configured on the application and is called after the connector has build a ResourceObject from the native application data.Initially designed for non-rule based connectors to add SPPrivileged flag to an object, but could be used to do any transformations.
     *
     * @param object      The ResourceObject built by the connector.
     * @param application Application that references the connector.
     * @param connector   The connector object.
     * @param state       A Map containing state information.
     * @return resourceObject The updated resource object.
     */
    public ResourceObject resourceObjectCustomization(ResourceObject object, SailPointContext context, Application application, Object connector, Map state) throws Exception {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-resourceObjectCustomization-IDW");
        log.setLevel(Level.TRACE);
        log.trace("Entering THD-Rule-ResourceObjectCustomization-IDW");
        ResourceObject newResourceObject;
        if (object == null){
            log.trace("OBJECT IS NULL");
        }
        newResourceObject =  LCE_RuleLibrary.updateIDWResourceObject(object, context);
        if (newResourceObject== null)
            log.trace("newResourceObject is null");

        log.trace("Exiting THD-Rule-ResourceObjectCustomization-IDW");
        return newResourceObject;
    }
}

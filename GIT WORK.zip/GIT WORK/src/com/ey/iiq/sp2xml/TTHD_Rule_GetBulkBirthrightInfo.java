package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_Birthright;
import com.ey.iiq.constants.THD_Constants_General;
import com.ey.iiq.util.THD_Util_Birthright;
import com.ey.iiq.util.THD_Util_SearchUtil;
import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.*;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Message;
import sailpoint.tools.Util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Rule(name = "THD-Rule-GetBulkBirthrightInfo", filename = "THD-Rule-GetBulkBirthrightInfo.xml")
public class THD_Rule_GetBulkBirthrightInfo {
    public String getIdentityBirthrightInfo(SailPointContext context)
            throws GeneralException, SQLException, IOException {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-GetIdentityBirthrightInfo");
        log.setLevel(Level.TRACE);
        log.trace("ENTERING getIdentityBirthrightInfo()");

        // The identity that must be fetched from the task definition that will also act as a flag
        List<Identity> identityList = null;
        Iterator iter = null;
        String fullName = "";
        String basePath = "/home/a_iiq/birthrightExport/%s%s.csv";
        String fileName = "birthrightExport";
        int exportCount = 0;
        fullName = String.format(basePath,fileName,exportCount);
        File f = new File(fullName);
        while(f.exists()){
            fullName=String.format(basePath,fileName,(++exportCount));
            f = new File(fullName);
        }
        f.createNewFile();
        FileWriter fw = new FileWriter(fullName);


        // String that can be used when error is to be written multiple times
        String errorMessage;

        log.debug("Get the required values from SailPoint Custom Objects");
        List<String> birthrightApplications = THD_Util_Birthright.getBirthrightApplications(context);
        List<String> identityAttributes     = THD_Util_Birthright.getBirthrightIdentityAttributes(context);

        // Check if the required values were retrieved from Custom Objects
        if (birthrightApplications == null || birthrightApplications.isEmpty() ||
                identityAttributes == null || identityAttributes.isEmpty()) {
            if (birthrightApplications == null || birthrightApplications.isEmpty())
                log.debug("Failed to retrieve birthright applications");
            if (identityAttributes == null || identityAttributes.isEmpty())
                log.error("Failed to retrieve birthright identity attributes");

            errorMessage = "Unable to retrieve required values from Custom Objects from SailPoint, " +
                    "view log for more details";
        } else {
            log.debug("Successfully retrieved required values from Custom Objects");

            List filters = new ArrayList();
            QueryOptions qo = new QueryOptions();
            List<Filter> fl = new ArrayList<Filter>();
            fl.add(Filter.eq("uid","JX002"));
            fl.add(Filter.eq("uid","JX003"));
            fl.add(Filter.eq("uid","JX004"));
            fl.add(Filter.eq("uid","JX005"));
            fl.add(Filter.eq("uid","JX006"));
            //fl.add(Filter.notnull("uid"));
            qo.addFilter(Filter.or(fl));
            //qo.addFilter(Filter.contains( "uid","JX0"));
            iter = context.search(Identity.class, qo);
        }

        // If the identity is not null then all required values have been fetched
        if (iter != null && iter.hasNext()) {
            log.debug("Get the list of birthright accounts the identity should receive:");
            while(iter.hasNext()) {
                Identity identity = (Identity)iter.next();
                List<String> birthrightAccounts = THD_Util_Birthright.getBirthrightAccounts(context, identity.getName());

                // Loop through all existing birthright applications checking if the identity gets an account on it
                for (String birthrightApplication : birthrightApplications) {

                    // Check if the identity gets an account on the current birthright application
                    if (!birthrightAccounts.contains(birthrightApplication)) {
                        log.debug("Identity does not get a birthright account on application '" + birthrightApplication + "'");
                    } else {
                        log.debug("Identity does get a birthright account on application '" + birthrightApplication + "'");

                        if (THD_Util_Birthright.hasBirthrightTable(context, birthrightApplication)) {

                            // Get the application object from SailPoint and ensure it was retrieved
                            Application application = THD_Util_SearchUtil.getApplication(context, birthrightApplication);
                            if (application == null) {
                                errorMessage = "Failed to find application '" + birthrightApplication + "' in SailPoint";
                                log.error(errorMessage);
                            } else {
                                log.debug("Successfully found application '" + birthrightApplication + "' in SailPoint");

                                // Get the group attribute off of the application (assume only one)
                                if (application.getGroupAttributes() == null || application.getGroupAttributes().isEmpty()) {
                                    errorMessage = "Failed to find a group attribute on application '" + birthrightApplication + "'";
                                    log.error(errorMessage);
                                } else {
                                    String groupAttributeName = application.getGroupAttributes().get(0).getName();
                                    log.debug("Successfully found group attribute name '" + groupAttributeName + "' on application");

                                    // Get the birthright table name using the application name and check to ensure it was retrieved
                                    String birthrightTableName =
                                            THD_Util_Birthright.getBirthrightTableName(context, birthrightApplication);
                                    if (Util.isNullOrEmpty(birthrightTableName)) {
                                        errorMessage = "Failed to retrieve birthright table name using application '" +
                                                birthrightApplication + "' from Custom Object";
                                        log.error(errorMessage);
                                    } else {
                                        log.debug("Birthright table name from Custom Object: " + birthrightTableName);
                                        log.debug("Get the birthright entitlements (without checking if they exist in SailPoint)");
                                        List<String> birthrightEntitlements =
                                                THD_Util_Birthright.getBirthrightEntitlements(false,
                                                        identity, identityAttributes, context, birthrightApplication,
                                                        birthrightTableName, groupAttributeName);

                                        // The list can be empty but if it is null then there was a failure
                                        if (birthrightEntitlements == null) {
                                            errorMessage = "Failed to get entitlements for application '" + birthrightApplication + "'";
                                            log.error(errorMessage);
                                        } else {
                                            log.debug("Successfully retrieved birthright entitlements");

                                            // Add the number of entitlements to the taskResult
                                            int numBirthrightEntitlements = birthrightEntitlements.size();

                                            // If the number of entitlements was greater than 0 then display the entitlements themselves
                                            if (numBirthrightEntitlements > 0) {

                                                // Translate the list into a string with entitlements on new lines
                                                StringBuilder birthrightEntitlementsBuilder = new StringBuilder();
                                                String line;
                                                int lineCount=0;

                                                for (String birthrightEntitlement : birthrightEntitlements) {
                                                    // Check for first value to avoid appending new line on first entry
                                                    line = String.format("%s\t%s\t%s\n",identity.getName(),birthrightApplication,birthrightEntitlement);
                                                    birthrightEntitlementsBuilder.append(line);
                                                    lineCount+=1;
                                                    if (lineCount%1000==0){
                                                        fw.append(birthrightEntitlementsBuilder.toString());
                                                        birthrightEntitlementsBuilder.setLength(0);
                                                    }
                                                }
                                                fw.append(birthrightEntitlementsBuilder.toString());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            fw.close();
        }
        log.trace("EXITING getIdentityBirthrightInfo()");
        return "File Written to: " + fullName;
    }
}

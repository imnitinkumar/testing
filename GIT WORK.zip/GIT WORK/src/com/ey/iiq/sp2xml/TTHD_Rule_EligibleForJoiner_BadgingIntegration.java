package com.ey.iiq.sp2xml;

import com.ey.iiq.constants.THD_Constants_IdentityAttributes;
import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.Identity;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

@Rule(name="THD-Rule-EligibleForJoiner-BadgingIntegration", filename = "THD-Rule-EligibleForJoiner-BadgingIntegration.xml")
public class THD_Rule_EligibleForJoiner_BadgingIntegration {
    public boolean execute(SailPointContext context, String identityName) {
        Logger log = Logger.getLogger("thd.iam.rule.THD-Rule-EligibleForJoiner-BadgingIntegration");
        log.trace("ENTERING THD-Rule-EligibleForJoiner-BadgingIntegration");

        // The flag to be returned that represents if the identity meets the criteria for a Badging account
        boolean meetsCriteria = false;

        try {
            Identity identity = context.getObjectByName(Identity.class, identityName);
            meetsCriteria = Util.otob(identity.getAttribute(THD_Constants_IdentityAttributes.BADGE_ENABLED));
        } catch (GeneralException e) {
            log.error("Exception Caught in THD-Rule-EligibleForJoiner-BadgingIntegration: " + e.toString());
        }

        log.trace("EXITING THD-Rule-EligibleForJoiner-BadgingIntegration");
        return meetsCriteria;
    }
}
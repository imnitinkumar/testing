package com.ey.iiq.sp2xml;

import com.magnolia.iiq.build.Rule;
import org.apache.log4j.Logger;

@Rule(name="THD-Rule-EligibleForJoiner-EPR", filename = "THD-Rule-EligibleForJoiner-EPR.xml")
public class THD_Rule_EligibleForJoiner_EPR {
    public boolean execute() {
        Logger log = Logger.getLogger("thd.iam.THD-Rule-EligibleForJoiner-EPR");
        log.trace("ENTERING THD-Rule-EligibleForJoiner-EPR");

        // All identities meet the criteria for an EPR account

        log.trace("EXITING THD-Rule-EligibleForJoiner-EPR");
        return true;
    }
}

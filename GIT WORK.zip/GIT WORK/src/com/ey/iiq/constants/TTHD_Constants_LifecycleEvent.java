package com.ey.iiq.constants;

public class THD_Constants_LifecycleEvent {

    // Custom Objects
    public static final String CUSTOM_LIFECYCLE_CONFIGURATIONS = "THD_Custom_LifeCycle_Configurations";

    // Lifecycle Event Flags
    public static final String JOINER_FLAG = "Joiner";
    public static final String LEAVER_FLAG = "Leaver";
    public static final String CONTRACTOR_SUSPENSION_FLAG = "ContractorSuspension";
    public static final String CONTRACTOR_REINSTATE_FLAG = "ContractorReinstate";
    public static final String LOA_FLAG = "LeaveOfAbsence";
    public static final String MOVER_CORP_FLAG = "MoverCorp";
    public static final String MOVER_FLAG = "Mover";
    public static final String MOVER_STORE_INTERNAL_FLAG = "MoverStoreInternal";
    public static final String MOVER_STORE_TO_STORE_FLAG = "MoverStoreToStore";
    public static final String MOVER_STORE_TO_CORP_FLAG = "MoverStoreToCorp";
    public static final String MOVER_CORP_TO_STORE_FLAG = "MoverCorpToStore";
    public static final String MOVER_CORP_TRANSFER_FLAG = "MoverCorpTransfer";
    public static final String PREHIRE_FLAG = "Prehire";
    public static final String REHIRE_FLAG = "Rehire";
    public static final String RLOA_FLAG = "ReturnFromLeaveOfAbsence";
    public static final String NONE_FLAG = "None";

    // Resource Object Keys
    public static final String EVENT_TO_BE_TRIGGERED_KEY = "eventToBeTriggered";
    public static final String EVENT_PROCESSED_STATUS = "eventProcessedStatus";
    public static final String IIQ_DISABLED_KEY = "IIQDisabled";
}
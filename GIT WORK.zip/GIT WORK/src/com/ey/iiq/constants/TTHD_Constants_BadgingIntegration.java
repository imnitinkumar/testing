package com.ey.iiq.constants;

public class THD_Constants_BadgingIntegration {

    public static final String DATE_PATTERN="yyyy-MM-dd-hhmmss";

    //Application Attributes
    public static final String APP_NAME="CorpSecHRBadgeInterface";
    public static final String SFTP_HOST="host";
    public static final String SFTP_PORT="port";
    public static final String SFTP_USER="transportUser";
    public static final String SFTP_USER_PASSWORD="transportUserPassword";

    //CUSTOM OBJECTS
    public static final String CUSTOM_MAPPINGS="THD-Custom-BadgingIntegration-Mappings";
    public static final String CUSTOM_MAPPINGS_BASE_PATH="baseFilePath";
    public static final String CUSTOM_MAPPINGS_FILE_ATTRIBUTES="fileAttributes";
    public static final String CUSTOM_MAPPINGS_TO_LIST="toList";

    //EMAIL TEMPLATE
    public static final String FAILURE_EMAIL_TEMPLATE="THD-EmailTemplate-BadgingIntegration-FileWriteError";
    public static final String FAILURE_EMAIL_DATE="date";
    public static final String FAILURE_EMAIL_UID="uid";
    public static final String FAILURE_EMAIL_FIRST_NAME="fName";
    public static final String FAILURE_EMAIL_LAST_NAME="lName";
    public static final String FAILURE_EMAIL_EMAIL="email";
    public static final String FAILURE_EMAIL_USER_TYPE="userType";

    //PROVISION FAILURE
    public static final String PROVISION_FAILURE_MESSAGE = "Unable to write file to Badging Server. Provisioning Failed.";

    //BADGE STATUS VALUES:
    public static final String BADGE_STATUS="badge status";
    public static final String BADGE_STATUS_ACTIVE="A";
    public static final String BADGE_STATUS_INACTIVE="I";
    public static final String BADGE_STATUS_TERMINATED="T";
}

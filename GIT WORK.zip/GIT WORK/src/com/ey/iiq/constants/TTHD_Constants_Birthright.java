package com.ey.iiq.constants;

public class THD_Constants_Birthright {

    // Approval Comments
    public static final String APPROVAL_COMMENTS_ADD_RULE_SHELL =
            "New Birthright Rule:\n" +
                    "%s" +
                    "Number of identities that meet the criteria of the new rule: %d\n" +
                    "Number of identities that will gain the entitlement: %d";

    public static final String APPROVAL_COMMENTS_MODIFY_RULE_SHELL =
            "New Birthright Rule:\n" +
                    "%s" +
                    "Number of identities that meet the criteria of the new rule: %d\n" +
                    "Number of identities that will gain the entitlement: %d\n\n" +
                    "Old Birthright Rule:\n" +
                    "%s" +
                    "Number of identities that meet the criteria of the old rule: %d\n" +
                    "Number of identities that will lose the entitlement: %d";

    public static final String UPDATED_APPROVAL_COMMENTS_MODIFY_RULE_SHELL =
            "After the initial approval it was determined that the identities affected has changed.\n" +
                    "Below is the updated result of modifying rule: %s\n\n" +
                    "New Birthright Rule:\n" +
                    "%s" +
                    "Number of identities that meet the criteria of the new rule: %d\n" +
                    "Number of identities that will gain the entitlement: %d\n\n" +
                    "Old Birthright Rule:\n" +
                    "%s" +
                    "Number of identities that meet the criteria of the old rule: %d\n" +
                    "Number of identities that will lose the entitlement: %d";

    // Birthright Rule to String
    public static final String BIRTHRIGHT_RULE_TO_STRING_SHELL =
            "Application: %s\n" +
                    "Entitlement: %s\n" +
                    "Rule Id: %s\n" +
                    "Description: %s\n" +
                    "Disabled: %s\n" +
                    "Dynamic: %s\n" +
                    "Equals Criteria:\n" +
                    "%s" +
                    "Not Equals Criteria:\n" +
                    "%s";
    public static final String CRITERIA_EQUALS_VALUE = "\t%s: %s\n";
    public static final String NO_CRITERIA = "\tNone\n";

    // Custom Object Attributes
    public static final String CUSTOM_ATTRIBUTE_DISABLE_ON_DELETE = "disableOnDelete";
    public static final String CUSTOM_ATTRIBUTE_TABLE_NAME = "tableName";

    // Custom Object Names
    public static final String CUSTOM_OBJECT_BIRTHRIGHT_IDENTITY_ATTRIBUTES = "THD-Custom-Birthright-IdentityAttributes";
    public static final String CUSTOM_OBJECT_BIRTHRIGHT_MAPPINGS = "THD-Custom-Birthright-Mappings";

    // Dynamic AD Group Attributes
    public static final String DYNAMIC_DISTRICT_ATTRIBUTE = "_district_";
    public static final String DYNAMIC_DIVISION_ATTRIBUTE = "_division_";
    public static final String DYNAMIC_PROVINCE_ATTRIBUTE = "_province_";
    public static final String DYNAMIC_REGION_ATTRIBUTE = "_region_";
    public static final String DYNAMIC_STATE_ATTRIBUTE = "_state_";
    public static final String DYNAMIC_STORE_ATTRIBUTE = "_store_";

    // Identity Attributes
    public static final String DISTRICT_NUMBER_ATTRIBUTE = "districtNumber";
    public static final String DIVISION_NAME_ATTRIBUTE = "divisionName";
    public static final String DIVISION_NUMBER_ATTRIBUTE = "divisionNumber";
    public static final String JOB_TITLE_ATTRIBUTE = "jobTitle";
    public static final String REGION_NAME_ATTRIBUTE = "regionName";
    public static final String REGION_NUMBER_ATTRIBUTE = "regionNumber";
    public static final String STATE_PROVINCE_CODE_ATTRIBUTE = "stateProvinceCode";
    public static final String LOCATION_NUMBER_ATTRIBUTE = "locationNumber";

    // JSON Map Field Names
    public static final String APPLICATION_JSON_FIELD = "application";
    public static final String ASSIGNMENT_CRITERIA_JSON_FIELD = "assignmentCriteria";
    public static final String BIRTHRIGHT_APPLICATIONS_JSON_FIELD = "birthrightApplications";
    public static final String DESCRIPTION_JSON_FIELD = "description";
    public static final String DISABLED_JSON_FIELD = "disabled";
    public static final String DYNAMIC_JSON_FIELD = "dynamic";
    public static final String ENDS_IN_SUP_JSON_FIELD = "endsInSUP";
    public static final String ENTITLEMENT_JSON_FIELD = "entitlement";
    public static final String ENTITLEMENTS_JSON_FIELD = "entitlements";
    public static final String EQUALS_JSON_FIELD = "equals";
    public static final String NOT_EQUALS_JSON_FIELD = "notEquals";
    public static final String RULE_ID_JSON_FIELD = "ruleId";
    public static final String RULES_JSON_FIELD = "rules";
    public static final String WORKFLOW_ARGS_JSON_FIELD = "workflowArgs";

    // Misc Required Values
    public static final String ERROR_MESSAGE = "error";
    public static final String IDENTITY_ATTRIBUTE_VARCHAR_SIZE = "VARCHAR(32)";
    public static final String LINK_APPLICATION_NAME = "links.application.name";
    public static final String NAME_PROPERTY = "name";
    public static final String RULE_CHANGELOG_TABLE_NAME = "birthright_rule_changelog";
    public static final String SUP_SUFFIX = "SUP";

    // Operations
    public static final String ADD_RULE_OPERATION = "add";
    public static final String MODIFY_RULE_OPERATION = "modify";

    // Process Rule Map
    public static final String ADD_RULE_QUERY_KEY = "addRuleQuery";
    public static final String APPLICATION_NAME_KEY = "applicationName";
    public static final String APPROVAL_COMMENTS_KEY = "approvalComments";
    public static final String BIRTHRIGHT_IDENTITY_ATTRIBUTES_KEY = "identityAttributes";
    public static final String BIRTHRIGHT_TABLE_NAME_KEY = "birthrightTableName";
    public static final String DYNAMIC_KEY = "dynamic";
    public static final String GAINING_ENTITLEMENT_KEY = "identitiesThatWillGainEntitlement";
    public static final String GROUP_ATTRIBUTE_NAME_KEY = "groupAttributeName";
    public static final String IDENTITIES_AFFECTED_CHANGED_KEY = "identitiesAffectedChanged";
    public static final String LOSING_ENTITLEMENT_KEY = "identitiesThatWillLoseEntitlement";
    public static final String MEET_NEW_CRITERIA_KEY = "identitiesMeetingNewRuleCriteria";
    public static final String MEET_OLD_CRITERIA_KEY = "identitiesMeetingOldRuleCriteria";
    public static final String MODIFY_RULE_QUERY_KEY = "modifyRuleQuery";
    public static final String NEW_ENTITLEMENT_NAME_KEY = "newEntitlementName";
    public static final String NEW_RULE_AS_STRING_KEY = "newRuleAsString";
    public static final String NUM_MEET_NEW_CRITERIA_KEY = "numIdentitiesMeetingNewRuleCriteria";
    public static final String NUM_MEET_OLD_CRITERIA_KEY = "numIdentitiesMeetingOldRuleCriteria";
    public static final String NUM_GAINING_ENTITLEMENT_KEY = "numIdentitiesThatWillGainEntitlement";
    public static final String NUM_LOSING_ENTITLEMENT_KEY = "numIdentitiesThatWillLoseEntitlement";
    public static final String OLD_ENTITLEMENT_NAME_KEY = "oldEntitlementName";
    public static final String OLD_RULE_AS_STRING_KEY = "oldRuleAsString";
    public static final String RULE_CHANGELOG_INSERT_STATEMENT_KEY = "ruleChangelogInsertStatement";
    public static final String RULE_ID_KEY = "ruleId";

    // SQL String Shells
    public static final String AND_COLUMN_IS_NULL_OR_EQUALS_VALUE = "AND (%s IS NULL OR %s = '%s')";
    public static final String COLUMN_EQUALS_NULL = "\t%s = NULL,\n";
    public static final String COLUMN_EQUALS_VALUE = "\t%s = '%s',\n";
    public static final String VALUE_TO_SQL_STRING = "'%s'";

    // Table Column Names
    public static final String DISABLED_COLUMN_NAME = "disabled";
    public static final String DESCRIPTION_COLUMN_NAME = "description";
    public static final String DYNAMIC_COLUMN_NAME = "dynamic";
    public static final String ENDS_IN_SUP_COLUMN_NAME = "endsInSUP";
    public static final String ENTITLEMENT_COLUMN_NAME = "entitlement";
    public static final String NOT_LIST_COLUMN_NAME = "notList";
    public static final String RULE_ID_COLUMN_NAME = "ruleId";

    // Task Definition Names
    public static final String TASK_GET_IDENTITY_BIRTHRIGHT_INFO = "THD-TaskDefinition-RunRule-GetIdentityBirthrightInfo";

    // Birthright Table Query Shells
    public static final String ADD_RULE_CHANGELOG_QUERY_SHELL =
            "INSERT INTO " + RULE_CHANGELOG_TABLE_NAME + "\n" +
                    "VALUES (\n" +
                    "\tCURRENT_TIMESTAMP,\n" +
                    "\t'%s',\n" +   // modifiedBy
                    "\t'%s',\n" +   // tableModified
                    "\t'%s',\n" +   // operation (add/modify/disable/enable)
                    "\t'%s',\n" +   // ruleId
                    "\t'%s',\n" +   // newRule
                    "\t'%s'\n" +    // oldRule
                    ");";

    public static final String ADD_RULE_QUERY_SHELL =
            "INSERT INTO %s (" +    // birthrightTableName
                    ENTITLEMENT_COLUMN_NAME + ", " +
                    "%s" +          // <All Identity Attribute Criteria>
                    ENDS_IN_SUP_COLUMN_NAME + ", " +
                    NOT_LIST_COLUMN_NAME + ", " +
                    DYNAMIC_COLUMN_NAME + ", " +
                    DISABLED_COLUMN_NAME + ", " +
                    DESCRIPTION_COLUMN_NAME + ")\n" +
                    "VALUES (\n" +
                    "\t'%s',\n" +   // entitlement
                    "%s" +          // <All Criteria Values>
                    "\t%s,\n" +     // endsInSUP
                    "\t%s,\n" +     // notList
                    "\t%s,\n" +     // dynamic
                    "\t%s,\n" +     // disabled
                    "\t%s\n" +      // description
                    ");";

    public static final String CHECK_IF_IDENTITY_GETS_ENTITLEMENT_QUERY_SHELL =
            "SELECT DISTINCT " + NOT_LIST_COLUMN_NAME + "\n" +
                    "FROM %s\n" +   // birthrightTableName
                    "WHERE " + RULE_ID_COLUMN_NAME + " != '%s'\n" +
                    "\tAND " + ENTITLEMENT_COLUMN_NAME + " = '%s'\n" +
                    "\tAND (" + ENDS_IN_SUP_COLUMN_NAME + " IS NULL OR " + ENDS_IN_SUP_COLUMN_NAME + " = '%s')\n" +
                    "\tAND (" + DISABLED_COLUMN_NAME + " IS NULL OR " + DISABLED_COLUMN_NAME + " = 'FALSE')\n" +
                    "\t%s;";        // <All Identity Attribute Criteria> (AND's will be generated)

    public static final String CREATE_BIRTHRIGHT_ASSIGNMENT_TABLE_QUERY_SHELL =
            "CREATE TABLE %s(" +    // birthrightTableName
                    "id INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED, " +
                    RULE_ID_COLUMN_NAME + " AS 'RID' + RIGHT('0000000000' + CAST(id AS VARCHAR(10)), 10) PERSISTED, " +
                    ENTITLEMENT_COLUMN_NAME + " VARCHAR(255) NOT NULL, " +
                    "%s" +          // <All Identity Attribute Criteria> (commas will be generated)
                    ENDS_IN_SUP_COLUMN_NAME + " VARCHAR(8), " +
                    NOT_LIST_COLUMN_NAME + " VARCHAR(255), " +
                    DYNAMIC_COLUMN_NAME + " VARCHAR(8), " +
                    DISABLED_COLUMN_NAME + " VARCHAR(8), " +
                    DESCRIPTION_COLUMN_NAME + " VARCHAR(255)" +
                    ");";

    public static final String GET_ENTITLEMENTS_QUERY_SHELL =
            "SELECT DISTINCT " + ENTITLEMENT_COLUMN_NAME + ", " + NOT_LIST_COLUMN_NAME + ", " + DYNAMIC_COLUMN_NAME + "\n" +
                    "FROM %s\n" +   // birthrightTableName
                    "WHERE (" + ENDS_IN_SUP_COLUMN_NAME + " IS NULL OR " + ENDS_IN_SUP_COLUMN_NAME + " = '%s')\n" +
                    "\tAND (" + DISABLED_COLUMN_NAME + " IS NULL OR " + DISABLED_COLUMN_NAME + " = 'FALSE')\n" +
                    "\t%s;";        // <All Identity Attribute Criteria> (AND's will be generated)

    public static final String GET_RULE_FROM_RULE_ID_QUERY_SHELL =
            "SELECT\n" +
                    "\t" + ENTITLEMENT_COLUMN_NAME + ",\n" +
                    "%s" +          // <All Identity Attribute Criteria> (commas will be generated)
                    "\t" + ENDS_IN_SUP_COLUMN_NAME + ",\n" +
                    "\t" + NOT_LIST_COLUMN_NAME + ",\n" +
                    "\t" + DYNAMIC_COLUMN_NAME + ",\n" +
                    "\t" + DISABLED_COLUMN_NAME + ",\n" +
                    "\t" + DESCRIPTION_COLUMN_NAME + "\n" +
                    "FROM %s\n" +   // birthrightTableName
                    "WHERE " + RULE_ID_COLUMN_NAME + " = '%s';";

    public static final String MODIFY_RULE_QUERY_SHELL =
            "UPDATE %s\n" +         // birthrightTableName
                    "SET\n" +
                    "\t" + ENTITLEMENT_COLUMN_NAME + " = '%s',\n" +
                    "%s" +          // <All Identity Attribute Criteria> (commas will be generated)
                    "\t" + ENDS_IN_SUP_COLUMN_NAME + " = %s,\n" +
                    "\t" + NOT_LIST_COLUMN_NAME + " = %s,\n" +
                    "\t" + DYNAMIC_COLUMN_NAME + " = %s,\n" +
                    "\t" + DISABLED_COLUMN_NAME + " = %s,\n" +
                    "\t" + DESCRIPTION_COLUMN_NAME + " = %s\n" +
                    "WHERE " + RULE_ID_COLUMN_NAME + " = '%s';";
}
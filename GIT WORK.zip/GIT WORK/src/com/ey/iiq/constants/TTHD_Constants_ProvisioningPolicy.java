package com.ey.iiq.constants;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class THD_Constants_ProvisioningPolicy {
    public static final String DESCRIPTION_MESSAGE = "%s Application Account Created Automatically by IdentityIQ";

    //LDAP
    public static final String LDAP_CN="cn=%s+uid=%s";
    public static final String LDAP_CORP_ASSOCIATE_OU=",ou=st9100,o=homedepot.com,c=us";
    public static final String LDAP_STORE_ASSOCIATE_OU=",ou=st%s,ou=stores,o=thdidmprov";
    public static final String LDAP_CONTRACTOR_OU=",ou=THD CONTRACTORS,o=homedepot.com,c=us";
    public static final String PASSWORD_LAST_MODIFIED="20150101";

    //AD
    public static final String AD_CORP_ASSOCIATE_OU=",OU=Corp,OU=Associates,OU=THD Accounts,%s";
    public static final String AD_STORE_ASSOCIATE_OU=",OU=Store,OU=Associates,OU=THD Accounts,%s";
    public static final String AD_CONTRACTOR_OU=",OU=Contractors,OU=Non Associate,OU=THD Accounts,%s";
    public static final String AD_UAC_ACTIVE="512";
    public static final String AD_UAC_INACTIVE="514";
    public static final String AD_PROXY_ADDRESS="SMTP:%s";
    public static final String AD_PROXY_ADDRESS2="smtp:%s@%s";

    //AD - EXTENSION ATTRIBUTE 2
    public static final String AD_YOWMAIL_BUID_1="3827810982763882Tl3LQqAB";
    public static final String AD_YOWMAIL_BUID_2="7450824613322106890027MV";
    public static final String AD_YOWMAIL_BUID_3="7450824613322106890030MV";
    public static final String AD_YOWMAIL_BUID_4="7450824613322106890031MV";
    public static final String AD_YOWMAIL_BUID_5="7454692564806009930139MV";
    public final static Set<String> AD_YOWMAIL_BUID_SET = Collections.unmodifiableSet(
            new HashSet<String>(Arrays.asList(
                    AD_YOWMAIL_BUID_1,
                    AD_YOWMAIL_BUID_2,
                    AD_YOWMAIL_BUID_3,
                    AD_YOWMAIL_BUID_4,
                    AD_YOWMAIL_BUID_5
              )));



}

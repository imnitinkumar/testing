package com.ey.iiq.constants;

public class THD_Constants_General {
    // General constants that can be used in many different situations
    public static final String COMMA = ",";
    public static final String COMMA_WITH_TRAILING_SPACE = ", ";
    public static final String EMPTY_STRING = "";
    public static final String FALSE = "False";
    public static final String NEW_LINE = "\n";
    public static final String NULL_AS_STRING = "NULL";
    public static final String PIPE = "|";
    public static final String SPACE = " ";
    public static final String TAB = "\t";
    public static final String TRUE = "True";
    public static final String UNDERSCORE = "_";

    //PERSON TYPES
    public static final String PERSON_TYPE_CONTRACTOR = "CONTRACTOR";
    public static final String PERSON_TYPE_ASSOCIATE = "ASSOCIATE";

    //LOCATION TYPES
    public static final String LOCATION_TYPE_STORE = "STR";
    public static final String LOCATION_TYPE_CORP = "CORP";
    public static final String LOCATION_TYPE_DC = "DC";
    public static final String LOCATION_TYPE_MET = "MET";

    //STATUS
    public static final String IDENTITY_STATUS_ACTIVE = "A";
    public static final String IDENTITY_STATUS_INACTIVE = "I";
    public static final String IDENTITY_STATUS_TERMINATED = "T";
    public static final String IDENTITY_STATUS_PREHIRE = "H";
    public static final String IDENTITY_STATUS_REHIRE = "R";

    //HOMEDEPOT EMAIL DOMAIN
    public static final String EMAIL_DOMAIN = "@homedepot.com";
    public static final String YOWMAIL_EMAIL_DOMAIN = "@yowmail.com";

}

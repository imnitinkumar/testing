package com.ey.iiq.integrationExecutor;

    import com.ey.iiq.constants.THD_Constants_BadgingIntegration;
    import com.ey.iiq.util.THD_Util_SearchUtil;
    import org.apache.commons.lang.StringUtils;
    import org.apache.log4j.Level;
    import org.apache.log4j.Logger;
    import sailpoint.api.SailPointContext;
    import sailpoint.integration.AbstractIntegrationExecutor;
    import sailpoint.integration.ProvisioningPlan;
    import sailpoint.integration.ProvisioningPlan.AccountRequest;
    import sailpoint.integration.ProvisioningPlan.AttributeRequest;
    import sailpoint.integration.RequestResult;
    import sailpoint.object.*;
    import com.ey.iiq.util.THD_Util_BadgingIntegration;
    import sailpoint.tools.GeneralException;
    import sailpoint.tools.Util;
    import com.ey.iiq.constants.THD_Constants_IdentityAttributes;

    import java.util.List;

public class THD_IntegrationExecutor_BadgingIntegration extends AbstractIntegrationExecutor{

    Logger log = Logger.getLogger("com.ey.com.THD-IntegrationExecutor-BadgingIntegration");

    private String resultStatus;
    private String errorMessage;
    private int retryWait;
    private String successStatus=RequestResult.STATUS_COMMITTED;


    public void configure(SailPointContext context, sailpoint.object.IntegrationConfig config) throws Exception {
        log.setLevel(Level.TRACE);
        if (log.isTraceEnabled()) log.trace("Enter configure");
        this._context = context;
        this._config = config;

        Attributes<String, Object> args = config.getAttributes();
        resultStatus = args.getString("resultStatus");
        errorMessage = args.getString("errorMessage");
        retryWait = args.containsKey("retryWait") ? args.getInt("retryWait") : 1;

        if (log.isTraceEnabled()) log.trace("Exit configure");
    }


    /**
     * Does the provisioning of accounts.  Entry point into the executor class.
     * @param identity - name of the identity to provision
     * @param plan - The provision plan object
     * @return RequestResult object of with the provision status
     */
    @Override
    public RequestResult provision(Identity identity, ProvisioningPlan plan) throws Exception {
        log.setLevel(Level.TRACE);
        if (log.isTraceEnabled()) log.trace("Enter provision for identity: " + identity);
        if (log.isDebugEnabled()) log.debug("Input Plan: " + ((plan != null) ? plan.toMap().toString() : "null"));

        RequestResult result = new RequestResult();
        List<AccountRequest> accReqs = null;
        AccountRequest accReq = null;
        List<AttributeRequest> attReqs = null;
        AttributeRequest attReq  = null;
        Application app=null;

        result.setStatus(resultStatus);

        String requestId = null;
        String badgeStatus = "";

        if (plan != null && plan.getArguments() != null) {
            if (log.isDebugEnabled()) log.debug("plan is not null");
            requestId = (String) plan.getArguments().get("identityRequestId");
            result.setRequestID(requestId);
            accReqs = plan.getAccountRequests();
        }
        else{
            log.error("Plan is null");
        }

        if (accReqs!=null){
            if (log.isDebugEnabled()) log.debug("accReqs are not null");
            accReq = accReqs.get(0);
            accReq.setNativeIdentity(identity.getName());
            attReqs = accReq.getAttributeRequests();
            app = THD_Util_SearchUtil.getApplication(_context,accReq.getApplication());
        }
        else{
            log.error("accReqs are null");
        }

        if (attReqs != null){
            if (log.isDebugEnabled()) log.debug("attReqs are not null");
        }
        else{
            log.error("attReqs are null");
        }

        try {
            if (needFile(identity, accReq, attReqs, _context)) {
                badgeStatus = THD_Util_BadgingIntegration.generateBadgingSystemFile(_context, identity, app, attReqs);
                if (log.isDebugEnabled()) log.debug("Badge Status Returned: " + badgeStatus);

                //File Write Failover, Email Sent with File Attached
                if (StringUtils.equals(RequestResult.STATUS_WARNING, badgeStatus)) {
                    result.setStatus(RequestResult.STATUS_COMMITTED);
                    accReq.setResult(result);
                }
                //Provisioning Failure, No File Write or Email Sent
                if (StringUtils.equals(RequestResult.STATUS_FAILURE, badgeStatus)) {
                    result.addError(THD_Constants_BadgingIntegration.PROVISION_FAILURE_MESSAGE);
                    result.setStatus(RequestResult.STATUS_FAILURE);
                    accReq.setResult(result);
                }
                //Successful File Write
                if (StringUtils.equals(RequestResult.STATUS_COMMITTED, badgeStatus)) {
                    result.setStatus(RequestResult.STATUS_COMMITTED);
                    accReq.setResult(result);
                }
            }
            else{
                //Invalid plan structure
                if (accReq == null){
                    if (log.isDebugEnabled()) log.debug("Invalid Account Request: " + identity.getName());
                    result.setStatus(RequestResult.STATUS_FAILURE);
                }
                //Valid plan structure but no file needed to be written
                else {
                    if (log.isDebugEnabled()) log.debug("No File Needs to be Written for Identity: " + identity.getName());
                    result.setStatus(RequestResult.STATUS_COMMITTED);
                    accReq.setResult(result);
                }
            }
        }
        catch(GeneralException e){
            result.setStatus(RequestResult.STATUS_FAILURE);
            result.addError(THD_Constants_BadgingIntegration.PROVISION_FAILURE_MESSAGE);
            accReq.setResult(result);
            resultStatus=badgeStatus;
            throw e;
        }

        if (log.isDebugEnabled()) log.debug("Returning RequestResult. Status: " + result.getStatus() + "; RequestID: " + requestId);
        return result;
    }

    public boolean needFile(Identity identity, AccountRequest accReq, List<AttributeRequest> attReqs, SailPointContext context){
        boolean result = false;
        log.setLevel(Level.TRACE);
        String planStatus = "";
        String planLocationNumber="";
        String linkLocationNumber="";

        if (context == null){
            if (log.isDebugEnabled()) log.debug("Context is null");
            return false;
        }
        if (identity == null){
            if (log.isDebugEnabled()) log.debug("Identity is null");
            return false;
        }
        else{
            if (log.isTraceEnabled()) log.trace("Entering needFile with Identity" + identity.getName());
        }
        if (accReq == null){
            if (log.isDebugEnabled()) log.debug("Account Request is null");
            return false;
        }
        else{
            if (log.isDebugEnabled()) log.debug("Account Request Operation: " + accReq.getOperation());
        }
        if (attReqs == null){
            if (log.isDebugEnabled()) log.debug("Attribute Requests is null");
        }
        else {
            for (AttributeRequest attReq : attReqs) {
                if (THD_Constants_BadgingIntegration.BADGE_STATUS.equalsIgnoreCase(attReq.getName())) {
                    planStatus = Util.otos(attReq.getValue());
                    log.debug("Plan status: " + planStatus);
                } else if (THD_Constants_IdentityAttributes.LOCATION_NUMBER.equalsIgnoreCase(attReq.getName())) {
                    planLocationNumber = Util.otos(attReq.getValue());
                    log.debug("Plan location number: " + planLocationNumber);
                } else {
                    log.debug("Attribute: " + attReq.getName() + " \tValue: " + attReq.getValue());
                }
            }
        }

        for (Link l : identity.getLinks()){
            if (THD_Constants_BadgingIntegration.APP_NAME.equals(l.getApplication().getName())){
                linkLocationNumber = Util.otos(l.getAttribute(THD_Constants_IdentityAttributes.LOCATION_NUMBER));
            }
        }

        //Create Operation
        if (accReq.getOperation().equals(sailpoint.object.ProvisioningPlan.AccountRequest.Operation.Create.toString())) {
            if (Util.otob(identity.getAttribute(THD_Constants_IdentityAttributes.BADGE_ENABLED)) && planStatus != null
                    && StringUtils.equalsIgnoreCase(planStatus, THD_Constants_BadgingIntegration.BADGE_STATUS_ACTIVE)) {
                if (log.isDebugEnabled()) log.debug("Create Event Processed Setting Result to true");
                result = true;
            }
        }

        //Enable Operation
        else if (accReq.getOperation().equals(sailpoint.object.ProvisioningPlan.AccountRequest.Operation.Enable.toString())) {
            if (Util.otob(identity.getAttribute(THD_Constants_IdentityAttributes.BADGE_ENABLED)) && planStatus != null
                    && StringUtils.equalsIgnoreCase(planStatus, THD_Constants_BadgingIntegration.BADGE_STATUS_ACTIVE)) {
                if (log.isDebugEnabled()) log.debug("Enable Event Processed Setting Result to true");
                result = true;
            }
        }

        //Modify Operation
        else if (accReq.getOperation().equals(sailpoint.object.ProvisioningPlan.AccountRequest.Operation.Modify.toString())) {
            //Badge Enabled attribute is True but the attribute Request is T(erminated) (badgeEnabled: F->T)
            if (Util.otob(identity.getAttribute(THD_Constants_IdentityAttributes.BADGE_ENABLED)) && planStatus != null
                    && StringUtils.equalsIgnoreCase(planStatus, THD_Constants_BadgingIntegration.BADGE_STATUS_TERMINATED)) {
                if (log.isDebugEnabled()) log.debug ("Modify Event (F->T) Processed Setting result to true");
                result = true;
            }
            //Badge Enabled attribute is True but the attribute Request is I(nactive) (badgeEnabled: F->T)
            else if (Util.otob(identity.getAttribute(THD_Constants_IdentityAttributes.BADGE_ENABLED)) && planStatus != null
                    && StringUtils.equalsIgnoreCase(planStatus, THD_Constants_BadgingIntegration.BADGE_STATUS_INACTIVE)) {
                if (log.isDebugEnabled()) log.debug ("Modify Event (F->T) Processed Setting result to true");
                result = true;
            }
            //Badge Enabled attribute is false but the attribute Request is A(ctive) (badgeEnabled: T->F)
            else if (!Util.otob(identity.getAttribute(THD_Constants_IdentityAttributes.BADGE_ENABLED)) && planStatus != null
                    && StringUtils.equalsIgnoreCase(planStatus, THD_Constants_BadgingIntegration.BADGE_STATUS_ACTIVE)) {
                if (log.isDebugEnabled()) log.debug ("Modify Event (T->F) Processed Setting result to true");
                result = true;
            }
            //Badge Enabled attribute is True and location number changes
            else if (Util.otob(identity.getAttribute(THD_Constants_IdentityAttributes.BADGE_ENABLED)) && !linkLocationNumber.equalsIgnoreCase(planLocationNumber)){
                result = true;
            }
            else{
                if (log.isDebugEnabled()) log.debug ("Modify Event (no change) Processed Setting result to false");
                result=false;
            }
        }

        //Disable Operation
        else if (accReq.getOperation().equals(sailpoint.object.ProvisioningPlan.AccountRequest.Operation.Disable.toString())) {
            if (planStatus != null && StringUtils.equalsIgnoreCase(planStatus, THD_Constants_BadgingIntegration.BADGE_STATUS_INACTIVE)) {
                if (log.isDebugEnabled()) log.debug("Disable Event Processed Setting Result to true");
                result = true;
            }
        }

        //Delete Operation
        else if (accReq.getOperation().equals(sailpoint.object.ProvisioningPlan.AccountRequest.Operation.Delete.toString())) {
            if (planStatus != null && StringUtils.equalsIgnoreCase(planStatus, THD_Constants_BadgingIntegration.BADGE_STATUS_TERMINATED)) {
                if (log.isDebugEnabled()) log.debug("Delete Event Processed Setting Result to true");
                result = true;
            }
        }
        else{
            if (log.isDebugEnabled()) log.debug("Unidentified Life Cycle Event Processed Setting Result to false");
            result = false;
        }

        if (log.isDebugEnabled()) log.debug("needFile return value: " + result);
        if (log.isTraceEnabled()) log.trace("Exiting needFile with Identity" + identity.getName());
        return result;
    }
}

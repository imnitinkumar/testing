package com.homedepot.iam.iiq.snowclone.SnowCloneExecutor;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import org.apache.http.HttpException;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.object.Attributes;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningResult;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;
import sailpoint.object.Custom;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.algorithms.Algorithm;
import com.google.auth.oauth2.ServiceAccountCredentials;
import java.io.FileInputStream;
import java.security.interfaces.RSAPrivateKey;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.lang.StringBuilder;
import java.lang.String;
import org.json.simple.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.util.EntityUtils;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.apache.http.impl.client.DefaultHttpClient;



public class TicketSystemClient {
  private static final Logger logger = Logger.getLogger(TicketSystemClient.class);

  static final String TICKETS = "tickets";

  static final String SIMULATED_LATENCY = "simulatedLatency";
  SailPointContext context;

  SnowCloneExecutor executor;


  public TicketSystemClient(SnowCloneExecutor executor) throws GeneralException {
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    this.executor = executor;
    logger.debug("Start SnowCloneExecutor");
    logger.debug("Thread Name:" + Thread.currentThread().getName() + ", id:" + Thread.currentThread().getId());
  }

  ProvisioningResult provision(ProvisioningPlan plan) throws GeneralException, IOException, HttpException {
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);

    List<String> appList = new ArrayList();
    if ( plan != null ) {
      logger.debug( "plan [" + plan.toXml() + "]" );
      appList = getAppList(plan);
    }
    logger.debug("In provision statement in Ticket System Class");
    ProvisioningResult provisioningResult = new ProvisioningResult();
    String num = createServiceTicket(appList);
    provisioningResult.setStatus("queued");
    provisioningResult.setRequestID(num);
    return provisioningResult;
  }
  List<String> getAppList(ProvisioningPlan plan)
  {
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    logger.debug("in get AppList method");
    List<String> appList = new ArrayList();
    String identityRequestNo = null;
    String pattern = null;
    Attributes<String, Object> planArgs = plan.getArguments();
    if (planArgs != null) {
      identityRequestNo = (String)planArgs.get("identityRequestId");
      logger.debug("identityRequestNo:" + identityRequestNo);
    }
    List<ProvisioningPlan.AccountRequest> accounts = plan.getAccountRequests();
    if ( ( accounts != null ) && ( accounts.size() > 0 ) ) {

      for (ProvisioningPlan.AccountRequest account : accounts)
      {
        String app = account.getApplication();
        String operation = account.getOperation().toString();
        String user = account.getNativeIdentity();
        pattern = app + ":" + operation + ":" + user + ":" + identityRequestNo;
        logger.debug("pattern: " + pattern);
        appList.add(pattern);
      }
    }
    logger.debug("appList: " + appList);
    return appList;
  }

  ProvisioningResult checkStatus(String requestId) throws GeneralException, IOException {
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    logger.debug("In check status statement in Ticket System Class");
    //Boolean ticketStatus =  checkTicket(requestId);
    ProvisioningResult provisioningResult = new ProvisioningResult();
    provisioningResult.setStatus("committed");
    return provisioningResult;
  }
  Boolean checkTicket(String requestId) throws IOException {
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    logger.debug("Entering checkTicket()");

    String token = null;
    String num = null;
    try
    {
      //Call method to get the JWT token
      token = generateJwtToken();
    }
    catch (Exception e)
    {
      logger.error("exception : " + e.getMessage());
    }
    logger.debug("token generated: " + token);

    //call method to create payload for the request
    String postData = generateCheckStatusPayload(requestId);
    logger.debug("post data: " + postData);

    //call method to make post request and return ticket number
    num = makePOSTRequest(postData, token);
    logger.debug("ticket number :" + num);
    return true;
  }
  String generateCheckStatusPayload(String requestId)
  {
    return requestId;
  }
  String createServiceTicket(List<String> appList) throws HttpException, IOException, GeneralException {
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    logger.debug("Entering createIncidentTicket()");

    String token = null;
    String num = null;
    try
    {
      //Call method to get the JWT token
      token = generateJwtToken();
    }
    catch (Exception e)
    {
      logger.error("exception : " + e.getMessage());
    }
    logger.debug("token generated: " + token);

    //call method to create payload for the request
    String postData = generatePayload(appList);
    logger.debug("post data: " + postData);

    //call method to make post request and return ticket number
    num = makePOSTRequest(postData, token);
    logger.debug("ticket number :" + num);
    return num;
  }
  String generateJwtToken() throws FileNotFoundException, IOException {

    //This method will generate the JWT token require for authentication
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);

    Date now = new Date();
    Date expTime = new Date(System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(3600));
    logger.debug("expiry time: " + expTime);
    // Build the JWT payload
    JWTCreator.Builder token = JWT.create().withIssuedAt(now).withExpiresAt(expTime).withIssuer("sailpoint-dev@io1-datalake-dev.iam.gserviceaccount.com").withAudience("sailpoint-dev@io1-datalake-dev.iam.gserviceaccount.com").withSubject("sailpoint-dev@io1-datalake-dev.iam.gserviceaccount.com").withClaim("email", "sailpoint-dev@io1-datalake-dev.iam.gserviceaccount.com");
    // Sign the JWT with a service account
    FileInputStream stream = new FileInputStream("/opt/apps/logs/io1-datalake-dev-4a548d10d3f8.json");

    ServiceAccountCredentials cred = (ServiceAccountCredentials) ServiceAccountCredentials.fromStream(stream);
    RSAPrivateKey key = (RSAPrivateKey) cred.getPrivateKey();
    Algorithm algorithm = Algorithm.RSA256(null, key);
    return token.sign(algorithm);

  }

  String getTicketNumber(String responseBody, String status) {
    //This method is used to get the ticket number from the response body
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    logger.debug("Entering getTicketNumber()");

    String incNumber = null;
    try
    {
      if( Util.isNotNullOrEmpty(status) && status.contains("201"))
      {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(responseBody);
        //get the JSONArray result
        JSONArray result = (JSONArray) obj.get("result");
        JSONObject obj2 = (JSONObject)result.get(0);
        if(Util.isNotNullOrEmpty((String) obj2.get("display_name")) && ((String) obj2.get("display_name")).equalsIgnoreCase("number"))
        incNumber= (String) obj2.get("display_value");
      }
      logger.debug("Incident number --> " + incNumber);
      return incNumber;
    }
    catch (Exception e){
      logger.error("Exception getTicketNumber() : " + e.getMessage());
      return incNumber;
    }
  }

  String generatePayload(List<String> appList) throws GeneralException {
    Custom obj = context.getObjectByName(Custom.class, "THD-Custom-ServiceNow-Mapping");
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    logger.debug("in generatePayload method");
    String accessRequestID = null;
    String userName = null;
    StringBuilder str1 =  new StringBuilder();
    int counter = 0;
    int appSize = appList.size();
    logger.debug("app size: " + appSize);

    for(String app : appList)
    {
      logger.debug("app: " + app);
      counter++;

      str1.append("{");
      String[] value = app.split(":");
      logger.debug("value 1: " + value[0] + " value 2: " + value[1]);
      accessRequestID =  value[3];
      userName = value[2];
      logger.debug("Access request id: " + accessRequestID);
      logger.debug("User Name: " + userName);
      str1.append("\"action\" : \"" + value[1] + "\",");
      str1.append("\"description\" : \"" + app + "\",");
      str1.append("\"application_field_name\" : \"" + value[0] + "\"");

      str1.append("}");
      logger.debug("counter: " + counter);
      if(counter < appSize) {
        logger.debug("met the criteria");
        str1.append(",");
      }

    }
    String dynamic = str1.toString();
    logger.debug("dynamic content of payload: " + dynamic);
    StringBuilder str = new StringBuilder("{");
    str.append("\"u_cat_item\":\"" + obj.get("cat_item") + "\",");
    str.append("\"u_opened_by\": \"" + obj.get("opened_by") +  "\",");
    str.append("\"u_watch_list\": \"" + obj.get("watch_list") + "\",");
    str.append("\"u_variables\":{");
    str.append("\"access_request_id\": \"" + accessRequestID + "\",");
    str.append("\"opened_by_field_user_name\": \"" + obj.get("opened_by") + "\",");
    str.append("\"req_description\": \"" + String.format((String) obj.get("shortDescription"), accessRequestID) + "\",");
    str.append("\"user_field_user_name\": \"" + userName + "\",");
    str.append("\"sailpoint_application_task_MRVS\":[ ");
    str.append(dynamic);
    str.append("]}}");
    logger.debug("string builder value: " + str.toString());
    return str.toString();
  }
  String makePOSTRequest(String postData, String token) throws IOException {
    String status = null;
    String num = null;
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    DefaultHttpClient httpclient = new DefaultHttpClient();
    String responseBody = "";
    CloseableHttpResponse response = null;
    try
    {

      HttpPost httpPost = new HttpPost("https://snowcloneapi-dot-io1-datalake-dev.appspot.com/v1/ritm/catalog-item");
      httpPost.setHeader("Accept", "application/json");
      httpPost.setHeader("Content-Type", "application/json");
      httpPost.setHeader("x-app-srv-account", "SVC_IIQ_ServiceNowNP");

      String authorizationHeader = "Bearer " + token;


      httpPost.setHeader("Authorization", authorizationHeader);

      HttpEntity entity = new ByteArrayEntity(postData.getBytes("utf-8"));
      httpPost.setEntity(entity);

      logger.debug("Executing request " + httpPost.getRequestLine());
      response = httpclient.execute(httpPost);

      logger.debug("----------------------------------------");
      logger.debug(response.getStatusLine());
      status = response.getStatusLine().toString();
      responseBody = EntityUtils.toString(response.getEntity());
      logger.debug("response body: " + responseBody);
      logger.debug("status: " + status);
      //call method to get Ticket number

      num = getTicketNumber(responseBody, status);
      logger.debug("Exiting createIncidentTicket()"+ num);
      return num;

    }
    catch (Exception e){
      logger.error("Exception createIncidentTicket() : " + e.getMessage());
    }
    finally
    {
      if(response != null)
        response.close();

      if(httpclient != null)
        httpclient.close();
    }
    return num;

  }
}

package com.homedepot.iam.iiq.snowclone.SnowCloneExecutor;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import sailpoint.api.SailPointContext;
import sailpoint.integration.AbstractIntegrationExecutor;
import sailpoint.object.IntegrationConfig;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningResult;
import sailpoint.tools.GeneralException;

public class SnowCloneExecutor extends AbstractIntegrationExecutor {
  private static final Logger logger = Logger.getLogger(SnowCloneExecutor.class);
  
  SailPointContext context;
  
  private TicketSystemClient ticketSystemClient;
  
  IntegrationConfig config;

  private int simulatedLatency = 100;
  
  public SnowCloneExecutor() throws GeneralException {
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    logger.debug("Start SnowCloneExecutor");
    this.ticketSystemClient = new TicketSystemClient(this);
  }

  public void configure(SailPointContext context, IntegrationConfig config) throws Exception {
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    logger.debug("In configure method in main class");
    logger.debug("configure start()");
    super.configure(context, config);
    this.simulatedLatency = config.getInt("simulatedLatency");
    this.context = context;
    this.config = config;
  }
  
  public ProvisioningResult checkStatus(String requestId) throws Exception {
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    logger.debug("In check status method in main class");
    logger.debug("Inside checkStatus:" + requestId);
    ProvisioningResult provisioningResult = new ProvisioningResult();
    logger.debug("simulated latency sleep start (" + this.simulatedLatency + " ms)");
    Thread.sleep(this.simulatedLatency);
    logger.debug("simulated latency sleep end");
    if (this.context != null) {
      if (null == requestId || requestId.isEmpty()) {
        provisioningResult.addError("The requestId was null or empty");
        provisioningResult.setStatus("failed");
      } else {
        provisioningResult = this.ticketSystemClient.checkStatus(requestId);
      } 
    } else {
      provisioningResult.setStatus("failed");
      provisioningResult.addError("The context was null");
    } 
    return provisioningResult;
  }
  
  public String ping() throws Exception {
    return "Success";
  }
  
  public ProvisioningResult provision(ProvisioningPlan plan) throws Exception {
    Logger logger = Logger.getLogger("test");
    logger.setLevel(Level.DEBUG);
    logger.debug("plan in provision step: " + plan.toXml());
    logger.debug("In provision method in main class");
    logger.debug("Start provision(). Thread Name:" + Thread.currentThread().getName() + ", id:" + 
        Thread.currentThread().getId());
    ProvisioningResult provisioningResult = new ProvisioningResult();
    logger.debug("simulated latency sleep start (" + this.simulatedLatency + " ms)");
    Thread.sleep(this.simulatedLatency);
    logger.debug("simulated latency sleep end");
    if (null != plan && null != this.context) {
        provisioningResult = this.ticketSystemClient.provision(plan);
    } else {
      provisioningResult.setStatus("failed");
      provisioningResult.addError("The context or plan was null");
    } 
    return provisioningResult;
  }

}
